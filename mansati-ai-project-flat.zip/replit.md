# Mansati AI on Replit

## Run locally in the workspace

The project uses Next.js and Node.js 24.

```bash
npm install
npm run dev -- -p 5000
```

The Replit workflow is **Start application** and serves the app on port 5000.

## Required secrets

Set these as Replit Secrets before using authentication, onboarding, or AI chat:

- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`
- `CLOUDFLARE_ACCOUNT_ID + CLOUDFLARE_AI_API_TOKEN`
- `ENCRYPTION_KEY`

Stripe and Google credentials are optional and only enable their respective
features. The Supabase schema and storage bucket setup are documented in
`README.md` and `DEPLOY_GUIDE.md`.

## Production

The app builds with `npm run build` and runs with:

```bash
npm run start -- -p 5000
```

Publishing is configured for an autoscale web deployment using that production
command. Set `NEXT_PUBLIC_APP_URL` to the published `.replit.app` URL after the
first publish so authentication redirects and widget snippets use the public
address.