import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#f2f7ff",
          500: "#3b6cf6",
          600: "#2d54d1",
          700: "#233fa3"
        }
      }
    }
  },
  plugins: []
};

export default config;
