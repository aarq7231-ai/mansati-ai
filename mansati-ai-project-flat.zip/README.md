# Mansati AI — Phase 1: Database + Auth + Multi-Tenancy

This is the **foundation** of the platform. It includes:

- Full database schema (all 27 tables from the spec) with indexes
- Row Level Security policies so every business's data is isolated
- Email/password signup, login, logout, password reset
- Onboarding flow that creates a workspace, starts the 3-day trial, and
  auto-creates the first AI agent
- A minimal dashboard proving the whole chain works

Nothing else (landing page design, chat engine, channels, billing, etc.) is
built yet — those are separate phases, on purpose, so each piece is testable.

---

## What YOU need to do (one-time setup)

I can't create external accounts for you. Here's exactly what's needed:

### 1. Create a free Supabase project
- Go to **https://supabase.com** → sign up → "New Project"
- Pick any name/region, set a database password (save it somewhere safe)
- Wait ~2 minutes for it to finish provisioning

### 2. Get your API keys
- In your Supabase project: **Project Settings → API**
- Copy these three values:
  - `Project URL`
  - `anon public` key
  - `service_role` key (⚠️ keep this secret — never share it or put it in chat)

### 3. Fill in your environment file
- Copy `.env.example` to a new file named `.env.local`
- Paste in the three values from step 2:
  ```
  NEXT_PUBLIC_SUPABASE_URL=your-project-url
  NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
  SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
  ```

### 4. Run the database migrations
Easiest way (no command line needed):
- In Supabase: **SQL Editor** → New query
- Open `supabase/migrations/0001_schema.sql`, paste the whole file, click **Run**
- Repeat for `0002_rls_policies.sql`, then `0003_seed_plans.sql` (in that exact order)

### 5. Enable email auth (on by default, just confirm)
- **Authentication → Providers → Email** should already be enabled
- **Authentication → URL Configuration** → set Site URL to your deployed domain
  once you have one (use `http://localhost:3000` for now)

### 6. Run it
If you have someone run this for you, or once we set up deployment:
```
npm install
npm run dev
```
Then visit `/signup` → confirm email → you'll land in onboarding → dashboard.

### 7. Deploy (next phase, when you're ready)
- Push this folder to a GitHub repo
- Import it into **Vercel** (https://vercel.com)
- Add the same three env vars from step 3 in Vercel's project settings
- Vercel gives you a live URL automatically

---

## What's NOT needed yet
Everything in `.env.example` below the "LATER phases" line (WhatsApp, Instagram,
Telegram, Google, Stripe) — those are future build phases. Nothing in this
phase depends on them.

## Architecture notes for future phases
- **Tenant isolation**: every business-owned table has `workspace_id` + an
  RLS policy checking `workspace_members`. Never query these tables with the
  admin client from user-facing code — only the regular server client, so RLS
  stays in force.
- **Admin client** (`src/lib/supabase/admin.ts`) bypasses RLS. It's marked
  `server-only` so it can't accidentally leak into the browser. Reserve it for
  cron jobs, webhook handlers, and the future admin panel.
- **Plans/limits** live in the `plans` table, not in code — the admin panel
  (future phase) can change price/limits without a deploy.
- **Agent settings** are separate from `agents` (1:1) so the agent identity
  and its tunable behavior can evolve independently.

---

## Phase 2: Agent Builder + Chat Engine

Added on top of Phase 1:

- **AI Provider abstraction** (`src/lib/ai/`) — `AIProvider` interface,
  `Cloudflare Workers AIProvider` adapter, and a `ModelRouter`. Nothing else in the app talks
  to Cloudflare Workers AI directly, so adding DeepSeek or another provider later is one new
  file + one line in the router's registry.
- **Agent Builder** (`/dashboard/agents/[agentId]`) — edit personality, tone,
  system instructions, welcome/fallback messages, and custom rules. Includes
  a live "test your agent" chat panel right next to the form.
- **Chat engine** (`/api/chat/[publicAgentId]`) — streams responses via
  Server-Sent Events, persists every message, and enforces (server-side,
  never trusting the client):
  1. Human handoff — if a staff member has taken over, the AI stays silent
  2. Trial/subscription status — blocked with the exact message from the spec
     once the 3-day trial expires and no paid plan is active
  3. Monthly message limits — atomic check-and-increment via a Postgres
     function (`supabase/migrations/0004_usage_and_chat_helpers.sql`), so two
     simultaneous messages can never both slip past the limit
- **Anti-hallucination prompt builder** (`src/lib/chat/system-prompt.ts`) —
  assembles the system prompt in the exact priority order from the spec
  (system instructions → business settings → retrieved knowledge →
  conversation context) and instructs the model to use the configured
  fallback message instead of inventing answers.
- **Public chat page** (`/agent/[publicAgentId]`) — a no-login-required page
  businesses without a website can share directly with customers.

### One more thing YOU need for this phase
Get a free Cloudflare Workers AI API key:
- Go to **https://aistudio.google.com/app/apikey** → sign in → "Create API key"
- Add it to `.env.local`: `CLOUDFLARE_ACCOUNT_ID + CLOUDFLARE_AI_API_TOKEN=your-key-here`

### Run the new migration
Same as before — open `supabase/migrations/0004_usage_and_chat_helpers.sql`
in the Supabase SQL Editor and run it (after 0001–0003, which you should
already have run).

### What's intentionally stubbed for now
- **Knowledge base / RAG** (`src/lib/chat/knowledge.ts`) — returns no results
  yet. The upload → chunk → embed → vector-search pipeline is its own future
  phase; the chat engine already has a slot for retrieved context, so wiring
  it in later won't touch the chat route.
- **Website embed script / widget branding** — the public chat page proves
  the engine works; a polished, brandable `<script>` embed is part of the
  landing-page/widget phase.
- **Lead capture into CRM from conversations** — conversations don't yet
  auto-create a `contacts`/`leads` row; that's the CRM phase.

---

## Phase 3: Knowledge Base + RAG

Added on top of Phases 1–2. Agents can now answer from real business content
instead of just their configured instructions.

- **Ingestion pipeline** (`src/lib/knowledge/`) — upload PDF/DOCX/TXT/CSV/XLSX,
  paste text manually, or add a website URL (robots.txt is checked first).
  Each source is extracted → chunked → embedded → stored, with a visible
  status (pending/processing/ready/error) and a reprocess button if
  something fails.
- **Embeddings** (`src/lib/ai/embeddings.ts`) — same swappable-provider
  pattern as chat. Cloudflare Workers AI's `text-embedding-004` is the default.
- **Retrieval** (`src/lib/chat/knowledge.ts`) — replaces the earlier stub.
  Embeds the customer's message and runs a cosine-similarity search
  (`supabase/migrations/0005_knowledge_search.sql`) scoped to that specific
  agent. Results below a relevance threshold are dropped entirely rather
  than passed to the model — so the anti-hallucination fallback message
  kicks in instead of a low-confidence guess.
- **Dashboard page**: `/dashboard/agents/[agentId]/knowledge` — upload,
  add text, add a URL, see status, delete, or reprocess. Linked from the
  Agent Builder page.

### Two more things YOU need for this phase

**1. Enable pgvector** (if not already on) — in Supabase: **Database →
Extensions** → search "vector" → enable it. (Migration 0001 also tries to
enable it automatically; this is just a fallback if that didn't take.)

**2. Create the storage bucket for uploaded files**
- Supabase Dashboard → **Storage** → "New bucket"
- Name it exactly: `knowledge-files`
- Set it to **Private** (not public) — files are only ever accessed via the
  server using the service role key, never a public URL

### Run the new migration
Same process as before: **SQL Editor** → paste `0005_knowledge_search.sql` →
Run (after 0001–0004).

### Install the new packages
This phase adds `pdf-parse`, `mammoth`, and `xlsx` to `package.json` for
reading those file formats. Run `npm install` again before starting the dev
server.

### What's intentionally deferred
- Large files are processed synchronously on upload (fine for typical
  business documents). A background job queue for very large batches is a
  later scaling concern, not a Phase 3 need.
- No OCR for scanned/image-only PDFs yet.

---

## Phase 4: Embeddable Website Widget

Added on top of Phases 1–3. Businesses can now put the agent on their own
website with one script tag — no code changes on their end beyond pasting it.

- **`public/widget.js`** — a small, dependency-free vanilla JS script. It
  reads its own `<script>` tag's attributes (agent id, color, position,
  optional greeting bubble text) and injects a floating launcher button +
  chat iframe. Works on any website regardless of what it's built with.
- **`/embed/[publicAgentId]`** — the bare-chrome page that loads inside the
  widget's iframe, styled with the business's branding.
- **Branding controls** in the Agent Builder — primary color, logo URL,
  greeting bubble text, and left/right position, stored in
  `agent_settings.branding`. The Agent Builder now shows the exact
  `<script>` snippet to copy, generated from those settings.
- **CORS enabled** on `/api/chat/[publicAgentId]` — required since the
  widget script runs on arbitrary third-party domains, not just this app's
  own origin. Nothing sensitive is exposed; the same public-agent-id-only
  access model as the standalone chat page applies.

### Nothing new required from you for this phase
No new accounts or keys — this only needed code changes.

### How a business actually uses it
1. Open their agent in the Agent Builder
2. Set a brand color / logo / greeting (optional)
3. Copy the `<script>` snippet shown on the page
4. Paste it into their website's HTML before `</body>`

### What's intentionally deferred
- Widget analytics (opens, engagement) — part of the future Analytics phase
- Multiple simultaneous widgets per page, custom CSS injection — not needed
  for a first release
- Persisting the visitor's conversation across page reloads (currently a
  fresh conversation starts each page load) — a nice-to-have for later

---

## Phase 5: Unified Inbox + Human Handoff UI

Added on top of Phases 1–4. The handoff *logic* already existed in the chat
engine since Phase 2 (an AI-silenced state once `conversations.status =
human_active`) — this phase adds the staff-facing interface for it.

- **`/dashboard/inbox`** — every conversation across all channels (only
  `website` is live so far; WhatsApp/Instagram/Messenger/Telegram slot into
  the same list once those channel integrations are built) in one place,
  with contact name/phone, channel, and status at a glance.
- **`/dashboard/inbox/[conversationId]`** — the full thread, with:
  - **"تحويل إلى موظف" (Take over)** — flips the conversation to
    `human_active` and assigns it to the staff member who clicked it. The
    AI immediately stops responding on its next customer message (this
    check already existed in the chat route).
  - **"إعادة إلى الوكيل الذكي" (Hand back to AI)** — reverses it.
  - **Close** — marks the conversation `closed`.
  - A reply box that only appears once a human has taken over, so staff
    and AI never talk over each other.
- Lightweight auto-refresh (polling every few seconds) so staff see new
  incoming messages without manually reloading — a clean upgrade path to
  Supabase Realtime later without changing the page structure.

### Nothing new required from you for this phase
No new accounts, keys, or migrations — this only needed application code on
top of the existing schema and RLS policies.

### What's intentionally deferred
- Real-time push (Supabase Realtime/websockets) instead of polling
- Staff-to-staff conversation notes, tags, and internal comments
- Multi-agent assignment / team routing rules

---

## Phase 6: CRM + AI Lead Qualification

Added on top of Phases 1–5.

- **Automatic lead creation** (spec section 20) — every new conversation now
  creates a `contacts` + `leads` row automatically (`src/lib/crm/lead-capture.ts`),
  so nothing has to be filled in manually just to start tracking a customer.
- **AI lead qualification** (spec section 21) — define questions in the
  Agent Builder ("What service are you interested in?", "What's your
  budget?"). After each AI reply, a small non-streaming extraction call
  checks the conversation so far and saves any answers it can support
  directly from what was said — never invented — into `leads.answers`.
  Once every configured question has an answer, the lead auto-advances to
  `qualified`.
  - **Design choice worth knowing**: this uses a lightweight extraction
    call rather than full function-calling/tool-use in the main chat loop.
    It's simpler to reason about and keeps the primary streaming response
    fast, at the cost of running one extra small AI call per turn once
    lead questions are configured. Swapping to real function-calling later
    is possible without changing the CRM data model.
- **`/dashboard/contacts`** — every contact, with name/phone/email/source/tags
- **`/dashboard/contacts/[contactId]`** — edit contact info & notes, see
  every lead record and every conversation tied to them
- **`/dashboard/leads`** — the full pipeline (new → interested → qualified →
  negotiation → won → lost) with status filtering and one-click updates

### Nothing new required from you for this phase
No new accounts, keys, or migrations.

### What's intentionally deferred
- A visual drag-and-drop kanban board (current UI is a filterable list —
  functionally equivalent, less visual polish)
- Manual lead creation from the dashboard UI (currently only auto-created
  from conversations)

---

## Phase 7: Billing (provider-agnostic, Stripe adapter)

Added on top of Phases 1–6.

- **Billing provider abstraction** (`src/lib/billing/`) — same swappable
  pattern as the AI providers. Checkout, webhooks, and cancellation all go
  through a `BillingProvider` interface; nothing else in the app talks to
  Stripe directly, so a region-specific provider can be added later
  without touching the dashboard or the `subscriptions` table.
- **`/dashboard/billing`** — shows current plan, status, trial countdown,
  and an "الترقية الآن" (Upgrade) button for the $5/mo Pro plan.
- **`/api/billing/checkout`** — authenticated, owner/admin-only, starts a
  Stripe Checkout session for the caller's own workspace.
- **`/api/billing/webhook`** — verifies the signature, then updates
  `subscriptions` on successful payment, failed payment, renewal, and
  cancellation.
- **`plans.provider_metadata`** (new column, migration 0006) — holds the
  Stripe price ID (or any future provider's equivalent) per plan, so the
  price/limits themselves stay provider-agnostic in the `plans` table.

### This is the one phase with a genuine external dependency
Everything above is built and will compile/run — but real payments need a
Stripe account, which only you can create:

**1. Create a Stripe account** → **https://dashboard.stripe.com/register**

**2. Get your API key**
- Dashboard → Developers → API keys → copy the **Secret key**
- Add to `.env.local`: `STRIPE_SECRET_KEY=sk_...`

**3. Create the $5/mo product**
- Dashboard → Product catalog → "Add product" → name it "Mansati Pro",
  price $5.00/month, recurring
- Copy the **Price ID** (starts with `price_...`)
- In Supabase SQL Editor, run:
  ```sql
  update plans
  set provider_metadata = '{"stripe": {"price_id": "price_YOUR_ID_HERE"}}'
  where key = 'pro';
  ```

**4. Set up the webhook**
- Dashboard → Developers → Webhooks → "Add endpoint"
- URL: `https://YOUR_DOMAIN/api/billing/webhook`
- Events to send: `checkout.session.completed`, `invoice.payment_failed`,
  `customer.subscription.deleted`, `customer.subscription.updated`
- Copy the **Signing secret** → add to `.env.local`: `STRIPE_WEBHOOK_SECRET=whsec_...`

Until these are set, the Upgrade button will show a clear error instead of
failing silently — nothing else in the app is blocked by billing not being
configured yet.

### Run the new migration
`0006_billing_provider_metadata.sql` in the SQL Editor, after 0001–0005.

### What's intentionally deferred
- Invoice history UI, proration, plan downgrades
- A visible "cancel subscription" self-service button (the API method
  exists in the provider interface; wiring a button to it is a small
  follow-up)

---

## Phase 8: Admin Panel

Added on top of Phases 1–7. A separate, gated area for you (the platform
owner) to run Mansati AI itself — never exposed to regular business users.

- **`/admin`** — overview: total workspaces, users, trial/active/past-due
  breakdown, MRR, total agents, and this month's message volume across the
  whole platform.
- **`/admin/workspaces`** — every tenant, with plan/status at a glance.
- **`/admin/workspaces/[id]`** — usage detail, **change plan**, and
  **suspend/reactivate** (a suspended workspace's public agent immediately
  stops responding — enforced in the chat route itself, not just hidden in
  the UI). Every action is written to `admin_logs`.
- **`/admin/plans`** — edit price, message/storage/agent/file limits, and
  public/active visibility for any plan, live, with no code change or
  deploy. This is the "admin can change pricing without touching code"
  requirement from the spec, fully working end to end.
- **Security model**: gated by the `platform_admins` table + RLS (not a
  hard-coded role check) — every admin query relies on the database itself
  granting cross-tenant read/write access, the same pattern used
  throughout the app.

### One thing YOU need to do: make yourself an admin
There's no signup flow for platform admins by design — you grant it once,
directly in the database:
1. Sign up for a normal account first (if you haven't already) at `/signup`
2. In Supabase → **SQL Editor**, run (replace with your actual email):
   ```sql
   insert into platform_admins (user_id)
   select id from auth.users where email = 'your-email@example.com';
   ```
3. Visit `/admin` while logged in with that account

### Run the new migration
`0007_workspace_suspension.sql` in the SQL Editor, after 0001–0006.

### What's intentionally deferred
- Feature flags, template management, and detailed log viewers (the
  `admin_logs`/`audit_logs` tables exist and are being written to; a
  browsing UI for them is a small follow-up)
- Bulk actions (suspend multiple workspaces at once)

---

## Phase 9: Telegram Channel Integration

Added on top of Phases 1–8. The first live omnichannel connection — proves
the "all channels feed into the same conversation engine" architecture end
to end, using the channel abstraction the schema was already built for.

- **`/dashboard/agents/[agentId]/channels`** — paste a Telegram bot token,
  it's validated live against Telegram's API, a webhook is registered
  automatically, and the token is encrypted before it ever touches the
  database.
- **`src/lib/security/crypto.ts`** — AES-256-GCM encryption for any channel
  credential (this phase: Telegram bot tokens; the same function is ready
  for WhatsApp/Instagram/Messenger access tokens later).
- **Telegram webhook** (`/api/webhooks/telegram/[integrationId]`) — verified
  via Telegram's `secret_token` mechanism, then runs the message through
  the exact same building blocks as the website widget: trial/limit/handoff
  gates, the anti-hallucination system prompt, RAG retrieval, and CRM lead
  extraction — writing to the same `conversations`/`messages` tables, so a
  Telegram conversation shows up in the unified inbox exactly like a
  website one.
- Telegram conversations honor human handoff too — take one over from
  `/dashboard/inbox` and the bot goes silent there as well.

### One more thing YOU need for this phase
Generate an encryption key (needed before any channel can be connected):
```
openssl rand -base64 32
```
Add the result to `.env.local` as `ENCRYPTION_KEY=...`. If you don't have
`openssl` handy, any tool that generates 32 random bytes and base64-encodes
them works — the important part is 32 bytes, base64.

Then, to actually connect a bot: open Telegram, message **@BotFather**,
send `/newbot`, follow its prompts, and paste the token it gives you into
the Channels page. No Telegram developer account or approval process needed
— this is the one channel with essentially zero setup friction.

### Run the new migration
`0008_integration_agent_link.sql` in the SQL Editor, after 0001–0007.

### Why WhatsApp/Instagram/Messenger aren't built yet
These three genuinely require something only you can do: a **Meta Business
account**, app review, and (for WhatsApp) a verified phone number — Meta's
own approval process, not a technical blocker on my end. The architecture
is already shaped for them (same `integrations`/`integration_credentials`
tables, same channel enum, same conversation engine) — once you have a
Meta developer app and the relevant tokens, adding each one is the same
shape of work as this Telegram integration, not a redesign.

---

## Phase 10: Premium Landing Page

Added on top of Phases 1–9. Replaces the placeholder home page from Phase 1
with the full marketing page from spec section 3.

- **Arabic RTL / English LTR** — a language switcher persists the choice in
  a cookie, read server-side on every request, so the page renders with the
  correct `dir`/`lang` immediately (no flash of the wrong direction).
- **Dark / light mode** — persisted in `localStorage`, applied via a small
  blocking script before React hydrates (no flash of the wrong theme either).
- **Sections**: hero with the exact CTA copy from the spec ("ابدأ مجاناً
  لمدة 3 أيام" / "Start free for 3 days"), features, use-case tags for every
  business type listed in the spec, a pricing card pulled live from the
  `plans` table (so an admin price change from Phase 8 shows up here
  automatically), an FAQ accordion, and a testimonials placeholder section.
- Mobile-first, responsive, matches the rest of the app's Tailwind setup —
  no new design system introduced.

### Nothing new required from you for this phase
Pure frontend code — no new accounts, keys, or migrations.

### What's intentionally deferred
- Custom illustrations/animations beyond simple CSS (a licensed animation
  library or custom artwork is a design decision for you to make, not a
  technical blocker)
- Real testimonials (placeholder shown until you have actual customer quotes)
- A dedicated blog/content marketing section

---

## Phase 11: Agent Templates

Added on top of Phases 1–10 (spec section 33).

- **10 seeded templates** — restaurant, hotel, clinic, store, real estate,
  salon, gym, car dealership, school, and general service business — each
  with a suggested tone, greeting, system instructions, FAQ starting points,
  and lead-qualification questions relevant to that business type.
- **Onboarding now uses them automatically**: when a new workspace picks a
  business type that matches a template, the auto-created first agent
  starts with that template's tone/greeting/instructions/lead-questions
  instead of a generic blank slate — the business owner still edits
  everything afterward in the Agent Builder, same as before.
- If no template matches (or "أخرى / Other" is picked), onboarding falls
  back to the original generic behavior — nothing breaks for edge cases.

### Nothing new required from you for this phase
Pure data + a small onboarding change — no new accounts or app code shape
changes.

### Run the new migration
`0009_agent_templates_seed.sql` in the SQL Editor, after 0001–0008.

### What's intentionally deferred
- A template *picker* UI for applying/switching templates on an existing
  agent after onboarding (currently templates only apply at agent creation
  time during onboarding)
- The future template marketplace (spec section 34) — the schema already
  has `is_marketplace_item` and `created_by` on `agent_templates` ready for
  it, intentionally not built out further per the spec's own "don't
  overbuild this in the first release" note

---

## Phase 12: Analytics Dashboard

Added on top of Phases 1–11 (spec section 27).

- **`/dashboard/analytics`** — total conversations, total leads, qualified
  leads, and human-handoff count at a glance; a 6-month message-usage bar
  chart (via `recharts`) against the workspace's plan limit; and a
  conversations-by-channel breakdown (website, Telegram, and the
  not-yet-connected channels once they're live).
- All numbers come straight from tables that already exist and are already
  being written to by earlier phases (`usage`, `conversations`, `leads`) —
  nothing new to track, just a place to see it.

### Nothing new required from you for this phase
Pure code — no new accounts, keys, or migrations. `recharts` is a new
`package.json` dependency, picked up on your next `npm install`.

### What's intentionally deferred
- "Top questions" and detailed response-time statistics (spec section 27
  mentions these; they need either a categorization pass over message
  content or response-latency tracking, both reasonable but non-trivial
  follow-ups — noted here rather than silently skipped)
- Exportable reports (CSV/PDF)

---

## Phase 13: Referral System

Added on top of Phases 1–12 (spec section 31). The affiliate marketplace
(section 32) stays schema-only, per the spec's own instruction not to
overbuild it in the first release — the `affiliates` table is ready
whenever that's prioritized.

- Every workspace gets a unique `referral_code` (generated during
  onboarding) and a shareable link: `/signup?ref=CODE`.
- **`/dashboard/referrals`** — shows the link, referral history, and reward
  count.
- **Flow**: signup captures `?ref=` into the new user's metadata → onboarding
  looks up the referring workspace by code and logs a `referrals` row with
  status `signed_up` → when that new workspace's first payment succeeds
  (the Stripe webhook from Phase 7), the referrer automatically gets **30
  days added** to their trial or billing period, a notification is created,
  and the referral flips to `converted`.
- Reward logic lives in one function (`applyReferralRewardIfAny` in the
  billing webhook route) — the "free month" amount is a single constant
  there if you want to change it later, matching the spec's "configurable
  by admin" intent without needing a full admin UI for it yet.

### Nothing new required from you for this phase
Pure code + one migration — no new accounts or keys.

### Run the new migration
`0010_workspace_referral_code.sql` in the SQL Editor, after 0001–0009.

### What's intentionally deferred
- Admin UI to configure the reward amount/type (currently a code constant)
- The affiliate marketplace itself (schema exists, not built out — per spec)

---

## Phase 14: Google Calendar Integration

Added on top of Phases 1–13 (spec section 23). Full OAuth flow and calendar
actions are built; a Google Cloud OAuth app is the one thing only you can
create.

- **OAuth flow** (`/api/oauth/google/connect` → Google consent screen →
  `/api/oauth/google/callback`) — owner/admin-only, requests `offline`
  access so a refresh token is issued, which is encrypted with the same
  AES-256-GCM helper from Phase 9 before it touches the database.
- **`src/lib/google/calendar.ts`** — check availability (`freeBusy`),
  create, update, and cancel calendar events, all via Google's REST API
  directly (no heavy SDK needed).
- **Token handling**: rather than caching an access token and tracking its
  expiry, `getGoogleAccessToken()` refreshes on every use. Slightly more
  network calls, but it's a feature that isn't invoked on every chat
  message, and it eliminates an entire class of "token expired mid-call"
  bugs.
- **Connect button** in `/dashboard/agents/[agentId]/channels`.

### One thing YOU need for this phase
Create a Google Cloud OAuth app:
1. **https://console.cloud.google.com** → new project (or reuse one)
2. **APIs & Services → Library** → enable "Google Calendar API"
3. **APIs & Services → OAuth consent screen** → configure it (External is
   fine for testing; add your own email as a test user while it's not yet
   verified)
4. **APIs & Services → Credentials → Create Credentials → OAuth client ID**
   → type: Web application
   → Authorized redirect URI: `https://YOUR_DOMAIN/api/oauth/google/callback`
5. Copy the **Client ID** and **Client Secret** into `.env.local`:
   ```
   GOOGLE_CLIENT_ID=...
   GOOGLE_CLIENT_SECRET=...
   ```

Until these are set, clicking "ربط تقويم جوجل" shows a clear error instead
of failing silently — nothing else in the app is affected.

### What's intentionally deferred (and why it's a real design decision, not an oversight)
The AI agent **cannot yet invoke** calendar actions mid-conversation (e.g.
a customer saying "book me for 3pm Tuesday" and the agent actually doing
it). The calendar functions themselves are fully built and tested-shape —
what's missing is wiring them into the chat loop via real function-calling
(tool use), which is a meaningfully different architecture from the
lightweight lead-extraction approach used in Phase 6, and deserves its own
focused pass rather than being bolted on quickly here. Connecting the
calendar today means it's ready the moment that pass happens; it does not
yet make appointment booking talk-to-book.

Gmail sending (spec section 24) shares the same OAuth plumbing
(`buildGoogleAuthUrl({ scopes: ["gmail"] })` already supports it) but no
send-email action has been written yet — same "wire it into function
calling" deferral applies.

---

## Phase 15: Real Function-Calling / Tool-Use

Added on top of Phases 1–14 (spec section 22, and finally makes section 23
end-to-end). This is the piece flagged as deferred in Phase 14 — the AI can
now actually check availability and book appointments mid-conversation,
not just talk about doing so.

- **`AIProvider.completeWithTools`** (optional interface method,
  implemented by `Cloudflare Workers AIProvider`) — runs the full "model decides to call a
  function → we execute it → model gets the result → model answers"
  loop internally (capped at 4 rounds to guard against runaway calls),
  using Cloudflare Workers AI's native function-calling API.
- **`src/lib/chat/tools.ts`** — builds the exact list of tools available
  for a given turn. A tool is only ever offered to the model if BOTH the
  agent's `allowed_actions` includes it AND the underlying integration
  (Google Calendar) is actually connected — the model never sees a tool
  it can't really use.
- **Two tools shipped**: `check_calendar_availability` and
  `create_calendar_event`, both backed by the real Google Calendar
  functions from Phase 14.
- **Agent Builder** now has checkboxes to turn these on per agent, with a
  note that they're silently unavailable until Calendar is connected.
- **Current-time grounding**: when tools are active, the system prompt
  now includes the current date/time in the workspace's timezone, so the
  model can resolve "tomorrow at 3pm" into a real ISO datetime for the
  tool calls.
- **Wired into both live channels**: the website widget and Telegram.
  Tool-enabled turns run non-streaming internally (function-calling
  requires it) but the website route still sends the result through the
  same SSE contract the frontend already expects — no client-side changes
  needed. Every tool call is logged to `audit_logs` for traceability.

### Nothing new required from you for this phase
If you already connected Google Calendar in Phase 14, this works
immediately — just check the two boxes in an agent's builder page. No new
accounts, keys, or migrations.

### What's intentionally deferred
- Tools for other actions (send email via Gmail, generic webhook calls,
  notify-employee) — the same `ToolSet` pattern in `tools.ts` extends to
  these directly; only Calendar was built out as the concrete example
- Tool support for providers other than Cloudflare Workers AI (the interface method is
  optional specifically so this doesn't block adding a provider that
  doesn't support function calling)
- Streaming *during* tool execution (currently the whole tool-enabled turn
  waits, then sends one chunk — a partial "thinking..." indicator while
  tools run would be a nice follow-up but isn't required for correctness)

## Suggested next phase
The platform is now feature-complete against nearly all of the original
spec that doesn't require Meta Business verification. Reasonable next
steps: a visible "cancel subscription" button, a general polish pass
(loading states, error boundaries, empty states), or extending the tool
pattern to more actions (Gmail sending, webhooks, employee notifications).
