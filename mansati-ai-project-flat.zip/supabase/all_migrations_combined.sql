-- ============================================================================
-- Mansati AI — Core Schema (Migration 0001)
-- Multi-tenant AI Agent SaaS platform
-- ============================================================================
-- Design notes:
--  * "workspace" = tenant. Every business-owned row carries workspace_id.
--  * auth.users (Supabase Auth) is the source of truth for identity.
--  * profiles extends auth.users with app-level data (1:1).
--  * workspace_members maps users <-> workspaces with a role, enabling
--    multiple staff per business later without schema changes.
--  * RLS policies live in 0002_rls_policies.sql — this file is structure only.
-- ============================================================================

create extension if not exists "uuid-ossp";
create extension if not exists "pgcrypto";
create extension if not exists "vector"; -- pgvector, for document_chunks embeddings

-- ----------------------------------------------------------------------------
-- ENUMS
-- ----------------------------------------------------------------------------
create type workspace_role as enum ('owner', 'admin', 'agent_staff');
create type subscription_status as enum ('trialing', 'active', 'past_due', 'canceled', 'expired');
create type knowledge_source_type as enum ('pdf', 'docx', 'txt', 'csv', 'xlsx', 'website', 'manual_text');
create type document_status as enum ('pending', 'processing', 'ready', 'error');
create type conversation_channel as enum ('website', 'whatsapp', 'instagram', 'messenger', 'telegram');
create type conversation_status as enum ('ai_active', 'human_active', 'closed');
create type message_role as enum ('user', 'assistant', 'system', 'staff');
create type lead_status as enum ('new', 'interested', 'qualified', 'negotiation', 'won', 'lost');
create type integration_type as enum ('whatsapp', 'instagram', 'messenger', 'telegram', 'google_calendar', 'gmail');
create type automation_trigger_type as enum ('new_lead', 'appointment_requested', 'high_value_lead', 'conversation_handoff', 'custom');
create type plan_interval as enum ('month', 'year');

-- ----------------------------------------------------------------------------
-- PROFILES (extends auth.users)
-- ----------------------------------------------------------------------------
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  avatar_url text,
  preferred_language text not null default 'ar' check (preferred_language in ('ar', 'en')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- WORKSPACES (tenants)
-- ----------------------------------------------------------------------------
create table workspaces (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  slug text not null unique,
  business_type text,
  country text,
  preferred_language text not null default 'ar' check (preferred_language in ('ar', 'en')),
  business_description text,
  website_url text,
  logo_url text,
  timezone text not null default 'UTC',
  onboarding_completed boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table workspace_members (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role workspace_role not null default 'owner',
  created_at timestamptz not null default now(),
  unique (workspace_id, user_id)
);

-- ----------------------------------------------------------------------------
-- PLANS (admin-configurable, never hard-coded in app code)
-- ----------------------------------------------------------------------------
create table plans (
  id uuid primary key default uuid_generate_v4(),
  key text not null unique,               -- e.g. 'trial', 'pro'
  name text not null,
  price_cents integer not null default 0,
  currency text not null default 'USD',
  interval plan_interval not null default 'month',
  message_limit integer not null,         -- AI messages per period
  storage_limit_mb integer not null,
  agent_limit integer not null,
  file_limit integer not null,
  is_public boolean not null default true,
  is_active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- SUBSCRIPTIONS (billing-provider agnostic)
-- ----------------------------------------------------------------------------
create table subscriptions (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  plan_id uuid not null references plans(id),
  status subscription_status not null default 'trialing',
  billing_provider text,                  -- e.g. 'stripe', null while trialing
  provider_customer_id text,
  provider_subscription_id text,
  trial_started_at timestamptz not null default now(),
  trial_ends_at timestamptz not null default (now() + interval '3 days'),
  current_period_start timestamptz,
  current_period_end timestamptz,
  canceled_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (workspace_id)
);

-- ----------------------------------------------------------------------------
-- AGENT TEMPLATES (library + future marketplace)
-- ----------------------------------------------------------------------------
create table agent_templates (
  id uuid primary key default uuid_generate_v4(),
  key text not null unique,
  name text not null,
  business_type text not null,
  description text,
  suggested_system_instructions text,
  suggested_tone text,
  suggested_greeting text,
  suggested_faq jsonb not null default '[]',
  suggested_lead_questions jsonb not null default '[]',
  suggested_actions jsonb not null default '[]',
  is_marketplace_item boolean not null default false,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- AGENTS
-- ----------------------------------------------------------------------------
create table agents (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  template_id uuid references agent_templates(id),
  public_agent_id text not null unique default replace(uuid_generate_v4()::text, '-', ''),
  name text not null,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table agent_settings (
  agent_id uuid primary key references agents(id) on delete cascade,
  language text not null default 'ar',
  personality text,
  tone text,
  system_instructions text,
  welcome_message text,
  fallback_message text not null default 'عذراً، ما عندي معلومات مؤكدة عن هذا الموضوع. أقدر أحولك إلى موظف.',
  rules jsonb not null default '[]',
  lead_questions jsonb not null default '[]',
  handoff_triggers jsonb not null default '[]',
  allowed_actions jsonb not null default '[]',
  branding jsonb not null default '{}',
  ai_provider text not null default 'cloudflare',
  ai_model text,
  updated_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- KNOWLEDGE BASE
-- ----------------------------------------------------------------------------
create table knowledge_sources (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  agent_id uuid not null references agents(id) on delete cascade,
  type knowledge_source_type not null,
  source_url text,
  created_at timestamptz not null default now()
);

create table documents (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  knowledge_source_id uuid not null references knowledge_sources(id) on delete cascade,
  file_name text not null,
  file_type text,
  file_size_bytes bigint,
  storage_path text,
  status document_status not null default 'pending',
  error_message text,
  uploaded_at timestamptz not null default now(),
  processed_at timestamptz
);

create table document_chunks (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  document_id uuid not null references documents(id) on delete cascade,
  chunk_index integer not null,
  content text not null,
  embedding vector(1536),               -- requires pgvector extension
  created_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- CONVERSATIONS / MESSAGES
-- ----------------------------------------------------------------------------
create table contacts (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  name text,
  phone text,
  email text,
  source text,
  tags text[] not null default '{}',
  notes text,
  last_interaction_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table conversations (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  agent_id uuid not null references agents(id) on delete cascade,
  contact_id uuid references contacts(id) on delete set null,
  channel conversation_channel not null default 'website',
  status conversation_status not null default 'ai_active',
  assigned_staff_id uuid references auth.users(id),
  external_thread_id text,             -- id from WhatsApp/Telegram/etc.
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table messages (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  conversation_id uuid not null references conversations(id) on delete cascade,
  role message_role not null,
  content text not null,
  input_tokens integer,
  output_tokens integer,
  feedback smallint check (feedback in (-1, 0, 1)),
  created_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- CRM / LEADS
-- ----------------------------------------------------------------------------
create table leads (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  contact_id uuid not null references contacts(id) on delete cascade,
  conversation_id uuid references conversations(id) on delete set null,
  status lead_status not null default 'new',
  answers jsonb not null default '{}',   -- qualification Q&A
  value_estimate numeric,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table lead_events (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  lead_id uuid not null references leads(id) on delete cascade,
  event_type text not null,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- INTEGRATIONS (channels + Google)
-- ----------------------------------------------------------------------------
create table integrations (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  type integration_type not null,
  status text not null default 'disconnected',
  display_name text,
  metadata jsonb not null default '{}',   -- non-secret config (phone number id, page id, etc.)
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (workspace_id, type)
);

-- Secrets kept in a separate table so RLS + admin scoping can be tighter.
create table integration_credentials (
  id uuid primary key default uuid_generate_v4(),
  integration_id uuid not null references integrations(id) on delete cascade,
  encrypted_payload text not null,        -- encrypted at application layer before insert
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- AUTOMATIONS
-- ----------------------------------------------------------------------------
create table automations (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  name text not null,
  trigger_type automation_trigger_type not null,
  trigger_config jsonb not null default '{}',
  action_type text not null,
  action_config jsonb not null default '{}',
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table automation_runs (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  automation_id uuid not null references automations(id) on delete cascade,
  status text not null default 'pending',
  input jsonb not null default '{}',
  output jsonb not null default '{}',
  error_message text,
  ran_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- USAGE (source of truth for limits enforcement — never trust the frontend)
-- ----------------------------------------------------------------------------
create table usage (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  period_start date not null,
  period_end date not null,
  ai_messages_used integer not null default 0,
  input_tokens_used bigint not null default 0,
  output_tokens_used bigint not null default 0,
  storage_used_mb numeric not null default 0,
  documents_count integer not null default 0,
  agents_count integer not null default 0,
  integrations_count integer not null default 0,
  updated_at timestamptz not null default now(),
  unique (workspace_id, period_start)
);

-- ----------------------------------------------------------------------------
-- REFERRALS / AFFILIATES
-- ----------------------------------------------------------------------------
create table referrals (
  id uuid primary key default uuid_generate_v4(),
  referrer_workspace_id uuid not null references workspaces(id) on delete cascade,
  referred_workspace_id uuid references workspaces(id) on delete set null,
  code text not null unique,
  status text not null default 'pending',  -- pending, signed_up, converted, rewarded
  reward_type text,
  reward_value text,
  created_at timestamptz not null default now(),
  converted_at timestamptz
);

create table affiliates (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references auth.users(id) on delete cascade,
  referral_link_code text not null unique,
  visitors_count integer not null default 0,
  signups_count integer not null default 0,
  trials_count integer not null default 0,
  paid_conversions_count integer not null default 0,
  commission_owed_cents integer not null default 0,
  created_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- NOTIFICATIONS / AUDIT / ADMIN
-- ----------------------------------------------------------------------------
create table notifications (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  user_id uuid references auth.users(id) on delete cascade,
  type text not null,
  title text not null,
  body text,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table audit_logs (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid references workspaces(id) on delete cascade,
  actor_user_id uuid references auth.users(id),
  action text not null,
  target_table text,
  target_id uuid,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);

create table admin_logs (
  id uuid primary key default uuid_generate_v4(),
  admin_user_id uuid not null references auth.users(id),
  action text not null,
  target_workspace_id uuid references workspaces(id),
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);

-- Marks a user as a platform admin (separate from workspace roles).
create table platform_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- INDEXES
-- ----------------------------------------------------------------------------
create index idx_workspace_members_user on workspace_members(user_id);
create index idx_workspace_members_workspace on workspace_members(workspace_id);
create index idx_agents_workspace on agents(workspace_id);
create index idx_knowledge_sources_workspace on knowledge_sources(workspace_id);
create index idx_documents_workspace on documents(workspace_id);
create index idx_document_chunks_workspace on document_chunks(workspace_id);
create index idx_document_chunks_document on document_chunks(document_id);
create index idx_conversations_workspace on conversations(workspace_id);
create index idx_conversations_agent on conversations(agent_id);
create index idx_messages_workspace on messages(workspace_id);
create index idx_messages_conversation on messages(conversation_id);
create index idx_contacts_workspace on contacts(workspace_id);
create index idx_leads_workspace on leads(workspace_id);
create index idx_integrations_workspace on integrations(workspace_id);
create index idx_automations_workspace on automations(workspace_id);
create index idx_usage_workspace_period on usage(workspace_id, period_start);
create index idx_audit_logs_workspace on audit_logs(workspace_id);

-- ----------------------------------------------------------------------------
-- updated_at trigger helper
-- ----------------------------------------------------------------------------
create or replace function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

do $$
declare
  t text;
begin
  for t in select unnest(array[
    'profiles','workspaces','plans','subscriptions','agents','agent_settings',
    'contacts','conversations','leads','integrations','integration_credentials',
    'automations','usage'
  ])
  loop
    execute format('create trigger trg_set_updated_at before update on %I for each row execute function set_updated_at();', t);
  end loop;
end $$;

-- ----------------------------------------------------------------------------
-- Auto-create profile row on signup
-- ----------------------------------------------------------------------------
create or replace function handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, new.raw_user_meta_data->>'full_name');
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function handle_new_user();
-- ============================================================================
-- Mansati AI — Row Level Security (Migration 0002)
-- ============================================================================
-- Core principle: a row is visible/writable only if the requesting user is a
-- member of the workspace that owns it (workspace_members), or the user is a
-- platform_admin. Frontend checks are never trusted — this is the real gate.
--
-- Helper function `is_workspace_member(ws_id)` and `is_platform_admin()` keep
-- every policy short and consistent instead of repeating the join everywhere.
-- ============================================================================

create or replace function is_workspace_member(ws_id uuid)
returns boolean as $$
  select exists (
    select 1 from workspace_members
    where workspace_id = ws_id and user_id = auth.uid()
  );
$$ language sql security definer stable;

create or replace function is_workspace_admin_or_owner(ws_id uuid)
returns boolean as $$
  select exists (
    select 1 from workspace_members
    where workspace_id = ws_id and user_id = auth.uid()
      and role in ('owner', 'admin')
  );
$$ language sql security definer stable;

create or replace function is_platform_admin()
returns boolean as $$
  select exists (select 1 from platform_admins where user_id = auth.uid());
$$ language sql security definer stable;

-- Enable RLS everywhere. Nothing is readable/writable by default.
alter table profiles enable row level security;
alter table workspaces enable row level security;
alter table workspace_members enable row level security;
alter table plans enable row level security;
alter table subscriptions enable row level security;
alter table agent_templates enable row level security;
alter table agents enable row level security;
alter table agent_settings enable row level security;
alter table knowledge_sources enable row level security;
alter table documents enable row level security;
alter table document_chunks enable row level security;
alter table contacts enable row level security;
alter table conversations enable row level security;
alter table messages enable row level security;
alter table leads enable row level security;
alter table lead_events enable row level security;
alter table integrations enable row level security;
alter table integration_credentials enable row level security;
alter table automations enable row level security;
alter table automation_runs enable row level security;
alter table usage enable row level security;
alter table referrals enable row level security;
alter table affiliates enable row level security;
alter table notifications enable row level security;
alter table audit_logs enable row level security;
alter table admin_logs enable row level security;
alter table platform_admins enable row level security;

-- ----------------------------------------------------------------------------
-- PROFILES — a user can see/edit only their own profile
-- ----------------------------------------------------------------------------
create policy "profiles_select_own" on profiles for select using (id = auth.uid());
create policy "profiles_update_own" on profiles for update using (id = auth.uid());

-- ----------------------------------------------------------------------------
-- WORKSPACES — visible to members; created freely (signup/onboarding flow);
-- only owner/admin can update.
-- ----------------------------------------------------------------------------
create policy "workspaces_select_member" on workspaces for select
  using (is_workspace_member(id) or is_platform_admin());
create policy "workspaces_insert_authenticated" on workspaces for insert
  with check (auth.uid() is not null);
create policy "workspaces_update_admin" on workspaces for update
  using (is_workspace_admin_or_owner(id) or is_platform_admin());

-- ----------------------------------------------------------------------------
-- WORKSPACE_MEMBERS
-- ----------------------------------------------------------------------------
create policy "workspace_members_select" on workspace_members for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "workspace_members_insert_self_as_owner" on workspace_members for insert
  with check (user_id = auth.uid());
create policy "workspace_members_manage_admin" on workspace_members for update
  using (is_workspace_admin_or_owner(workspace_id));
create policy "workspace_members_delete_admin" on workspace_members for delete
  using (is_workspace_admin_or_owner(workspace_id));

-- ----------------------------------------------------------------------------
-- PLANS — public read (used on pricing page), admin-only write
-- ----------------------------------------------------------------------------
create policy "plans_select_public" on plans for select using (is_public and is_active);
create policy "plans_admin_all" on plans for all using (is_platform_admin());

-- ----------------------------------------------------------------------------
-- GENERIC WORKSPACE-SCOPED TABLES
-- Every table below follows the same shape: members can read; owner/admin can
-- write; platform admins can read everything for support/ops.
-- ----------------------------------------------------------------------------

-- SUBSCRIPTIONS
create policy "subscriptions_select" on subscriptions for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "subscriptions_write_admin" on subscriptions for all
  using (is_platform_admin());

-- AGENT_TEMPLATES: public library readable by everyone signed in; custom ones scoped to creator
create policy "agent_templates_select_public" on agent_templates for select
  using (not is_marketplace_item or created_by = auth.uid() or is_platform_admin());
create policy "agent_templates_admin_write" on agent_templates for all
  using (is_platform_admin());

-- AGENTS
create policy "agents_select" on agents for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "agents_insert" on agents for insert
  with check (is_workspace_admin_or_owner(workspace_id));
create policy "agents_update" on agents for update
  using (is_workspace_admin_or_owner(workspace_id));
create policy "agents_delete" on agents for delete
  using (is_workspace_admin_or_owner(workspace_id));

-- AGENT_SETTINGS (keyed by agent_id, so join through agents)
create policy "agent_settings_select" on agent_settings for select
  using (exists (select 1 from agents a where a.id = agent_id and is_workspace_member(a.workspace_id)));
create policy "agent_settings_write" on agent_settings for all
  using (exists (select 1 from agents a where a.id = agent_id and is_workspace_admin_or_owner(a.workspace_id)));

-- KNOWLEDGE_SOURCES / DOCUMENTS / DOCUMENT_CHUNKS
create policy "knowledge_sources_select" on knowledge_sources for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "knowledge_sources_write" on knowledge_sources for all
  using (is_workspace_admin_or_owner(workspace_id));

create policy "documents_select" on documents for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "documents_write" on documents for all
  using (is_workspace_admin_or_owner(workspace_id));

create policy "document_chunks_select" on document_chunks for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "document_chunks_write" on document_chunks for all
  using (is_workspace_admin_or_owner(workspace_id));

-- CONTACTS / CONVERSATIONS / MESSAGES / LEADS / LEAD_EVENTS
create policy "contacts_select" on contacts for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "contacts_write" on contacts for all
  using (is_workspace_member(workspace_id));

create policy "conversations_select" on conversations for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "conversations_write" on conversations for all
  using (is_workspace_member(workspace_id));

create policy "messages_select" on messages for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "messages_write" on messages for all
  using (is_workspace_member(workspace_id));

create policy "leads_select" on leads for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "leads_write" on leads for all
  using (is_workspace_member(workspace_id));

create policy "lead_events_select" on lead_events for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "lead_events_write" on lead_events for all
  using (is_workspace_member(workspace_id));

-- INTEGRATIONS — visible to members, but secrets table is locked down harder
create policy "integrations_select" on integrations for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "integrations_write" on integrations for all
  using (is_workspace_admin_or_owner(workspace_id));

-- integration_credentials: NEVER exposed to normal client reads.
-- Only accessible via service-role key from trusted server code, or platform admins.
create policy "integration_credentials_admin_only" on integration_credentials for all
  using (is_platform_admin());

-- AUTOMATIONS
create policy "automations_select" on automations for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "automations_write" on automations for all
  using (is_workspace_admin_or_owner(workspace_id));

create policy "automation_runs_select" on automation_runs for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "automation_runs_admin_write" on automation_runs for all
  using (is_platform_admin());

-- USAGE — read-only for members; only server (service role) or admin writes
create policy "usage_select" on usage for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "usage_admin_write" on usage for all
  using (is_platform_admin());

-- REFERRALS
create policy "referrals_select" on referrals for select
  using (is_workspace_member(referrer_workspace_id)
         or is_workspace_member(referred_workspace_id)
         or is_platform_admin());
create policy "referrals_admin_write" on referrals for all
  using (is_platform_admin());

-- AFFILIATES — user can see their own affiliate record
create policy "affiliates_select_own" on affiliates for select
  using (user_id = auth.uid() or is_platform_admin());
create policy "affiliates_admin_write" on affiliates for all
  using (is_platform_admin());

-- NOTIFICATIONS
create policy "notifications_select_own" on notifications for select
  using (user_id = auth.uid() or is_workspace_admin_or_owner(workspace_id));
create policy "notifications_admin_write" on notifications for all
  using (is_platform_admin());

-- AUDIT_LOGS / ADMIN_LOGS — read-only, admin-only (support/compliance)
create policy "audit_logs_admin_read" on audit_logs for select
  using (is_platform_admin() or is_workspace_admin_or_owner(workspace_id));
create policy "audit_logs_admin_write" on audit_logs for insert
  with check (is_platform_admin() or auth.uid() is not null);

create policy "admin_logs_admin_only" on admin_logs for all
  using (is_platform_admin());

create policy "platform_admins_admin_only" on platform_admins for all
  using (is_platform_admin());
-- ============================================================================
-- Mansati AI — Seed default plans (Migration 0003)
-- These are just the STARTING values. Admins can change price/limits anytime
-- from the Admin Panel (updates the `plans` table) — never hard-coded again.
-- ============================================================================

insert into plans (key, name, price_cents, currency, interval, message_limit, storage_limit_mb, agent_limit, file_limit, is_public, is_active, sort_order)
values
  ('trial', 'Free Trial', 0, 'USD', 'month', 100, 100, 1, 10, false, true, 0),
  ('basic', 'Mansati Basic', 500, 'USD', 'month', 3000, 1000, 3, 50, true, true, 1),
  ('pro', 'Mansati Pro', 1000, 'USD', 'month', 10000, 5000, 10, 100, true, true, 2)
on conflict (key) do nothing;
-- ============================================================================
-- Mansati AI — Usage tracking + limit enforcement (Migration 0004)
-- ============================================================================
-- Why a DB function instead of read-then-write from the app: two messages
-- arriving at the same moment must not both pass a limit check based on a
-- stale read. This function does the check-and-increment atomically inside
-- a single statement.
-- ============================================================================

create or replace function check_and_increment_usage(p_workspace_id uuid)
returns table (allowed boolean, messages_used integer, message_limit integer)
language plpgsql
security definer
as $$
declare
  v_period_start date := date_trunc('month', now())::date;
  v_period_end date := (date_trunc('month', now()) + interval '1 month - 1 day')::date;
  v_limit integer;
  v_used integer;
begin
  -- Resolve the workspace's current plan limit via its subscription.
  select p.message_limit into v_limit
  from subscriptions s
  join plans p on p.id = s.plan_id
  where s.workspace_id = p_workspace_id;

  if v_limit is null then
    -- No subscription/plan found — fail closed.
    return query select false, 0, 0;
    return;
  end if;

  -- Ensure a usage row exists for this workspace/period, then atomically
  -- increment only if under the limit (single UPDATE avoids the race).
  insert into usage (workspace_id, period_start, period_end, ai_messages_used)
  values (p_workspace_id, v_period_start, v_period_end, 0)
  on conflict (workspace_id, period_start) do nothing;

  update usage
  set ai_messages_used = ai_messages_used + 1,
      updated_at = now()
  where workspace_id = p_workspace_id
    and period_start = v_period_start
    and ai_messages_used < v_limit
  returning ai_messages_used into v_used;

  if v_used is null then
    -- Either the limit was already hit, or the row disappeared — report current count.
    select u.ai_messages_used into v_used
    from usage u
    where u.workspace_id = p_workspace_id and u.period_start = v_period_start;

    return query select false, coalesce(v_used, 0), v_limit;
    return;
  end if;

  return query select true, v_used, v_limit;
end;
$$;

-- Records token usage after a completion finishes (best-effort accounting,
-- separate from the pass/fail message-count gate above).
create or replace function record_token_usage(
  p_workspace_id uuid,
  p_input_tokens integer,
  p_output_tokens integer
)
returns void
language sql
security definer
as $$
  update usage
  set input_tokens_used = input_tokens_used + coalesce(p_input_tokens, 0),
      output_tokens_used = output_tokens_used + coalesce(p_output_tokens, 0),
      updated_at = now()
  where workspace_id = p_workspace_id
    and period_start = date_trunc('month', now())::date;
$$;
-- ============================================================================
-- Mansati AI — Knowledge retrieval (Migration 0005)
-- ============================================================================
-- Cosine-similarity search over document_chunks, scoped to a single agent's
-- knowledge sources. Called via the admin client from retrieveRelevantChunks()
-- (src/lib/chat/knowledge.ts) with the embedded user query.
-- ============================================================================

create index if not exists idx_document_chunks_embedding
  on document_chunks using ivfflat (embedding vector_cosine_ops) with (lists = 100);

create or replace function match_document_chunks(
  p_agent_id uuid,
  p_query_embedding vector(1536),
  p_match_count integer default 4
)
returns table (content text, similarity float)
language sql
stable
security definer
as $$
  select
    dc.content,
    1 - (dc.embedding <=> p_query_embedding) as similarity
  from document_chunks dc
  join documents d on d.id = dc.document_id
  join knowledge_sources ks on ks.id = d.knowledge_source_id
  where ks.agent_id = p_agent_id
    and d.status = 'ready'
  order by dc.embedding <=> p_query_embedding
  limit p_match_count;
$$;
-- ============================================================================
-- Mansati AI — Billing provider metadata (Migration 0006)
-- ============================================================================
-- Keeps the plans table provider-agnostic: a plan's price/limits are the
-- source of truth, and provider_metadata holds whatever ID/config a given
-- payment provider needs to charge for it (e.g. {"stripe": {"price_id": "..."}}).
-- Switching or adding a payment provider later never requires a schema change.
-- ============================================================================

alter table plans add column if not exists provider_metadata jsonb not null default '{}';
-- ============================================================================
-- Mansati AI — Workspace suspension flag (Migration 0007)
-- ============================================================================

alter table workspaces add column if not exists is_suspended boolean not null default false;
alter table workspaces add column if not exists suspended_reason text;
-- ============================================================================
-- Mansati AI — Integration -> agent linkage (Migration 0008)
-- ============================================================================
-- A workspace may eventually run multiple agents; each channel connection
-- (Telegram bot, WhatsApp number, etc.) needs to know which one answers it.

alter table integrations add column if not exists agent_id uuid references agents(id) on delete set null;
create index if not exists idx_integrations_agent on integrations(agent_id);

-- Needed for `upsert(..., { onConflict: "integration_id" })` when
-- (re)connecting a channel — one credentials row per integration.
alter table integration_credentials add constraint integration_credentials_integration_id_key unique (integration_id);
-- ============================================================================
-- Mansati AI — Agent template seeds (Migration 0009)
-- ============================================================================
-- Populates agent_templates (spec section 33) so onboarding can create a
-- meaningfully pre-configured agent instead of a blank one. Business owners
-- still edit everything afterward in the Agent Builder — these are starting
-- points, not locked-in behavior.
-- ============================================================================

insert into agent_templates (key, name, business_type, description, suggested_system_instructions, suggested_tone, suggested_greeting, suggested_faq, suggested_lead_questions, suggested_actions)
values
  (
    'restaurant', 'مطعم', 'restaurant',
    'قالب لمطاعم يجيب عن القائمة، الحجوزات، وأوقات الدوام.',
    'ساعد العملاء بمعلومات القائمة، الأسعار، أوقات الدوام، والحجوزات. اسأل عن عدد الأشخاص والوقت المفضل عند طلب حجز.',
    'ودود ومضياف',
    'أهلاً بك! هل تحتاج مساعدة في الحجز أو معرفة قائمة الطعام؟',
    '["ما هي أوقات الدوام؟", "هل يوجد توصيل؟", "هل يمكن الحجز لعدد كبير؟"]',
    '["كم عدد الأشخاص؟", "ما الوقت المفضل للحجز؟", "هل لديك أي حساسية غذائية؟"]',
    '["create_lead", "notify_employee"]'
  ),
  (
    'hotel', 'فندق', 'hotel',
    'قالب لفنادق يجيب عن الغرف، الأسعار، والحجوزات.',
    'ساعد الضيوف بمعلومات الغرف المتاحة، الأسعار، المرافق، وسياسة الإلغاء. اجمع تواريخ الوصول والمغادرة عند طلب حجز.',
    'راقٍ ومحترف',
    'مرحباً بك! كيف يمكنني مساعدتك في حجز إقامتك؟',
    '["ما هي أوقات تسجيل الدخول والخروج؟", "هل يوجد موقف سيارات؟", "ما سياسة الإلغاء؟"]',
    '["ما تاريخ الوصول والمغادرة؟", "كم عدد الضيوف؟", "هل تفضل نوع غرفة معين؟"]',
    '["create_lead", "check_calendar_availability"]'
  ),
  (
    'clinic', 'عيادة', 'clinic',
    'قالب لعيادات يساعد في حجز المواعيد والاستفسارات العامة.',
    'ساعد المرضى بمعلومات عامة عن الخدمات وأوقات الدوام، واجمع بيانات حجز الموعد. لا تقدم أي استشارة أو تشخيص طبي أبداً — أحل أي سؤال طبي مباشرة لموظف بشري.',
    'مطمئن ومهني',
    'مرحباً بك، كيف يمكنني مساعدتك في حجز موعدك اليوم؟',
    '["كيف أحجز موعداً؟", "هل تقبلون التأمين الصحي؟", "ما هي التخصصات المتوفرة؟"]',
    '["ما التخصص الذي تريد زيارته؟", "ما الوقت المفضل للموعد؟", "هل هذه زيارتك الأولى؟"]',
    '["create_lead", "check_calendar_availability", "transfer_conversation"]'
  ),
  (
    'store', 'متجر', 'store',
    'قالب لمتاجر يجيب عن المنتجات، الأسعار، والشحن.',
    'ساعد العملاء بمعلومات المنتجات، توفرها، الأسعار، وسياسة الشحن والإرجاع.',
    'ودود ومباشر',
    'أهلاً! أي منتج تبحث عنه اليوم؟',
    '["كم مدة التوصيل؟", "هل يمكن الإرجاع أو الاستبدال؟", "هل تشحنون خارج المدينة؟"]',
    '["ما المنتج الذي تهتم به؟", "ما ميزانيتك التقريبية؟"]',
    '["create_lead"]'
  ),
  (
    'real_estate', 'عقارات', 'real_estate',
    'قالب لمكاتب عقارية يجمع تفضيلات الباحثين عن عقار.',
    'ساعد العملاء بمعلومات عن العقارات المتوفرة واجمع تفضيلاتهم لتحويلها لفريق المبيعات.',
    'محترف وموثوق',
    'مرحباً! هل تبحث عن عقار للبيع أو للإيجار؟',
    '["ما المناطق المتوفرة لديكم؟", "هل تتعاملون مع التمويل العقاري؟"]',
    '["هل تبحث عن شراء أم إيجار؟", "ما الميزانية التقريبية؟", "ما المنطقة المفضلة؟"]',
    '["create_lead", "notify_employee"]'
  ),
  (
    'salon', 'صالون', 'salon',
    'قالب لصالونات التجميل والحلاقة لحجز المواعيد.',
    'ساعد العملاء بمعلومات الخدمات والأسعار، واجمع تفاصيل حجز الموعد.',
    'ودود وعصري',
    'أهلاً بك! أي خدمة تحتاجها اليوم؟',
    '["ما هي الخدمات المتوفرة؟", "كم سعر قص الشعر؟", "هل يمكن الحجز اليوم؟"]',
    '["ما الخدمة التي تريدها؟", "ما الوقت المفضل؟"]',
    '["create_lead", "check_calendar_availability"]'
  ),
  (
    'gym', 'نادي رياضي', 'gym',
    'قالب لأندية رياضية يجيب عن الاشتراكات والحصص.',
    'ساعد العملاء بمعلومات الاشتراكات، الحصص الرياضية، وأوقات الدوام.',
    'حماسي ومحفز',
    'أهلاً بطلك! كيف أقدر أساعدك في رحلتك الرياضية؟',
    '["ما أسعار الاشتراكات؟", "هل يوجد مدرب شخصي؟", "ما أوقات الدوام؟"]',
    '["ما هدفك الرياضي؟", "هل جربت الاشتراك من قبل؟"]',
    '["create_lead"]'
  ),
  (
    'car_dealership', 'معرض سيارات', 'car_dealership',
    'قالب لمعارض السيارات يجمع تفضيلات المشترين.',
    'ساعد العملاء بمعلومات السيارات المتوفرة، الأسعار، وخيارات التمويل.',
    'محترف وواثق',
    'أهلاً بك! أي نوع سيارة تبحث عنه؟',
    '["هل تقبلون التقسيط؟", "هل يوجد ضمان على السيارات؟"]',
    '["ما نوع السيارة المفضل؟", "ما الميزانية التقريبية؟", "نقداً أم تقسيط؟"]',
    '["create_lead", "notify_employee"]'
  ),
  (
    'school', 'مدرسة / معهد', 'school',
    'قالب لمدارس ومعاهد يجيب عن التسجيل والمناهج.',
    'ساعد أولياء الأمور والطلاب بمعلومات التسجيل، المناهج، والرسوم الدراسية.',
    'ودود ومطمئن',
    'مرحباً! هل تحتاج مساعدة في التسجيل أو الاستفسار عن برامجنا؟',
    '["ما هي الرسوم الدراسية؟", "ما مواعيد التسجيل؟", "هل يوجد سكن للطلاب؟"]',
    '["ما البرنامج الذي تهتم به؟", "ما المرحلة الدراسية؟"]',
    '["create_lead", "notify_employee"]'
  ),
  (
    'service_business', 'أعمال خدمية', 'service_business',
    'قالب عام لشركات الخدمات (صيانة، تنظيف، استشارات، إلخ).',
    'ساعد العملاء بمعلومات الخدمات المقدمة، الأسعار التقريبية، ومواعيد التنفيذ.',
    'محترف ومتعاون',
    'أهلاً بك! كيف يمكنني مساعدتك اليوم؟',
    '["ما الخدمات التي تقدمونها؟", "كم تستغرق الخدمة عادة؟"]',
    '["ما الخدمة التي تحتاجها؟", "متى تحتاج الخدمة؟"]',
    '["create_lead", "notify_employee"]'
  )
on conflict (key) do nothing;
-- ============================================================================
-- Mansati AI — Workspace referral code (Migration 0010)
-- ============================================================================

alter table workspaces add column if not exists referral_code text unique;
-- ============================================================================
-- Mansati AI — Agent webhook URL (Migration 0011)
-- ============================================================================
-- Supports the generic "trigger_webhook" action (spec section 22: "call an
-- API", "trigger webhook") without needing a whole webhook-management UI —
-- one configurable URL per agent is enough for the common case (notify an
-- external system, e.g. a CRM or Zapier, when the AI decides to).

alter table agent_settings add column if not exists webhook_url text;

-- ============================================================================
-- Mansati AI — Cloudflare AI migration + reply-only usage limits (Migration 0012)
-- ============================================================================
-- Mansati AI — Cloudflare AI migration + reply-only usage limits
-- Convert an older database where only the legacy $5 `pro` row exists.
-- On a fresh database the correct Basic/Pro rows already exist, so this is skipped.
do $$
begin
  if not exists (select 1 from plans where key = 'basic') then
    update plans
    set key = 'basic',
        name = 'Mansati Basic',
        price_cents = 500,
        message_limit = 3000,
        is_public = true,
        is_active = true,
        sort_order = 1
    where key = 'pro';
  end if;
end $$;

insert into plans (key, name, price_cents, currency, interval, message_limit, storage_limit_mb, agent_limit, file_limit, is_public, is_active, sort_order)
values ('basic', 'Mansati Basic', 500, 'USD', 'month', 3000, 1000, 3, 50, true, true, 1)
on conflict (key) do update set
  name = excluded.name,
  price_cents = excluded.price_cents,
  message_limit = excluded.message_limit,
  storage_limit_mb = excluded.storage_limit_mb,
  agent_limit = excluded.agent_limit,
  file_limit = excluded.file_limit,
  is_public = excluded.is_public,
  is_active = excluded.is_active,
  sort_order = excluded.sort_order;

insert into plans (key, name, price_cents, currency, interval, message_limit, storage_limit_mb, agent_limit, file_limit, is_public, is_active, sort_order)
values ('pro', 'Mansati Pro', 1000, 'USD', 'month', 10000, 5000, 10, 100, true, true, 2)
on conflict (key) do update set
  name = excluded.name,
  price_cents = excluded.price_cents,
  message_limit = excluded.message_limit,
  storage_limit_mb = excluded.storage_limit_mb,
  agent_limit = excluded.agent_limit,
  file_limit = excluded.file_limit,
  is_public = excluded.is_public,
  is_active = excluded.is_active,
  sort_order = excluded.sort_order;

-- All existing agents use Cloudflare AI after migration.
update agent_settings
set ai_provider = 'cloudflare',
    ai_model = '@cf/meta/llama-3.2-1b-instruct'
where ai_provider is distinct from 'cloudflare'
   or ai_model is null
   or ai_model like 'gemini%';

-- Cloudflare EmbeddingGemma returns 768-dimensional vectors. Existing Gemini
-- 1536d vectors cannot be mixed with the new model, so clear old vectors and
-- let document re-processing regenerate them with Cloudflare.
drop index if exists idx_document_chunks_embedding;
update document_chunks set embedding = null;
alter table document_chunks
  alter column embedding type vector(768)
  using null::vector(768);

create index if not exists idx_document_chunks_embedding
  on document_chunks using ivfflat (embedding vector_cosine_ops) with (lists = 100);

create or replace function match_document_chunks(
  p_agent_id uuid,
  p_query_embedding vector(768),
  p_match_count integer default 4
)
returns table (content text, similarity float)
language sql
stable
security definer
as $$
  select
    dc.content,
    1 - (dc.embedding <=> p_query_embedding) as similarity
  from document_chunks dc
  join documents d on d.id = dc.document_id
  join knowledge_sources ks on ks.id = d.knowledge_source_id
  where ks.agent_id = p_agent_id
    and d.status = 'ready'
    and dc.embedding is not null
  order by dc.embedding <=> p_query_embedding
  limit p_match_count;
$$;

-- Keep the existing function name for compatibility, but treat it as a
-- server-side reservation. A failed AI generation must release the slot.
create or replace function check_and_increment_usage(p_workspace_id uuid)
returns table (allowed boolean, messages_used integer, message_limit integer)
language plpgsql
security definer
as $$
declare
  v_period_start date := date_trunc('month', now())::date;
  v_period_end date := (date_trunc('month', now()) + interval '1 month - 1 day')::date;
  v_limit integer;
  v_used integer;
begin
  select p.message_limit into v_limit
  from subscriptions s
  join plans p on p.id = s.plan_id
  where s.workspace_id = p_workspace_id
    and (s.status = 'trialing' or s.status = 'active');

  if v_limit is null then
    return query select false, 0, 0;
    return;
  end if;

  insert into usage (workspace_id, period_start, period_end, ai_messages_used)
  values (p_workspace_id, v_period_start, v_period_end, 0)
  on conflict (workspace_id, period_start) do nothing;

  update usage
  set ai_messages_used = ai_messages_used + 1,
      updated_at = now()
  where workspace_id = p_workspace_id
    and period_start = v_period_start
    and ai_messages_used < v_limit
  returning ai_messages_used into v_used;

  if v_used is null then
    select u.ai_messages_used into v_used
    from usage u
    where u.workspace_id = p_workspace_id and u.period_start = v_period_start;
    return query select false, coalesce(v_used, 0), v_limit;
    return;
  end if;

  return query select true, v_used, v_limit;
end;
$$;

create or replace function release_ai_reply_usage(p_workspace_id uuid)
returns void
language sql
security definer
as $$
  update usage
  set ai_messages_used = greatest(ai_messages_used - 1, 0),
      updated_at = now()
  where workspace_id = p_workspace_id
    and period_start = date_trunc('month', now())::date
    and ai_messages_used > 0;
$$;

-- Token accounting remains internal analytics only; it is never shown to the customer.
