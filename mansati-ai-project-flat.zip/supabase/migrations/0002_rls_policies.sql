-- ============================================================================
-- Mansati AI — Row Level Security (Migration 0002)
-- ============================================================================
-- Core principle: a row is visible/writable only if the requesting user is a
-- member of the workspace that owns it (workspace_members), or the user is a
-- platform_admin. Frontend checks are never trusted — this is the real gate.
--
-- Helper function `is_workspace_member(ws_id)` and `is_platform_admin()` keep
-- every policy short and consistent instead of repeating the join everywhere.
-- ============================================================================

create or replace function is_workspace_member(ws_id uuid)
returns boolean as $$
  select exists (
    select 1 from workspace_members
    where workspace_id = ws_id and user_id = auth.uid()
  );
$$ language sql security definer stable;

create or replace function is_workspace_admin_or_owner(ws_id uuid)
returns boolean as $$
  select exists (
    select 1 from workspace_members
    where workspace_id = ws_id and user_id = auth.uid()
      and role in ('owner', 'admin')
  );
$$ language sql security definer stable;

create or replace function is_platform_admin()
returns boolean as $$
  select exists (select 1 from platform_admins where user_id = auth.uid());
$$ language sql security definer stable;

-- Enable RLS everywhere. Nothing is readable/writable by default.
alter table profiles enable row level security;
alter table workspaces enable row level security;
alter table workspace_members enable row level security;
alter table plans enable row level security;
alter table subscriptions enable row level security;
alter table agent_templates enable row level security;
alter table agents enable row level security;
alter table agent_settings enable row level security;
alter table knowledge_sources enable row level security;
alter table documents enable row level security;
alter table document_chunks enable row level security;
alter table contacts enable row level security;
alter table conversations enable row level security;
alter table messages enable row level security;
alter table leads enable row level security;
alter table lead_events enable row level security;
alter table integrations enable row level security;
alter table integration_credentials enable row level security;
alter table automations enable row level security;
alter table automation_runs enable row level security;
alter table usage enable row level security;
alter table referrals enable row level security;
alter table affiliates enable row level security;
alter table notifications enable row level security;
alter table audit_logs enable row level security;
alter table admin_logs enable row level security;
alter table platform_admins enable row level security;

-- ----------------------------------------------------------------------------
-- PROFILES — a user can see/edit only their own profile
-- ----------------------------------------------------------------------------
create policy "profiles_select_own" on profiles for select using (id = auth.uid());
create policy "profiles_update_own" on profiles for update using (id = auth.uid());

-- ----------------------------------------------------------------------------
-- WORKSPACES — visible to members; created freely (signup/onboarding flow);
-- only owner/admin can update.
-- ----------------------------------------------------------------------------
create policy "workspaces_select_member" on workspaces for select
  using (is_workspace_member(id) or is_platform_admin());
create policy "workspaces_insert_authenticated" on workspaces for insert
  with check (auth.uid() is not null);
create policy "workspaces_update_admin" on workspaces for update
  using (is_workspace_admin_or_owner(id) or is_platform_admin());

-- ----------------------------------------------------------------------------
-- WORKSPACE_MEMBERS
-- ----------------------------------------------------------------------------
create policy "workspace_members_select" on workspace_members for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "workspace_members_insert_self_as_owner" on workspace_members for insert
  with check (user_id = auth.uid());
create policy "workspace_members_manage_admin" on workspace_members for update
  using (is_workspace_admin_or_owner(workspace_id));
create policy "workspace_members_delete_admin" on workspace_members for delete
  using (is_workspace_admin_or_owner(workspace_id));

-- ----------------------------------------------------------------------------
-- PLANS — public read (used on pricing page), admin-only write
-- ----------------------------------------------------------------------------
create policy "plans_select_public" on plans for select using (is_public and is_active);
create policy "plans_admin_all" on plans for all using (is_platform_admin());

-- ----------------------------------------------------------------------------
-- GENERIC WORKSPACE-SCOPED TABLES
-- Every table below follows the same shape: members can read; owner/admin can
-- write; platform admins can read everything for support/ops.
-- ----------------------------------------------------------------------------

-- SUBSCRIPTIONS
create policy "subscriptions_select" on subscriptions for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "subscriptions_write_admin" on subscriptions for all
  using (is_platform_admin());

-- AGENT_TEMPLATES: public library readable by everyone signed in; custom ones scoped to creator
create policy "agent_templates_select_public" on agent_templates for select
  using (not is_marketplace_item or created_by = auth.uid() or is_platform_admin());
create policy "agent_templates_admin_write" on agent_templates for all
  using (is_platform_admin());

-- AGENTS
create policy "agents_select" on agents for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "agents_insert" on agents for insert
  with check (is_workspace_admin_or_owner(workspace_id));
create policy "agents_update" on agents for update
  using (is_workspace_admin_or_owner(workspace_id));
create policy "agents_delete" on agents for delete
  using (is_workspace_admin_or_owner(workspace_id));

-- AGENT_SETTINGS (keyed by agent_id, so join through agents)
create policy "agent_settings_select" on agent_settings for select
  using (exists (select 1 from agents a where a.id = agent_id and is_workspace_member(a.workspace_id)));
create policy "agent_settings_write" on agent_settings for all
  using (exists (select 1 from agents a where a.id = agent_id and is_workspace_admin_or_owner(a.workspace_id)));

-- KNOWLEDGE_SOURCES / DOCUMENTS / DOCUMENT_CHUNKS
create policy "knowledge_sources_select" on knowledge_sources for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "knowledge_sources_write" on knowledge_sources for all
  using (is_workspace_admin_or_owner(workspace_id));

create policy "documents_select" on documents for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "documents_write" on documents for all
  using (is_workspace_admin_or_owner(workspace_id));

create policy "document_chunks_select" on document_chunks for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "document_chunks_write" on document_chunks for all
  using (is_workspace_admin_or_owner(workspace_id));

-- CONTACTS / CONVERSATIONS / MESSAGES / LEADS / LEAD_EVENTS
create policy "contacts_select" on contacts for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "contacts_write" on contacts for all
  using (is_workspace_member(workspace_id));

create policy "conversations_select" on conversations for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "conversations_write" on conversations for all
  using (is_workspace_member(workspace_id));

create policy "messages_select" on messages for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "messages_write" on messages for all
  using (is_workspace_member(workspace_id));

create policy "leads_select" on leads for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "leads_write" on leads for all
  using (is_workspace_member(workspace_id));

create policy "lead_events_select" on lead_events for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "lead_events_write" on lead_events for all
  using (is_workspace_member(workspace_id));

-- INTEGRATIONS — visible to members, but secrets table is locked down harder
create policy "integrations_select" on integrations for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "integrations_write" on integrations for all
  using (is_workspace_admin_or_owner(workspace_id));

-- integration_credentials: NEVER exposed to normal client reads.
-- Only accessible via service-role key from trusted server code, or platform admins.
create policy "integration_credentials_admin_only" on integration_credentials for all
  using (is_platform_admin());

-- AUTOMATIONS
create policy "automations_select" on automations for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "automations_write" on automations for all
  using (is_workspace_admin_or_owner(workspace_id));

create policy "automation_runs_select" on automation_runs for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "automation_runs_admin_write" on automation_runs for all
  using (is_platform_admin());

-- USAGE — read-only for members; only server (service role) or admin writes
create policy "usage_select" on usage for select
  using (is_workspace_member(workspace_id) or is_platform_admin());
create policy "usage_admin_write" on usage for all
  using (is_platform_admin());

-- REFERRALS
create policy "referrals_select" on referrals for select
  using (is_workspace_member(referrer_workspace_id)
         or is_workspace_member(referred_workspace_id)
         or is_platform_admin());
create policy "referrals_admin_write" on referrals for all
  using (is_platform_admin());

-- AFFILIATES — user can see their own affiliate record
create policy "affiliates_select_own" on affiliates for select
  using (user_id = auth.uid() or is_platform_admin());
create policy "affiliates_admin_write" on affiliates for all
  using (is_platform_admin());

-- NOTIFICATIONS
create policy "notifications_select_own" on notifications for select
  using (user_id = auth.uid() or is_workspace_admin_or_owner(workspace_id));
create policy "notifications_admin_write" on notifications for all
  using (is_platform_admin());

-- AUDIT_LOGS / ADMIN_LOGS — read-only, admin-only (support/compliance)
create policy "audit_logs_admin_read" on audit_logs for select
  using (is_platform_admin() or is_workspace_admin_or_owner(workspace_id));
create policy "audit_logs_admin_write" on audit_logs for insert
  with check (is_platform_admin() or auth.uid() is not null);

create policy "admin_logs_admin_only" on admin_logs for all
  using (is_platform_admin());

create policy "platform_admins_admin_only" on platform_admins for all
  using (is_platform_admin());
