-- ============================================================================
-- Mansati AI — Knowledge retrieval (Migration 0005)
-- ============================================================================
-- Cosine-similarity search over document_chunks, scoped to a single agent's
-- knowledge sources. Called via the admin client from retrieveRelevantChunks()
-- (src/lib/chat/knowledge.ts) with the embedded user query.
-- ============================================================================

create index if not exists idx_document_chunks_embedding
  on document_chunks using ivfflat (embedding vector_cosine_ops) with (lists = 100);

create or replace function match_document_chunks(
  p_agent_id uuid,
  p_query_embedding vector(1536),
  p_match_count integer default 4
)
returns table (content text, similarity float)
language sql
stable
security definer
as $$
  select
    dc.content,
    1 - (dc.embedding <=> p_query_embedding) as similarity
  from document_chunks dc
  join documents d on d.id = dc.document_id
  join knowledge_sources ks on ks.id = d.knowledge_source_id
  where ks.agent_id = p_agent_id
    and d.status = 'ready'
  order by dc.embedding <=> p_query_embedding
  limit p_match_count;
$$;
