-- ============================================================================
-- Mansati AI — Usage tracking + limit enforcement (Migration 0004)
-- ============================================================================
-- Why a DB function instead of read-then-write from the app: two messages
-- arriving at the same moment must not both pass a limit check based on a
-- stale read. This function does the check-and-increment atomically inside
-- a single statement.
-- ============================================================================

create or replace function check_and_increment_usage(p_workspace_id uuid)
returns table (allowed boolean, messages_used integer, message_limit integer)
language plpgsql
security definer
as $$
declare
  v_period_start date := date_trunc('month', now())::date;
  v_period_end date := (date_trunc('month', now()) + interval '1 month - 1 day')::date;
  v_limit integer;
  v_used integer;
begin
  -- Resolve the workspace's current plan limit via its subscription.
  select p.message_limit into v_limit
  from subscriptions s
  join plans p on p.id = s.plan_id
  where s.workspace_id = p_workspace_id;

  if v_limit is null then
    -- No subscription/plan found — fail closed.
    return query select false, 0, 0;
    return;
  end if;

  -- Ensure a usage row exists for this workspace/period, then atomically
  -- increment only if under the limit (single UPDATE avoids the race).
  insert into usage (workspace_id, period_start, period_end, ai_messages_used)
  values (p_workspace_id, v_period_start, v_period_end, 0)
  on conflict (workspace_id, period_start) do nothing;

  update usage
  set ai_messages_used = ai_messages_used + 1,
      updated_at = now()
  where workspace_id = p_workspace_id
    and period_start = v_period_start
    and ai_messages_used < v_limit
  returning ai_messages_used into v_used;

  if v_used is null then
    -- Either the limit was already hit, or the row disappeared — report current count.
    select u.ai_messages_used into v_used
    from usage u
    where u.workspace_id = p_workspace_id and u.period_start = v_period_start;

    return query select false, coalesce(v_used, 0), v_limit;
    return;
  end if;

  return query select true, v_used, v_limit;
end;
$$;

-- Records token usage after a completion finishes (best-effort accounting,
-- separate from the pass/fail message-count gate above).
create or replace function record_token_usage(
  p_workspace_id uuid,
  p_input_tokens integer,
  p_output_tokens integer
)
returns void
language sql
security definer
as $$
  update usage
  set input_tokens_used = input_tokens_used + coalesce(p_input_tokens, 0),
      output_tokens_used = output_tokens_used + coalesce(p_output_tokens, 0),
      updated_at = now()
  where workspace_id = p_workspace_id
    and period_start = date_trunc('month', now())::date;
$$;
