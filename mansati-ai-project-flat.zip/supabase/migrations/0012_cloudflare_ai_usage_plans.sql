-- Mansati AI — Cloudflare AI migration + reply-only usage limits
-- Basic: $5 / 3,000 AI replies per month
-- Pro:   $10 / 10,000 AI replies per month
-- Customer questions and human replies are never counted.

-- Convert an older database where only the legacy $5 `pro` row exists.
-- On a fresh database the correct Basic/Pro rows already exist, so this is skipped.
do $$
begin
  if not exists (select 1 from plans where key = 'basic') then
    update plans
    set key = 'basic',
        name = 'Mansati Basic',
        price_cents = 500,
        message_limit = 3000,
        is_public = true,
        is_active = true,
        sort_order = 1
    where key = 'pro';
  end if;
end $$;

insert into plans (key, name, price_cents, currency, interval, message_limit, storage_limit_mb, agent_limit, file_limit, is_public, is_active, sort_order)
values ('basic', 'Mansati Basic', 500, 'USD', 'month', 3000, 1000, 3, 50, true, true, 1)
on conflict (key) do update set
  name = excluded.name,
  price_cents = excluded.price_cents,
  message_limit = excluded.message_limit,
  storage_limit_mb = excluded.storage_limit_mb,
  agent_limit = excluded.agent_limit,
  file_limit = excluded.file_limit,
  is_public = excluded.is_public,
  is_active = excluded.is_active,
  sort_order = excluded.sort_order;

insert into plans (key, name, price_cents, currency, interval, message_limit, storage_limit_mb, agent_limit, file_limit, is_public, is_active, sort_order)
values ('pro', 'Mansati Pro', 1000, 'USD', 'month', 10000, 5000, 10, 100, true, true, 2)
on conflict (key) do update set
  name = excluded.name,
  price_cents = excluded.price_cents,
  message_limit = excluded.message_limit,
  storage_limit_mb = excluded.storage_limit_mb,
  agent_limit = excluded.agent_limit,
  file_limit = excluded.file_limit,
  is_public = excluded.is_public,
  is_active = excluded.is_active,
  sort_order = excluded.sort_order;

-- All existing agents use Cloudflare AI after migration.
update agent_settings
set ai_provider = 'cloudflare',
    ai_model = '@cf/meta/llama-3.2-1b-instruct'
where ai_provider is distinct from 'cloudflare'
   or ai_model is null
   or ai_model like 'gemini%';

-- Cloudflare EmbeddingGemma returns 768-dimensional vectors. Existing Gemini
-- 1536d vectors cannot be mixed with the new model, so clear old vectors and
-- let document re-processing regenerate them with Cloudflare.
drop index if exists idx_document_chunks_embedding;
update document_chunks set embedding = null;
alter table document_chunks
  alter column embedding type vector(768)
  using null::vector(768);

create index if not exists idx_document_chunks_embedding
  on document_chunks using ivfflat (embedding vector_cosine_ops) with (lists = 100);

create or replace function match_document_chunks(
  p_agent_id uuid,
  p_query_embedding vector(768),
  p_match_count integer default 4
)
returns table (content text, similarity float)
language sql
stable
security definer
as $$
  select
    dc.content,
    1 - (dc.embedding <=> p_query_embedding) as similarity
  from document_chunks dc
  join documents d on d.id = dc.document_id
  join knowledge_sources ks on ks.id = d.knowledge_source_id
  where ks.agent_id = p_agent_id
    and d.status = 'ready'
    and dc.embedding is not null
  order by dc.embedding <=> p_query_embedding
  limit p_match_count;
$$;

-- Keep the existing function name for compatibility, but treat it as a
-- server-side reservation. A failed AI generation must release the slot.
create or replace function check_and_increment_usage(p_workspace_id uuid)
returns table (allowed boolean, messages_used integer, message_limit integer)
language plpgsql
security definer
as $$
declare
  v_period_start date := date_trunc('month', now())::date;
  v_period_end date := (date_trunc('month', now()) + interval '1 month - 1 day')::date;
  v_limit integer;
  v_used integer;
begin
  select p.message_limit into v_limit
  from subscriptions s
  join plans p on p.id = s.plan_id
  where s.workspace_id = p_workspace_id
    and (s.status = 'trialing' or s.status = 'active');

  if v_limit is null then
    return query select false, 0, 0;
    return;
  end if;

  insert into usage (workspace_id, period_start, period_end, ai_messages_used)
  values (p_workspace_id, v_period_start, v_period_end, 0)
  on conflict (workspace_id, period_start) do nothing;

  update usage
  set ai_messages_used = ai_messages_used + 1,
      updated_at = now()
  where workspace_id = p_workspace_id
    and period_start = v_period_start
    and ai_messages_used < v_limit
  returning ai_messages_used into v_used;

  if v_used is null then
    select u.ai_messages_used into v_used
    from usage u
    where u.workspace_id = p_workspace_id and u.period_start = v_period_start;
    return query select false, coalesce(v_used, 0), v_limit;
    return;
  end if;

  return query select true, v_used, v_limit;
end;
$$;

create or replace function release_ai_reply_usage(p_workspace_id uuid)
returns void
language sql
security definer
as $$
  update usage
  set ai_messages_used = greatest(ai_messages_used - 1, 0),
      updated_at = now()
  where workspace_id = p_workspace_id
    and period_start = date_trunc('month', now())::date
    and ai_messages_used > 0;
$$;

-- Token accounting remains internal analytics only; it is never shown to the customer.
