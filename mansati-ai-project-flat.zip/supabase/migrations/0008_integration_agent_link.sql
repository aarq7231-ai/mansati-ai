-- ============================================================================
-- Mansati AI — Integration -> agent linkage (Migration 0008)
-- ============================================================================
-- A workspace may eventually run multiple agents; each channel connection
-- (Telegram bot, WhatsApp number, etc.) needs to know which one answers it.

alter table integrations add column if not exists agent_id uuid references agents(id) on delete set null;
create index if not exists idx_integrations_agent on integrations(agent_id);

-- Needed for `upsert(..., { onConflict: "integration_id" })` when
-- (re)connecting a channel — one credentials row per integration.
alter table integration_credentials add constraint integration_credentials_integration_id_key unique (integration_id);
