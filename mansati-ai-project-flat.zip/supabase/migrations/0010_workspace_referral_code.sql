-- ============================================================================
-- Mansati AI — Workspace referral code (Migration 0010)
-- ============================================================================

alter table workspaces add column if not exists referral_code text unique;
