-- ============================================================================
-- Mansati AI — Seed default plans (Migration 0003)
-- These are just the STARTING values. Admins can change price/limits anytime
-- from the Admin Panel (updates the `plans` table) — never hard-coded again.
-- ============================================================================

insert into plans (key, name, price_cents, currency, interval, message_limit, storage_limit_mb, agent_limit, file_limit, is_public, is_active, sort_order)
values
  ('trial', 'Free Trial', 0, 'USD', 'month', 100, 100, 1, 10, false, true, 0),
  ('basic', 'Mansati Basic', 500, 'USD', 'month', 3000, 1000, 3, 50, true, true, 1),
  ('pro', 'Mansati Pro', 1000, 'USD', 'month', 10000, 5000, 10, 100, true, true, 2)
on conflict (key) do nothing;
