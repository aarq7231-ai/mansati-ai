-- ============================================================================
-- Mansati AI — Billing provider metadata (Migration 0006)
-- ============================================================================
-- Keeps the plans table provider-agnostic: a plan's price/limits are the
-- source of truth, and provider_metadata holds whatever ID/config a given
-- payment provider needs to charge for it (e.g. {"stripe": {"price_id": "..."}}).
-- Switching or adding a payment provider later never requires a schema change.
-- ============================================================================

alter table plans add column if not exists provider_metadata jsonb not null default '{}';
