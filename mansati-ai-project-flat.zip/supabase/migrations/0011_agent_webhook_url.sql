-- ============================================================================
-- Mansati AI — Agent webhook URL (Migration 0011)
-- ============================================================================
-- Supports the generic "trigger_webhook" action (spec section 22: "call an
-- API", "trigger webhook") without needing a whole webhook-management UI —
-- one configurable URL per agent is enough for the common case (notify an
-- external system, e.g. a CRM or Zapier, when the AI decides to).

alter table agent_settings add column if not exists webhook_url text;
