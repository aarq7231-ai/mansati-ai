-- ============================================================================
-- Mansati AI — Core Schema (Migration 0001)
-- Multi-tenant AI Agent SaaS platform
-- ============================================================================
-- Design notes:
--  * "workspace" = tenant. Every business-owned row carries workspace_id.
--  * auth.users (Supabase Auth) is the source of truth for identity.
--  * profiles extends auth.users with app-level data (1:1).
--  * workspace_members maps users <-> workspaces with a role, enabling
--    multiple staff per business later without schema changes.
--  * RLS policies live in 0002_rls_policies.sql — this file is structure only.
-- ============================================================================

create extension if not exists "uuid-ossp";
create extension if not exists "pgcrypto";
create extension if not exists "vector"; -- pgvector, for document_chunks embeddings

-- ----------------------------------------------------------------------------
-- ENUMS
-- ----------------------------------------------------------------------------
create type workspace_role as enum ('owner', 'admin', 'agent_staff');
create type subscription_status as enum ('trialing', 'active', 'past_due', 'canceled', 'expired');
create type knowledge_source_type as enum ('pdf', 'docx', 'txt', 'csv', 'xlsx', 'website', 'manual_text');
create type document_status as enum ('pending', 'processing', 'ready', 'error');
create type conversation_channel as enum ('website', 'whatsapp', 'instagram', 'messenger', 'telegram');
create type conversation_status as enum ('ai_active', 'human_active', 'closed');
create type message_role as enum ('user', 'assistant', 'system', 'staff');
create type lead_status as enum ('new', 'interested', 'qualified', 'negotiation', 'won', 'lost');
create type integration_type as enum ('whatsapp', 'instagram', 'messenger', 'telegram', 'google_calendar', 'gmail');
create type automation_trigger_type as enum ('new_lead', 'appointment_requested', 'high_value_lead', 'conversation_handoff', 'custom');
create type plan_interval as enum ('month', 'year');

-- ----------------------------------------------------------------------------
-- PROFILES (extends auth.users)
-- ----------------------------------------------------------------------------
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  avatar_url text,
  preferred_language text not null default 'ar' check (preferred_language in ('ar', 'en')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- WORKSPACES (tenants)
-- ----------------------------------------------------------------------------
create table workspaces (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  slug text not null unique,
  business_type text,
  country text,
  preferred_language text not null default 'ar' check (preferred_language in ('ar', 'en')),
  business_description text,
  website_url text,
  logo_url text,
  timezone text not null default 'UTC',
  onboarding_completed boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table workspace_members (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role workspace_role not null default 'owner',
  created_at timestamptz not null default now(),
  unique (workspace_id, user_id)
);

-- ----------------------------------------------------------------------------
-- PLANS (admin-configurable, never hard-coded in app code)
-- ----------------------------------------------------------------------------
create table plans (
  id uuid primary key default uuid_generate_v4(),
  key text not null unique,               -- e.g. 'trial', 'pro'
  name text not null,
  price_cents integer not null default 0,
  currency text not null default 'USD',
  interval plan_interval not null default 'month',
  message_limit integer not null,         -- AI messages per period
  storage_limit_mb integer not null,
  agent_limit integer not null,
  file_limit integer not null,
  is_public boolean not null default true,
  is_active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- SUBSCRIPTIONS (billing-provider agnostic)
-- ----------------------------------------------------------------------------
create table subscriptions (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  plan_id uuid not null references plans(id),
  status subscription_status not null default 'trialing',
  billing_provider text,                  -- e.g. 'stripe', null while trialing
  provider_customer_id text,
  provider_subscription_id text,
  trial_started_at timestamptz not null default now(),
  trial_ends_at timestamptz not null default (now() + interval '3 days'),
  current_period_start timestamptz,
  current_period_end timestamptz,
  canceled_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (workspace_id)
);

-- ----------------------------------------------------------------------------
-- AGENT TEMPLATES (library + future marketplace)
-- ----------------------------------------------------------------------------
create table agent_templates (
  id uuid primary key default uuid_generate_v4(),
  key text not null unique,
  name text not null,
  business_type text not null,
  description text,
  suggested_system_instructions text,
  suggested_tone text,
  suggested_greeting text,
  suggested_faq jsonb not null default '[]',
  suggested_lead_questions jsonb not null default '[]',
  suggested_actions jsonb not null default '[]',
  is_marketplace_item boolean not null default false,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- AGENTS
-- ----------------------------------------------------------------------------
create table agents (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  template_id uuid references agent_templates(id),
  public_agent_id text not null unique default replace(uuid_generate_v4()::text, '-', ''),
  name text not null,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table agent_settings (
  agent_id uuid primary key references agents(id) on delete cascade,
  language text not null default 'ar',
  personality text,
  tone text,
  system_instructions text,
  welcome_message text,
  fallback_message text not null default 'عذراً، ما عندي معلومات مؤكدة عن هذا الموضوع. أقدر أحولك إلى موظف.',
  rules jsonb not null default '[]',
  lead_questions jsonb not null default '[]',
  handoff_triggers jsonb not null default '[]',
  allowed_actions jsonb not null default '[]',
  branding jsonb not null default '{}',
  ai_provider text not null default 'cloudflare',
  ai_model text,
  updated_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- KNOWLEDGE BASE
-- ----------------------------------------------------------------------------
create table knowledge_sources (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  agent_id uuid not null references agents(id) on delete cascade,
  type knowledge_source_type not null,
  source_url text,
  created_at timestamptz not null default now()
);

create table documents (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  knowledge_source_id uuid not null references knowledge_sources(id) on delete cascade,
  file_name text not null,
  file_type text,
  file_size_bytes bigint,
  storage_path text,
  status document_status not null default 'pending',
  error_message text,
  uploaded_at timestamptz not null default now(),
  processed_at timestamptz
);

create table document_chunks (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  document_id uuid not null references documents(id) on delete cascade,
  chunk_index integer not null,
  content text not null,
  embedding vector(1536),               -- requires pgvector extension
  created_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- CONVERSATIONS / MESSAGES
-- ----------------------------------------------------------------------------
create table contacts (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  name text,
  phone text,
  email text,
  source text,
  tags text[] not null default '{}',
  notes text,
  last_interaction_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table conversations (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  agent_id uuid not null references agents(id) on delete cascade,
  contact_id uuid references contacts(id) on delete set null,
  channel conversation_channel not null default 'website',
  status conversation_status not null default 'ai_active',
  assigned_staff_id uuid references auth.users(id),
  external_thread_id text,             -- id from WhatsApp/Telegram/etc.
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table messages (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  conversation_id uuid not null references conversations(id) on delete cascade,
  role message_role not null,
  content text not null,
  input_tokens integer,
  output_tokens integer,
  feedback smallint check (feedback in (-1, 0, 1)),
  created_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- CRM / LEADS
-- ----------------------------------------------------------------------------
create table leads (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  contact_id uuid not null references contacts(id) on delete cascade,
  conversation_id uuid references conversations(id) on delete set null,
  status lead_status not null default 'new',
  answers jsonb not null default '{}',   -- qualification Q&A
  value_estimate numeric,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table lead_events (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  lead_id uuid not null references leads(id) on delete cascade,
  event_type text not null,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- INTEGRATIONS (channels + Google)
-- ----------------------------------------------------------------------------
create table integrations (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  type integration_type not null,
  status text not null default 'disconnected',
  display_name text,
  metadata jsonb not null default '{}',   -- non-secret config (phone number id, page id, etc.)
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (workspace_id, type)
);

-- Secrets kept in a separate table so RLS + admin scoping can be tighter.
create table integration_credentials (
  id uuid primary key default uuid_generate_v4(),
  integration_id uuid not null references integrations(id) on delete cascade,
  encrypted_payload text not null,        -- encrypted at application layer before insert
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- AUTOMATIONS
-- ----------------------------------------------------------------------------
create table automations (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  name text not null,
  trigger_type automation_trigger_type not null,
  trigger_config jsonb not null default '{}',
  action_type text not null,
  action_config jsonb not null default '{}',
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table automation_runs (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  automation_id uuid not null references automations(id) on delete cascade,
  status text not null default 'pending',
  input jsonb not null default '{}',
  output jsonb not null default '{}',
  error_message text,
  ran_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- USAGE (source of truth for limits enforcement — never trust the frontend)
-- ----------------------------------------------------------------------------
create table usage (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  period_start date not null,
  period_end date not null,
  ai_messages_used integer not null default 0,
  input_tokens_used bigint not null default 0,
  output_tokens_used bigint not null default 0,
  storage_used_mb numeric not null default 0,
  documents_count integer not null default 0,
  agents_count integer not null default 0,
  integrations_count integer not null default 0,
  updated_at timestamptz not null default now(),
  unique (workspace_id, period_start)
);

-- ----------------------------------------------------------------------------
-- REFERRALS / AFFILIATES
-- ----------------------------------------------------------------------------
create table referrals (
  id uuid primary key default uuid_generate_v4(),
  referrer_workspace_id uuid not null references workspaces(id) on delete cascade,
  referred_workspace_id uuid references workspaces(id) on delete set null,
  code text not null unique,
  status text not null default 'pending',  -- pending, signed_up, converted, rewarded
  reward_type text,
  reward_value text,
  created_at timestamptz not null default now(),
  converted_at timestamptz
);

create table affiliates (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references auth.users(id) on delete cascade,
  referral_link_code text not null unique,
  visitors_count integer not null default 0,
  signups_count integer not null default 0,
  trials_count integer not null default 0,
  paid_conversions_count integer not null default 0,
  commission_owed_cents integer not null default 0,
  created_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- NOTIFICATIONS / AUDIT / ADMIN
-- ----------------------------------------------------------------------------
create table notifications (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  user_id uuid references auth.users(id) on delete cascade,
  type text not null,
  title text not null,
  body text,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table audit_logs (
  id uuid primary key default uuid_generate_v4(),
  workspace_id uuid references workspaces(id) on delete cascade,
  actor_user_id uuid references auth.users(id),
  action text not null,
  target_table text,
  target_id uuid,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);

create table admin_logs (
  id uuid primary key default uuid_generate_v4(),
  admin_user_id uuid not null references auth.users(id),
  action text not null,
  target_workspace_id uuid references workspaces(id),
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);

-- Marks a user as a platform admin (separate from workspace roles).
create table platform_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- INDEXES
-- ----------------------------------------------------------------------------
create index idx_workspace_members_user on workspace_members(user_id);
create index idx_workspace_members_workspace on workspace_members(workspace_id);
create index idx_agents_workspace on agents(workspace_id);
create index idx_knowledge_sources_workspace on knowledge_sources(workspace_id);
create index idx_documents_workspace on documents(workspace_id);
create index idx_document_chunks_workspace on document_chunks(workspace_id);
create index idx_document_chunks_document on document_chunks(document_id);
create index idx_conversations_workspace on conversations(workspace_id);
create index idx_conversations_agent on conversations(agent_id);
create index idx_messages_workspace on messages(workspace_id);
create index idx_messages_conversation on messages(conversation_id);
create index idx_contacts_workspace on contacts(workspace_id);
create index idx_leads_workspace on leads(workspace_id);
create index idx_integrations_workspace on integrations(workspace_id);
create index idx_automations_workspace on automations(workspace_id);
create index idx_usage_workspace_period on usage(workspace_id, period_start);
create index idx_audit_logs_workspace on audit_logs(workspace_id);

-- ----------------------------------------------------------------------------
-- updated_at trigger helper
-- ----------------------------------------------------------------------------
create or replace function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

do $$
declare
  t text;
begin
  for t in select unnest(array[
    'profiles','workspaces','plans','subscriptions','agents','agent_settings',
    'contacts','conversations','leads','integrations','integration_credentials',
    'automations','usage'
  ])
  loop
    execute format('create trigger trg_set_updated_at before update on %I for each row execute function set_updated_at();', t);
  end loop;
end $$;

-- ----------------------------------------------------------------------------
-- Auto-create profile row on signup
-- ----------------------------------------------------------------------------
create or replace function handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, new.raw_user_meta_data->>'full_name');
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function handle_new_user();
