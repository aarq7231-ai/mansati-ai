-- ============================================================================
-- Mansati AI — Workspace suspension flag (Migration 0007)
-- ============================================================================

alter table workspaces add column if not exists is_suspended boolean not null default false;
alter table workspaces add column if not exists suspended_reason text;
