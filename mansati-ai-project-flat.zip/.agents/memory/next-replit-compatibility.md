---
name: Replit Next.js compatibility
description: Secure Next.js package versions and async request APIs needed for imported Mansati AI code on Replit.
---

Replit's package firewall blocks the imported Next 14 line because of a critical vulnerability. The secure Next 15 line requires async access for cookies, page params, and search params; update those contracts rather than reverting to the blocked package.

**Why:** Keeping the vulnerable dependency was not an option, while leaving the old synchronous contracts produces runtime warnings and can fail stricter future Next releases.

**How to apply:** For future dependency refreshes in this project, prefer the newest secure version within the smallest compatible major line and run both the production build and a real preview request before publishing.