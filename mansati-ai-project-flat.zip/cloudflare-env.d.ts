interface CloudflareEnv {
  ASSETS: Fetcher;
}

interface Env extends CloudflareEnv {}
