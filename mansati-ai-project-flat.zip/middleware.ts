import { createServerClient, type CookieOptions } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";

/**
 * Runs on every request. Two jobs:
 *  1. Refresh the Supabase auth session (required by @supabase/ssr).
 *  2. Gate /dashboard and /onboarding behind authentication.
 *
 * This is the server-side enforcement layer for "protected routes" —
 * frontend redirects alone are never sufficient.
 */
export async function middleware(request: NextRequest) {
  const path = request.nextUrl.pathname;

  // These are called by anonymous website visitors, third-party webhooks
  // (Telegram), and Google's OAuth redirect — none of them carry or need
  // our session cookie, so skip the Supabase client + getUser() call
  // entirely rather than paying for it on every public chat message.
  const isPublicApi =
    path.startsWith("/api/chat/") ||
    path.startsWith("/api/webhooks/") ||
    path.startsWith("/api/oauth/") ||
    path === "/api/set-lang";
  if (isPublicApi) return NextResponse.next();

  let response = NextResponse.next({ request: { headers: request.headers } });

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          return request.cookies.get(name)?.value;
        },
        set(name: string, value: string, options: CookieOptions) {
          response = NextResponse.next({ request: { headers: request.headers } });
          response.cookies.set({ name, value, ...options });
        },
        remove(name: string, options: CookieOptions) {
          response = NextResponse.next({ request: { headers: request.headers } });
          response.cookies.set({ name, value: "", ...options });
        }
      }
    }
  );

  const {
    data: { user }
  } = await supabase.auth.getUser();

  const isProtected = path.startsWith("/dashboard") || path.startsWith("/onboarding") || path.startsWith("/admin");
  const isAuthPage = path.startsWith("/login") || path.startsWith("/signup");

  if (isProtected && !user) {
    const redirectUrl = new URL("/login", request.url);
    redirectUrl.searchParams.set("next", path);
    return NextResponse.redirect(redirectUrl);
  }

  if (isAuthPage && user) {
    return NextResponse.redirect(new URL("/dashboard", request.url));
  }

  return response;
}

export const config = {
  matcher: [
    /*
     * Run on everything except static assets and image optimization files,
     * so the session cookie stays fresh across the whole app.
     */
    "/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)"
  ]
};
