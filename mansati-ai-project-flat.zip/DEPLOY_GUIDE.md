# Mansati AI — Deployment & Testing Guide (from your phone)

Follow these in order. Nothing here requires writing or editing code —
only tapping, pasting values, and running things other people built
(Vercel, Supabase, Replit). If any step produces an error, copy the exact
error text and send it back in chat — I'll fix the code, you won't need to.

---

## Step 1 — Get the project onto your phone

You already have it: **mansati-ai-qa.zip** (shared earlier in this chat).
- Tap the file → Save to Files (iPhone) or Downloads (Android).
- Leave it zipped for now — Step 2 handles extraction.

---

## Step 2 — Get it into GitHub (via Replit — works fully from a phone browser)

GitHub's own mobile site can't reliably upload a project with this many
folders, so use **Replit** as the phone-friendly middle step — it can
unzip your project AND push it to GitHub with taps, no typing commands.

1. Go to **replit.com** in your phone's browser → sign up / log in
   (you can use "Continue with Google").
2. Tap **+ Create App/Repl** → look for **"Import from a ZIP file"** (or
   "Upload folder") → select `mansati-ai-qa.zip` from your phone.
3. Wait for it to finish extracting — you'll see the full folder tree.
4. In Replit, open the left sidebar → **Git / Version Control** icon.
5. Tap **Connect to GitHub** → authorize with your GitHub account (create
   a free GitHub account first at github.com if you don't have one).
6. Tap **Create a GitHub repo** (name it `mansati-ai`) → **Push**.
   This creates the repo and uploads every file in one action.

You now have a real GitHub repository with the full project.

---

## Step 3 — Create your Supabase project

1. Go to **supabase.com** → sign up/log in → **New Project**.
2. Pick any name/region, set a database password (save it somewhere).
3. Wait ~2 minutes for provisioning to finish.
4. Go to **Project Settings → API** → copy these three values somewhere
   safe (a Notes app is fine, don't post them in chat):
   - **Project URL**
   - **anon public key**
   - **service_role key** (⚠️ keep this one especially private)

---

## Step 4 — Run the database setup (one paste)

1. In your project folder (Replit, or the unzipped files), open
   **`supabase/all_migrations_combined.sql`** — this is every migration
   already combined into one file, so you only paste once instead of 11
   times.
2. Select all the text in that file, copy it.
3. In Supabase: **SQL Editor → New query** → paste the whole thing →
   **Run**.
4. If it finishes without a red error banner, your database is fully set
   up (tables, security rules, seed data — everything).
5. Double-check pgvector is on: **Database → Extensions** → search
   "vector" → should show as enabled (the migration also tries to enable
   it automatically).

---

## Step 5 — Create the storage bucket

1. Supabase → **Storage** → **New bucket**.
2. Name it exactly: `knowledge-files`
3. Set it to **Private** (not public).

---

## Step 6 — Get your Cloudflare Workers AI API key

1. Go to **aistudio.google.com/app/apikey** on your phone.
2. Sign in with a Google account → **Create API key** → copy it.

---

## Step 7 — Deploy to Vercel

1. Go to **vercel.com** → sign up/log in with **"Continue with GitHub"**
   (one tap — this also grants Vercel access to your new repo).
2. **Add New → Project** → select the `mansati-ai` repo you pushed in
   Step 2 → Vercel auto-detects it's a Next.js app.
3. Before clicking Deploy, open **Environment Variables** and add these
   one at a time (name on the left, value on the right):

   | Name | Value |
   |---|---|
   | `NEXT_PUBLIC_SUPABASE_URL` | from Step 3 |
   | `NEXT_PUBLIC_SUPABASE_ANON_KEY` | from Step 3 |
   | `SUPABASE_SERVICE_ROLE_KEY` | from Step 3 |
   | `NEXT_PUBLIC_APP_URL` | leave as `https://placeholder.vercel.app` for now — you'll fix this in Step 7b |
   | `CLOUDFLARE_ACCOUNT_ID + CLOUDFLARE_AI_API_TOKEN` | from Step 6 |
   | `ENCRYPTION_KEY` | `taqCNPTItNkrOOmKwwRfubWBWTrqzmg9sN6Q8/SOPTk=` (generated for you — treat it like a password) |

4. Tap **Deploy**. This runs the real production build (`npm install` +
   `next build`) — this is Step 7 and Step 9 combined: if it fails, the
   build log on the Vercel page will show a red error. Copy that text and
   send it to me.

### Step 7b — Fix the URL (important, do this right after first deploy)
1. Once deployed, Vercel gives you a real URL like
   `https://mansati-ai-yourname.vercel.app`.
2. Go to your Vercel project → **Settings → Environment Variables** →
   edit `NEXT_PUBLIC_APP_URL` → set it to that real URL.
3. Go to **Deployments** → tap the three dots on the latest one →
   **Redeploy**. (Several features — email confirmation links, the
   website widget, Google OAuth, checkout redirects — depend on this
   value being correct.)
4. Back in Supabase: **Authentication → URL Configuration** → set **Site
   URL** to that same Vercel URL.

---

## Step 8 — Test the full flow

Open your live Vercel URL and go through, in order:

1. **Signup** → `/signup` → create an account → check your email → click
   the confirmation link.
2. **Onboarding** → fill in your business info → this auto-creates your
   workspace, starts your 3-day trial, and creates your first agent.
3. **Agent** → land on `/dashboard` → click into your agent → try editing
   its personality/instructions → Save.
4. **Knowledge** → from the agent page → "قاعدة المعرفة" → upload a small
   PDF or paste some text → wait for status to say "جاهز" (ready).
5. **AI chat** → use the "جرّب الوكيل مباشرة" test box on the agent page →
   ask it something covered by what you uploaded → confirm it answers
   from that content (and says it doesn't know when asked something
   unrelated).
6. **Widget** → from the agent page, copy the `<script>` snippet shown
   under "إضافة الوكيل إلى موقعك" → if you have any test webpage, paste it
   in; otherwise just visit the public link shown above it directly.
7. **Billing** → `/dashboard/billing` — this page will load fine even
   without Stripe connected; the "الترقية الآن" button will show a clear
   error instead of crashing if Stripe isn't set up yet (see optional
   steps below for connecting it for real).
8. **Admin** → make yourself a platform admin (one-time): in Supabase SQL
   Editor, run (replace with your real signup email):
   ```sql
   insert into platform_admins (user_id)
   select id from auth.users where email = 'your-email@example.com';
   ```
   Then visit `/admin` on your live site.

---

## Step 9 — If anything breaks

For each thing you test, one of three things happens:
- Works — move to the next item.
- You see a clear message in Arabic (like "الفترة التجريبية انتهت" or
  a Stripe/Google "not connected" notice) — that's expected behavior, not
  a bug, for anything you haven't connected yet (Stripe, Telegram,
  Google Calendar/Gmail are all optional and documented in the README).
- You see a blank white screen, a raw error stack trace, or the Vercel
  build fails — **copy the exact text** (screenshot is fine too) and
  send it to me in chat. I'll find and fix the underlying code issue —
  you won't need to touch anything yourself.

---

## Optional, only if you want them working right now
These are **not required** to test everything above — the app works
without them, just with those specific features inactive:
- **Stripe** (real payments): see README "Phase 7" section in the project
  for the exact click-path.
- **Telegram**: message @BotFather, get a bot token, paste it into the
  agent's "القنوات" page.
- **Google Calendar/Gmail**: see README "Phase 14" section for the Google
  Cloud OAuth app setup.


## Cloudflare Workers deployment

Mansati AI is prepared for Cloudflare Workers using the OpenNext adapter. Cloudflare currently documents OpenNext as the maintenance path for existing Next.js applications, while vinext is the newer default for new migrations.

1. Push this project to GitHub.
2. In Cloudflare Dashboard, create a Workers project from the GitHub repository.
3. Use the project build/deploy scripts from `package.json` (`deploy:cloudflare`).
4. Add these server-side environment variables/secrets:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`
   - `NEXT_PUBLIC_APP_URL`
   - `CLOUDFLARE_ACCOUNT_ID`
   - `CLOUDFLARE_AI_API_TOKEN`
   - `CLOUDFLARE_AI_MODEL` (optional; default `@cf/meta/llama-3.2-1b-instruct`)
   - `CLOUDFLARE_TOOL_MODEL` (optional; default `@cf/qwen/qwen3-30b-a3b-fp8`)
   - `ENCRYPTION_KEY`
   - Stripe and Google OAuth variables when those features are enabled.
5. Do not put Cloudflare AI tokens in browser code or `NEXT_PUBLIC_*` variables.
6. Run `supabase/all_migrations_combined.sql` once against the Supabase project.
7. After the migration, re-process existing knowledge documents so their embeddings are regenerated with the new 768-dimensional Cloudflare embedding model.


## Meta WhatsApp Cloud API

The project now includes a real WhatsApp Cloud API webhook and outbound message integration.
Set these server-side environment variables:

- `META_APP_ID` — Meta App ID.
- `META_APP_SECRET` — Meta App Secret, used to verify `X-Hub-Signature-256`.
- `META_WEBHOOK_VERIFY_TOKEN` — your webhook verification token.
- `META_GRAPH_API_VERSION` — Graph API version configured for your Meta app.

Webhook callback URL:
`https://YOUR_DOMAIN/api/webhooks/whatsapp`

Subscribe the Meta WhatsApp webhook to the `messages` field. Each customer/workspace stores its own WhatsApp access token encrypted in `integration_credentials`; the Phone Number ID is stored as non-secret integration metadata.

The Channels page lets a workspace owner connect a WhatsApp Phone Number ID + access token and verifies the credentials against the Graph API before saving them.
