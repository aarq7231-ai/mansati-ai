/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  experimental: {
    serverActions: { bodySizeLimit: "10mb" } // needed for knowledge-base uploads
  }
};

export default nextConfig;
