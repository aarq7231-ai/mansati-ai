# Mansati AI — Cloudflare-ready changes

This version is a separate prepared copy of the uploaded project. The original ZIP is untouched.

## Implemented
- Removed Gemini runtime AI usage and switched chat/lead extraction to Cloudflare Workers AI.
- Default chat model: `@cf/meta/llama-3.2-1b-instruct`.
- Tool-calling turns use `@cf/qwen/qwen3-30b-a3b-fp8`.
- RAG embeddings use multilingual `@cf/google/embeddinggemma-300m` (768 dimensions). Existing embeddings are cleared by migration 0012 and must be regenerated.
- Basic plan: $5/month, 3,000 successful AI replies/month.
- Pro plan: $10/month, 10,000 successful AI replies/month.
- Only AI reply slots are counted; customer questions and human replies are not counted.
- AI reply usage is reserved server-side and released if generation fails.
- Numeric usage counters are hidden from normal customers. Admin pages can still inspect usage.
- Dashboard shows an upgrade prompt only after the Basic limit is reached; it does not show the numeric count.
- Chat context was reduced from 20 to 10 recent messages to reduce input-token cost.
- Added Cloudflare OpenNext/Wrangler deployment files.

## Required Cloudflare secrets
- `CLOUDFLARE_ACCOUNT_ID`
- `CLOUDFLARE_AI_API_TOKEN`
- `CLOUDFLARE_AI_MODEL` (optional)
- `CLOUDFLARE_TOOL_MODEL` (optional)

Keep these server-side. Never use `NEXT_PUBLIC_` for AI credentials.

## Database
Run `supabase/all_migrations_combined.sql` once. Migration `0012_cloudflare_ai_usage_plans.sql` contains the Cloudflare/RAG/plan/usage changes.

## Important
The project dependencies could not be installed in this offline execution environment, so a full Next.js production build was not run here. The original project remains untouched; this ZIP is the prepared working copy for the next deployment/test step.


## WhatsApp Meta Cloud API
- Added Meta WhatsApp Graph API client.
- Added global `/api/webhooks/whatsapp` verification and signed webhook handling.
- Added WhatsApp connection/disconnection UI in Agent Channels.
- WhatsApp access tokens are encrypted with `ENCRYPTION_KEY`.
- Incoming WhatsApp text messages use the existing conversation/RAG/AI/usage pipeline.
- Outbound AI replies are sent through WhatsApp Cloud API.
- Added Meta environment variables to `.env.example`.
