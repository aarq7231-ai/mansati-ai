/**
 * Mansati AI — Website Widget
 *
 * Usage (copied from the Agent Builder's "Embed on your website" panel):
 *   <script src="https://YOUR_DOMAIN/widget.js" data-agent-id="AGENT_PUBLIC_ID" async></script>
 *
 * Optional data attributes on the same <script> tag:
 *   data-color="#3b6cf6"   — launcher/accent color
 *   data-position="left"   — "left" or "right" (default: right)
 *   data-greeting="مرحباً! تحتاج مساعدة؟"
 *
 * No framework, no build step — plain DOM APIs only, so it works dropped
 * into any website regardless of what that site is built with.
 */
(function () {
  var currentScript = document.currentScript;
  if (!currentScript) return;

  var agentId = currentScript.getAttribute("data-agent-id");
  if (!agentId) {
    console.error("Mansati AI widget: missing data-agent-id attribute on the script tag.");
    return;
  }

  var color = currentScript.getAttribute("data-color") || "#3b6cf6";
  var position = currentScript.getAttribute("data-position") === "left" ? "left" : "right";
  var greeting = currentScript.getAttribute("data-greeting") || "";
  var origin = new URL(currentScript.src).origin;

  var isOpen = false;

  // --- Launcher button -------------------------------------------------
  var launcher = document.createElement("button");
  launcher.setAttribute("aria-label", "فتح المحادثة");
  launcher.innerHTML =
    '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">' +
    '<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" ' +
    'stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  Object.assign(launcher.style, {
    position: "fixed",
    bottom: "20px",
    [position]: "20px",
    width: "60px",
    height: "60px",
    borderRadius: "50%",
    border: "none",
    background: color,
    boxShadow: "0 4px 16px rgba(0,0,0,0.2)",
    cursor: "pointer",
    zIndex: "2147483000",
    display: "flex",
    alignItems: "center",
    justifyContent: "center"
  });

  // --- Chat window (iframe) --------------------------------------------
  var frame = document.createElement("iframe");
  frame.src = origin + "/embed/" + encodeURIComponent(agentId);
  frame.title = "Mansati AI Chat";
  Object.assign(frame.style, {
    position: "fixed",
    bottom: "90px",
    [position]: "20px",
    width: "380px",
    maxWidth: "calc(100vw - 40px)",
    height: "600px",
    maxHeight: "calc(100vh - 120px)",
    border: "none",
    borderRadius: "16px",
    boxShadow: "0 8px 32px rgba(0,0,0,0.25)",
    zIndex: "2147483000",
    display: "none",
    background: "white"
  });

  // --- Optional greeting bubble, shown once before first open ----------
  var greetingBubble = null;
  if (greeting) {
    greetingBubble = document.createElement("div");
    greetingBubble.textContent = greeting;
    Object.assign(greetingBubble.style, {
      position: "fixed",
      bottom: "90px",
      [position]: "20px",
      maxWidth: "240px",
      background: "white",
      color: "#1e293b",
      padding: "10px 14px",
      borderRadius: "12px",
      boxShadow: "0 4px 16px rgba(0,0,0,0.15)",
      fontSize: "14px",
      fontFamily: "sans-serif",
      zIndex: "2147483000",
      cursor: "pointer"
    });
    greetingBubble.addEventListener("click", toggle);
  }

  function toggle() {
    isOpen = !isOpen;
    frame.style.display = isOpen ? "block" : "none";
    if (greetingBubble) greetingBubble.style.display = "none";
  }

  launcher.addEventListener("click", toggle);

  function mount() {
    document.body.appendChild(frame);
    document.body.appendChild(launcher);
    if (greetingBubble) document.body.appendChild(greetingBubble);
  }

  if (document.body) mount();
  else document.addEventListener("DOMContentLoaded", mount);
})();
