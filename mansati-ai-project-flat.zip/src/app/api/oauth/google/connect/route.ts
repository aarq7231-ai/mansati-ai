import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { buildGoogleAuthUrl } from "@/lib/google/oauth";
import { signOAuthState } from "@/lib/security/oauth-state";

export async function GET(request: NextRequest) {
  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.redirect(new URL("/login", request.url));

  const scope = request.nextUrl.searchParams.get("scope") === "gmail" ? "gmail" : "calendar";
  const agentId = request.nextUrl.searchParams.get("agentId") ?? "";

  const { data: membership } = await supabase
    .from("workspace_members")
    .select("workspace_id, role")
    .eq("user_id", user.id)
    .limit(1)
    .maybeSingle();

  if (!membership || !["owner", "admin"].includes(membership.role)) {
    return NextResponse.redirect(new URL("/dashboard", request.url));
  }

  if (agentId) {
    const { data: agent } = await supabase
      .from("agents")
      .select("id")
      .eq("id", agentId)
      .eq("workspace_id", membership.workspace_id)
      .maybeSingle();
    if (!agent) return NextResponse.redirect(new URL("/dashboard", request.url));
  }

  try {
    // state carries workspace + agent + which scope was requested through
    // Google's redirect, so the callback knows what to attach the tokens to.
    // Signed (see oauth-state.ts) so it can't be tampered with in transit,
    // and re-verified against the session in the callback route.
    const state = signOAuthState({ workspaceId: membership.workspace_id, agentId, scope, userId: user.id });
    const url = buildGoogleAuthUrl({ state, scopes: [scope] });
    return NextResponse.redirect(url);
  } catch (err: any) {
    return NextResponse.redirect(
      new URL(`/dashboard/agents/${agentId}/channels?error=${encodeURIComponent(err.message)}`, request.url)
    );
  }
}
