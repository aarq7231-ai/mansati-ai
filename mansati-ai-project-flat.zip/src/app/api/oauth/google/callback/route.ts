import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { encryptSecret } from "@/lib/security/crypto";
import { exchangeGoogleCode } from "@/lib/google/oauth";
import { verifyOAuthState } from "@/lib/security/oauth-state";

export async function GET(request: NextRequest) {
  const code = request.nextUrl.searchParams.get("code");
  const stateRaw = request.nextUrl.searchParams.get("state");
  const errorParam = request.nextUrl.searchParams.get("error");

  const state = verifyOAuthState(stateRaw);
  if (!state) {
    // Missing, tampered, malformed, or expired — refuse rather than trust it.
    return NextResponse.redirect(new URL("/dashboard?error=" + encodeURIComponent("انتهت صلاحية طلب الاتصال، حاول مرة أخرى."), request.url));
  }
  const backToChannels = new URL(`/dashboard/agents/${state.agentId}/channels`, request.url);

  if (errorParam || !code) {
    backToChannels.searchParams.set("error", "تم إلغاء الاتصال بجوجل.");
    return NextResponse.redirect(backToChannels);
  }

  // Re-verify against the live session rather than trusting the state's
  // userId/workspaceId alone: the state proves the request wasn't tampered
  // with in transit, but the person completing this redirect must still be
  // signed in as a user who currently has owner/admin rights on that exact
  // workspace — membership can change between initiating and completing
  // the OAuth flow, and this closes that window.
  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();

  if (!user || user.id !== state.userId) {
    return NextResponse.redirect(new URL("/login", request.url));
  }

  const { data: membership } = await supabase
    .from("workspace_members")
    .select("role")
    .eq("user_id", user.id)
    .eq("workspace_id", state.workspaceId)
    .maybeSingle();

  if (!membership || !["owner", "admin"].includes(membership.role)) {
    return NextResponse.redirect(new URL("/dashboard", request.url));
  }

  try {
    const tokens = await exchangeGoogleCode(code);
    if (!tokens.refresh_token) {
      // Google only returns a refresh_token on first consent — if the
      // business owner previously connected and revoked, this can be
      // empty. `prompt=consent` in buildGoogleAuthUrl guards against most
      // of this, but surface a clear message just in case.
      backToChannels.searchParams.set(
        "error",
        "لم يتم استلام صلاحية الوصول الدائم من جوجل. افصل الاتصال من إعدادات جوجل حسابك وحاول مرة أخرى."
      );
      return NextResponse.redirect(backToChannels);
    }

    const admin = createAdminClient();
    const type = state.scope === "gmail" ? "gmail" : "google_calendar";

    const { data: integration } = await admin
      .from("integrations")
      .upsert(
        { workspace_id: state.workspaceId, agent_id: state.agentId || null, type, status: "connected" },
        { onConflict: "workspace_id,type" }
      )
      .select("id")
      .single();

    await admin.from("integration_credentials").upsert(
      { integration_id: integration!.id, encrypted_payload: encryptSecret(tokens.refresh_token) },
      { onConflict: "integration_id" }
    );

    return NextResponse.redirect(backToChannels);
  } catch (err: any) {
    backToChannels.searchParams.set("error", err?.message ?? "فشل الاتصال بجوجل");
    return NextResponse.redirect(backToChannels);
  }
}
