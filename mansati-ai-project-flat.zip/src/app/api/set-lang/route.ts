import { NextRequest, NextResponse } from "next/server";

export async function POST(request: NextRequest) {
  const body = await request.json().catch(() => null);
  const lang = body?.lang === "en" ? "en" : "ar";

  const res = NextResponse.json({ ok: true });
  res.cookies.set("lang", lang, { maxAge: 60 * 60 * 24 * 365, path: "/" });
  return res;
}
