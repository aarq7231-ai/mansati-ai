import { NextRequest, NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { decryptSecret } from "@/lib/security/crypto";
import { telegramSendMessage } from "@/lib/telegram/client";
import { findOrCreateChannelConversation } from "@/lib/chat/find-or-create-channel-conversation";
import { checkAndIncrementUsage, recordTokenUsage, releaseUsageReservation } from "@/lib/usage/check-and-increment";
import { updateLeadFromConversation } from "@/lib/crm/lead-capture";
import { buildSystemPrompt } from "@/lib/chat/system-prompt";
import { retrieveRelevantChunks } from "@/lib/chat/knowledge";
import { routeModel } from "@/lib/ai/router";
import { completeNonStreaming } from "@/lib/ai/complete-non-streaming";
import { buildToolSet } from "@/lib/chat/tools";
import type { ChatMessage } from "@/lib/ai/types";

export const runtime = "nodejs";

const TRIAL_EXPIRED_MESSAGE_AR =
  "انتهت الفترة التجريبية. اشترك بـ $5 شهرياً لمواصلة استخدام الوكيل.";
const LIMIT_REACHED_MESSAGE_AR =
  "عذراً، الرد الآلي متوقف مؤقتاً. يرجى التواصل مع صاحب النشاط.";

export async function POST(request: NextRequest, { params }: { params: Promise<{ integrationId: string }> }) {
  const { integrationId } = await params;
  // Telegram signs webhook calls with the secret_token we set — verify it
  // before doing anything else, since this endpoint is otherwise unauthenticated.
  const secretHeader = request.headers.get("x-telegram-bot-api-secret-token");

  const admin = createAdminClient();
  const { data: integration } = await admin
    .from("integrations")
    .select("id, workspace_id, agent_id, status, metadata")
    .eq("id", integrationId)
    .eq("type", "telegram")
    .maybeSingle<any>();

  if (!integration || integration.status !== "connected" || !integration.agent_id) {
    return NextResponse.json({ ok: true }); // ack quietly — don't leak whether an integration id exists
  }
  if (integration.metadata?.webhook_secret !== secretHeader) {
    return NextResponse.json({ error: "invalid secret" }, { status: 401 });
  }

  const update = await request.json().catch(() => null);
  const message = update?.message;
  const text = message?.text as string | undefined;
  const chatId = message?.chat?.id;
  if (!text || !chatId) return NextResponse.json({ ok: true }); // ignore non-text updates (photos, stickers, etc. for now)

  const workspaceId = integration.workspace_id as string;
  const agentId = integration.agent_id as string;

  const { data: workspace } = await admin.from("workspaces").select("is_suspended, timezone").eq("id", workspaceId).single();
  const { data: cred } = await admin
    .from("integration_credentials")
    .select("encrypted_payload")
    .eq("integration_id", integration.id)
    .single();
  if (!cred) return NextResponse.json({ ok: true });
  const botToken = decryptSecret(cred.encrypted_payload);

  if (workspace?.is_suspended) return NextResponse.json({ ok: true });

  const { data: agent } = await admin
    .from("agents")
    .select("id, name, is_active, agent_settings(*)")
    .eq("id", agentId)
    .maybeSingle<any>();
  if (!agent || !agent.is_active) return NextResponse.json({ ok: true });
  const settings = agent.agent_settings;

  const { conversationId, status } = await findOrCreateChannelConversation({
    workspaceId,
    agentId,
    channel: "telegram",
    externalThreadId: String(chatId)
  });

  await admin.from("messages").insert({
    workspace_id: workspaceId,
    conversation_id: conversationId,
    role: "user",
    content: text
  });

  if (status === "human_active") return NextResponse.json({ ok: true }); // staff has taken over; stay silent

  const { data: subscription } = await admin
    .from("subscriptions")
    .select("status, trial_ends_at")
    .eq("workspace_id", workspaceId)
    .maybeSingle();
  const isTrialActive =
    subscription?.status === "trialing" &&
    subscription.trial_ends_at &&
    new Date(subscription.trial_ends_at).getTime() > Date.now();
  const isPaidActive = subscription?.status === "active";

  if (!isTrialActive && !isPaidActive) {
    await telegramSendMessage(botToken, chatId, TRIAL_EXPIRED_MESSAGE_AR).catch(() => {});
    return NextResponse.json({ ok: true });
  }

  const usage = await checkAndIncrementUsage(workspaceId);
  if (!usage.allowed) {
    await telegramSendMessage(botToken, chatId, LIMIT_REACHED_MESSAGE_AR).catch(() => {});
    return NextResponse.json({ ok: true });
  }

  const { data: history } = await admin
    .from("messages")
    .select("role, content")
    .eq("conversation_id", conversationId)
    .order("created_at", { ascending: true })
    .limit(10);

  const knowledgeChunks = await retrieveRelevantChunks({ workspaceId, agentId, query: text });
  const toolSet = await buildToolSet({
    workspaceId,
    agentId,
    allowedActions: settings?.allowed_actions,
    webhookUrl: settings?.webhook_url
  });

  const systemMessage = buildSystemPrompt({
    agentName: agent.name,
    businessName: "",
    language: settings?.language ?? "ar",
    personality: settings?.personality ?? null,
    tone: settings?.tone ?? null,
    systemInstructions: settings?.system_instructions ?? null,
    fallbackMessage: settings?.fallback_message ?? TRIAL_EXPIRED_MESSAGE_AR,
    rules: settings?.rules ?? [],
    knowledgeContext: knowledgeChunks,
    timezone: workspace?.timezone,
    hasTools: !!toolSet
  });

  const conversationMessages: ChatMessage[] = (history ?? []).map((m: any) => ({
    role: m.role === "staff" ? "assistant" : (m.role as ChatMessage["role"]),
    content: m.content
  }));

  const { provider, model } = routeModel({ preferredProvider: settings?.ai_provider, preferredModel: settings?.ai_model });

  try {
    let finalReply: string;
    let inputTokens = 0;
    let outputTokens = 0;

    if (toolSet && provider.completeWithTools) {
      const { text: toolText, toolCalls, usage } = await provider.completeWithTools({
        messages: [systemMessage, ...conversationMessages],
        tools: toolSet.definitions,
        executeTool: toolSet.executeTool,
        model
      });
      finalReply = toolText || settings?.fallback_message || TRIAL_EXPIRED_MESSAGE_AR;
      if (usage) {
        inputTokens = usage.inputTokens;
        outputTokens = usage.outputTokens;
      }

      for (const call of toolCalls) {
        await admin.from("audit_logs").insert({
          workspace_id: workspaceId,
          action: `tool_call:${call.name}`,
          target_table: "conversations",
          target_id: conversationId,
          metadata: { args: call.args, result: call.result }
        });
      }
    } else {
      const result = await completeNonStreaming(provider, { messages: [systemMessage, ...conversationMessages], model });
      finalReply = result.text || settings?.fallback_message || TRIAL_EXPIRED_MESSAGE_AR;
      inputTokens = result.inputTokens;
      outputTokens = result.outputTokens;
    }

    await admin.from("messages").insert({
      workspace_id: workspaceId,
      conversation_id: conversationId,
      role: "assistant",
      content: finalReply,
      output_tokens: outputTokens || null
    });
    await recordTokenUsage(workspaceId, inputTokens, outputTokens);

    const leadQuestions = Array.isArray(settings?.lead_questions) ? settings.lead_questions : [];
    if (leadQuestions.length > 0) {
      await updateLeadFromConversation({ workspaceId, conversationId, leadQuestions }).catch(() => {});
    }

    await telegramSendMessage(botToken, chatId, finalReply);
  } catch (err) {
    console.error("Telegram reply error:", err);
    await releaseUsageReservation(workspaceId).catch(() => {});
    await telegramSendMessage(botToken, chatId, settings?.fallback_message ?? "حدث خطأ، حاول مرة أخرى.").catch(() => {});
  }

  return NextResponse.json({ ok: true });
}
