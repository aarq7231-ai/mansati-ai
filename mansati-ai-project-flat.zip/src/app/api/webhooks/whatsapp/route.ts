import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";
import { createAdminClient } from "@/lib/supabase/admin";
import { decryptSecret } from "@/lib/security/crypto";
import { whatsappSendText, type WhatsAppCredentials } from "@/lib/meta/whatsapp";
import { findOrCreateChannelConversation } from "@/lib/chat/find-or-create-channel-conversation";
import { checkAndIncrementUsage, recordTokenUsage, releaseUsageReservation } from "@/lib/usage/check-and-increment";
import { updateLeadFromConversation } from "@/lib/crm/lead-capture";
import { buildSystemPrompt } from "@/lib/chat/system-prompt";
import { retrieveRelevantChunks } from "@/lib/chat/knowledge";
import { routeModel } from "@/lib/ai/router";
import { completeNonStreaming } from "@/lib/ai/complete-non-streaming";
import { buildToolSet } from "@/lib/chat/tools";
import type { ChatMessage } from "@/lib/ai/types";

export const runtime = "nodejs";

const TRIAL_EXPIRED_MESSAGE_AR = "انتهت الفترة التجريبية. اشترك لمواصلة استخدام الوكيل.";
const LIMIT_REACHED_MESSAGE_AR = "عذراً، الرد الآلي متوقف مؤقتاً. يرجى التواصل مع صاحب النشاط.";

function timingSafeStringEqual(a: string, b: string) {
  const left = Buffer.from(a, "utf8");
  const right = Buffer.from(b, "utf8");
  return left.length === right.length && crypto.timingSafeEqual(left, right);
}

function verifyMetaSignature(rawBody: string, signature: string | null) {
  const appSecret = process.env.META_APP_SECRET;
  if (!appSecret || !signature?.startsWith("sha256=")) return false;
  const expected = crypto.createHmac("sha256", appSecret).update(rawBody, "utf8").digest("hex");
  return timingSafeStringEqual(expected, signature.slice("sha256=".length));
}

export async function GET(request: NextRequest) {
  const mode = request.nextUrl.searchParams.get("hub.mode");
  const token = request.nextUrl.searchParams.get("hub.verify_token");
  const challenge = request.nextUrl.searchParams.get("hub.challenge");
  const expected = process.env.META_WEBHOOK_VERIFY_TOKEN;

  if (mode === "subscribe" && token && challenge && expected && timingSafeStringEqual(token, expected)) {
    return new NextResponse(challenge, { status: 200 });
  }
  return new NextResponse("Forbidden", { status: 403 });
}

export async function POST(request: NextRequest) {
  const rawBody = await request.text();
  if (!verifyMetaSignature(rawBody, request.headers.get("x-hub-signature-256"))) {
    return NextResponse.json({ error: "invalid signature" }, { status: 401 });
  }

  const payload = JSON.parse(rawBody);
  if (payload?.object !== "whatsapp_business_account") return NextResponse.json({ ok: true });

  const admin = createAdminClient();

  for (const entry of Array.isArray(payload.entry) ? payload.entry : []) {
    for (const change of Array.isArray(entry.changes) ? entry.changes : []) {
      if (change?.field !== "messages") continue;
      const value = change.value;
      const phoneNumberId = String(value?.metadata?.phone_number_id || "");
      if (!phoneNumberId) continue;

      const { data: integration } = await admin
        .from("integrations")
        .select("id, workspace_id, agent_id, status, metadata")
        .eq("type", "whatsapp")
        .eq("status", "connected")
        .eq("metadata->>phone_number_id", phoneNumberId)
        .maybeSingle<any>();
      if (!integration?.agent_id) continue;

      const { data: cred } = await admin
        .from("integration_credentials")
        .select("encrypted_payload")
        .eq("integration_id", integration.id)
        .maybeSingle();
      if (!cred) continue;

      const credentials = JSON.parse(decryptSecret(cred.encrypted_payload)) as WhatsAppCredentials;
      const workspaceId = integration.workspace_id as string;
      const agentId = integration.agent_id as string;
      const { data: workspace } = await admin.from("workspaces").select("is_suspended, timezone").eq("id", workspaceId).single();
      if (workspace?.is_suspended) continue;

      const { data: agent } = await admin
        .from("agents")
        .select("id, name, is_active, agent_settings(*)")
        .eq("id", agentId)
        .maybeSingle<any>();
      if (!agent || !agent.is_active) continue;
      const settings = agent.agent_settings;

      for (const message of Array.isArray(value?.messages) ? value.messages : []) {
        if (message?.type !== "text" || !message?.text?.body || !message?.from) continue;
        const text = String(message.text.body).trim();
        const sender = String(message.from);
        if (!text) continue;

        const { conversationId, status } = await findOrCreateChannelConversation({
          workspaceId,
          agentId,
          channel: "whatsapp",
          externalThreadId: sender
        });

        await admin.from("messages").insert({
          workspace_id: workspaceId,
          conversation_id: conversationId,
          role: "user",
          content: text,
          metadata: { whatsapp_message_id: message.id, whatsapp_from: sender }
        });

        if (status === "human_active") continue;

        const { data: subscription } = await admin
          .from("subscriptions")
          .select("status, trial_ends_at")
          .eq("workspace_id", workspaceId)
          .maybeSingle();
        const isTrialActive = subscription?.status === "trialing" && subscription.trial_ends_at && new Date(subscription.trial_ends_at).getTime() > Date.now();
        const isPaidActive = subscription?.status === "active";
        if (!isTrialActive && !isPaidActive) {
          await whatsappSendText(phoneNumberId, credentials.accessToken, sender, TRIAL_EXPIRED_MESSAGE_AR).catch(() => {});
          continue;
        }

        const usage = await checkAndIncrementUsage(workspaceId);
        if (!usage.allowed) {
          await whatsappSendText(phoneNumberId, credentials.accessToken, sender, LIMIT_REACHED_MESSAGE_AR).catch(() => {});
          continue;
        }

        const { data: history } = await admin
          .from("messages")
          .select("role, content")
          .eq("conversation_id", conversationId)
          .order("created_at", { ascending: true })
          .limit(10);
        const knowledgeChunks = await retrieveRelevantChunks({ workspaceId, agentId, query: text });
        const toolSet = await buildToolSet({ workspaceId, agentId, allowedActions: settings?.allowed_actions, webhookUrl: settings?.webhook_url });
        const systemMessage = buildSystemPrompt({
          agentName: agent.name,
          businessName: "",
          language: settings?.language ?? "ar",
          personality: settings?.personality ?? null,
          tone: settings?.tone ?? null,
          systemInstructions: settings?.system_instructions ?? null,
          fallbackMessage: settings?.fallback_message ?? TRIAL_EXPIRED_MESSAGE_AR,
          rules: settings?.rules ?? [],
          knowledgeContext: knowledgeChunks,
          timezone: workspace?.timezone,
          hasTools: !!toolSet
        });
        const conversationMessages: ChatMessage[] = (history ?? []).map((m: any) => ({ role: m.role === "staff" ? "assistant" : (m.role as ChatMessage["role"]), content: m.content }));
        const { provider, model } = routeModel({ preferredProvider: settings?.ai_provider, preferredModel: settings?.ai_model });

        try {
          let finalReply = "";
          let inputTokens = 0;
          let outputTokens = 0;
          if (toolSet && provider.completeWithTools) {
            const result = await provider.completeWithTools({ messages: [systemMessage, ...conversationMessages], tools: toolSet.definitions, executeTool: toolSet.executeTool, model });
            finalReply = result.text || settings?.fallback_message || "عذراً، لم أتمكن من الإجابة حالياً.";
            inputTokens = result.usage?.inputTokens || 0;
            outputTokens = result.usage?.outputTokens || 0;
            for (const call of result.toolCalls) {
              await admin.from("audit_logs").insert({ workspace_id: workspaceId, action: `tool_call:${call.name}`, target_table: "conversations", target_id: conversationId, metadata: { args: call.args, result: call.result } });
            }
          } else {
            const result = await completeNonStreaming(provider, { messages: [systemMessage, ...conversationMessages], model });
            finalReply = result.text || settings?.fallback_message || "عذراً، لم أتمكن من الإجابة حالياً.";
            inputTokens = result.inputTokens;
            outputTokens = result.outputTokens;
          }

          await admin.from("messages").insert({ workspace_id: workspaceId, conversation_id: conversationId, role: "assistant", content: finalReply, output_tokens: outputTokens || null });
          await recordTokenUsage(workspaceId, inputTokens, outputTokens);
          const leadQuestions = Array.isArray(settings?.lead_questions) ? settings.lead_questions : [];
          if (leadQuestions.length > 0) await updateLeadFromConversation({ workspaceId, conversationId, leadQuestions }).catch(() => {});
          await whatsappSendText(phoneNumberId, credentials.accessToken, sender, finalReply);
        } catch (err) {
          console.error("WhatsApp reply error:", err);
          await releaseUsageReservation(workspaceId).catch(() => {});
          await whatsappSendText(phoneNumberId, credentials.accessToken, sender, settings?.fallback_message ?? "حدث خطأ، حاول مرة أخرى.").catch(() => {});
        }
      }
    }
  }

  return NextResponse.json({ ok: true });
}
