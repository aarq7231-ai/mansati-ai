import { NextRequest, NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { getBillingProvider } from "@/lib/billing";

export const runtime = "nodejs";

/**
 * Handles webhooks from whichever billing provider is active. Signature
 * verification happens inside the provider adapter (it knows its own
 * header name/secret format) — this route just normalizes the result and
 * writes it to `subscriptions`, so it never needs to change when a new
 * payment provider is added.
 */
export async function POST(request: NextRequest) {
  const rawBody = await request.text();
  const signature = request.headers.get("stripe-signature"); // header name is provider-specific; extend when adding others

  const billingProvider = getBillingProvider();
  const admin = createAdminClient();

  let event;
  try {
    event = await billingProvider.verifyWebhook(rawBody, signature);
  } catch (err: any) {
    return NextResponse.json({ error: `Webhook verification failed: ${err?.message}` }, { status: 400 });
  }

  switch (event.type) {
    case "checkout_completed": {
      const { data: pro } = await admin.from("plans").select("id").eq("key", "pro").single();
      await admin
        .from("subscriptions")
        .update({
          plan_id: pro?.id,
          status: "active",
          billing_provider: "stripe",
          provider_customer_id: event.providerCustomerId,
          provider_subscription_id: event.providerSubscriptionId,
          current_period_start: event.currentPeriodStart,
          current_period_end: event.currentPeriodEnd,
          canceled_at: null
        })
        .eq("workspace_id", event.workspaceId);

      await applyReferralRewardIfAny(admin, event.workspaceId);
      break;
    }
    case "payment_failed": {
      await admin
        .from("subscriptions")
        .update({ status: "past_due" })
        .eq("provider_subscription_id", event.providerSubscriptionId);
      break;
    }
    case "subscription_canceled": {
      await admin
        .from("subscriptions")
        .update({ status: "canceled", canceled_at: new Date().toISOString() })
        .eq("provider_subscription_id", event.providerSubscriptionId);
      break;
    }
    case "subscription_renewed": {
      await admin
        .from("subscriptions")
        .update({
          status: "active",
          current_period_start: event.currentPeriodStart,
          current_period_end: event.currentPeriodEnd
        })
        .eq("provider_subscription_id", event.providerSubscriptionId);
      break;
    }
    case "ignored":
    default:
      break;
  }

  return NextResponse.json({ received: true });
}

/**
 * Spec section 31: "if the referred customer becomes paid, referrer
 * receives configurable reward." The reward here is a free month, applied
 * by extending the referrer's trial or current billing period by 30 days
 * — simple, unambiguous, and works whether the referrer is still trialing
 * or already paying.
 */
async function applyReferralRewardIfAny(admin: ReturnType<typeof createAdminClient>, referredWorkspaceId: string) {
  const { data: referral } = await admin
    .from("referrals")
    .select("id, referrer_workspace_id")
    .eq("referred_workspace_id", referredWorkspaceId)
    .eq("status", "signed_up")
    .maybeSingle();
  if (!referral) return;

  const THIRTY_DAYS_MS = 30 * 24 * 60 * 60 * 1000;

  const { data: referrerSub } = await admin
    .from("subscriptions")
    .select("status, trial_ends_at, current_period_end")
    .eq("workspace_id", referral.referrer_workspace_id)
    .maybeSingle();

  if (referrerSub?.status === "trialing" && referrerSub.trial_ends_at) {
    const extended = new Date(new Date(referrerSub.trial_ends_at).getTime() + THIRTY_DAYS_MS).toISOString();
    await admin.from("subscriptions").update({ trial_ends_at: extended }).eq("workspace_id", referral.referrer_workspace_id);
  } else if (referrerSub?.status === "active" && referrerSub.current_period_end) {
    const extended = new Date(new Date(referrerSub.current_period_end).getTime() + THIRTY_DAYS_MS).toISOString();
    await admin
      .from("subscriptions")
      .update({ current_period_end: extended })
      .eq("workspace_id", referral.referrer_workspace_id);
  }

  await admin
    .from("referrals")
    .update({ status: "converted", converted_at: new Date().toISOString(), reward_type: "free_month", reward_value: "30_days" })
    .eq("id", referral.id);

  await admin.from("notifications").insert({
    workspace_id: referral.referrer_workspace_id,
    type: "referral_reward",
    title: "حصلت على شهر مجاني!",
    body: "أحد الأشخاص الذين دعوتهم اشترك بالخطة المدفوعة — أضفنا 30 يوماً إلى اشتراكك مجاناً."
  });
}
