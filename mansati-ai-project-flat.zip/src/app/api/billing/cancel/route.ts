import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { getBillingProvider } from "@/lib/billing";

export async function POST() {
  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  const { data: membership } = await supabase
    .from("workspace_members")
    .select("workspace_id, role")
    .eq("user_id", user.id)
    .limit(1)
    .maybeSingle();

  if (!membership || !["owner", "admin"].includes(membership.role)) {
    return NextResponse.json({ error: "only the workspace owner/admin can manage billing" }, { status: 403 });
  }

  const admin = createAdminClient();
  const { data: subscription } = await admin
    .from("subscriptions")
    .select("status, provider_subscription_id, billing_provider")
    .eq("workspace_id", membership.workspace_id)
    .maybeSingle();

  if (!subscription?.provider_subscription_id || subscription.status !== "active") {
    return NextResponse.json({ error: "لا يوجد اشتراك نشط لإلغائه" }, { status: 400 });
  }

  try {
    const billingProvider = getBillingProvider(subscription.billing_provider ?? undefined);
    await billingProvider.cancelSubscription(subscription.provider_subscription_id);
    // The provider's webhook (customer.subscription.deleted) will flip the
    // row to `canceled` — but update it here too so the UI reflects the
    // change immediately instead of waiting on webhook delivery.
    await admin
      .from("subscriptions")
      .update({ status: "canceled", canceled_at: new Date().toISOString() })
      .eq("workspace_id", membership.workspace_id);

    return NextResponse.json({ ok: true });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? "تعذر إلغاء الاشتراك" }, { status: 500 });
  }
}
