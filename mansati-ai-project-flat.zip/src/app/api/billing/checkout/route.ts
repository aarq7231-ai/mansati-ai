import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { getBillingProvider } from "@/lib/billing";

export async function POST(request: NextRequest) {
  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  const body = await request.json().catch(() => null);
  const planId = String(body?.planId || "");
  if (!planId) return NextResponse.json({ error: "planId is required" }, { status: 400 });

  const { data: membership } = await supabase
    .from("workspace_members")
    .select("workspace_id, role")
    .eq("user_id", user.id)
    .limit(1)
    .maybeSingle();

  if (!membership || !["owner", "admin"].includes(membership.role)) {
    return NextResponse.json({ error: "only the workspace owner/admin can manage billing" }, { status: 403 });
  }

  const billingProvider = getBillingProvider();
  const appUrl = process.env.NEXT_PUBLIC_APP_URL!;

  try {
    const { url } = await billingProvider.createCheckoutSession({
      workspaceId: membership.workspace_id,
      planId,
      customerEmail: user.email ?? undefined,
      successUrl: `${appUrl}/dashboard/billing?checkout=success`,
      cancelUrl: `${appUrl}/dashboard/billing?checkout=canceled`
    });
    return NextResponse.json({ url });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? "checkout failed" }, { status: 500 });
  }
}
