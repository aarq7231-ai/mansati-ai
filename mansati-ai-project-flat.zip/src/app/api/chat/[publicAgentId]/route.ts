import { NextRequest } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { routeModel } from "@/lib/ai/router";
import { buildSystemPrompt } from "@/lib/chat/system-prompt";
import { retrieveRelevantChunks } from "@/lib/chat/knowledge";
import { checkAndIncrementUsage, recordTokenUsage, releaseUsageReservation } from "@/lib/usage/check-and-increment";
import { ensureContactAndLead, updateLeadFromConversation } from "@/lib/crm/lead-capture";
import { buildToolSet } from "@/lib/chat/tools";
import type { ChatMessage } from "@/lib/ai/types";

export const runtime = "nodejs";

// The widget script runs on arbitrary business websites (spec section 12),
// so this endpoint must accept cross-origin requests. It exposes nothing
// sensitive — only the public agent id is required, same as the standalone
// public chat page.
const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type"
};

export async function OPTIONS() {
  return new Response(null, { status: 204, headers: CORS_HEADERS });
}


const TRIAL_EXPIRED_MESSAGE_AR =
  "انتهت الفترة التجريبية. اشترك بـ $5 شهرياً لمواصلة استخدام الوكيل.";
const LIMIT_REACHED_MESSAGE_AR =
  "عذراً، الرد الآلي متوقف مؤقتاً. يرجى التواصل مع صاحب النشاط.";
const HANDOFF_ACTIVE_MESSAGE_AR =
  "تم تحويل هذه المحادثة إلى أحد الموظفين، سيتم الرد عليك قريباً.";

/**
 * Sends a single, non-streamed text reply to the client using the same
 * SSE-ish line protocol as the real streaming path, so the frontend
 * doesn't need two code paths for "blocked" vs "AI answered".
 */
function staticReplyStream(text: string, conversationId: string | null) {
  const encoder = new TextEncoder();
  return new ReadableStream<Uint8Array>({
    start(controller) {
      controller.enqueue(encoder.encode(`data: ${JSON.stringify({ delta: text })}\n\n`));
      controller.enqueue(
        encoder.encode(`data: ${JSON.stringify({ done: true, conversationId })}\n\n`)
      );
      controller.close();
    }
  });
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ publicAgentId: string }> }
) {
  const { publicAgentId } = await params;
  const body = await request.json().catch(() => null);
  const userMessage = String(body?.message || "").trim();
  const incomingConversationId = body?.conversationId ? String(body.conversationId) : null;

  if (!userMessage) {
    return new Response(JSON.stringify({ error: "message is required" }), { status: 400, headers: CORS_HEADERS });
  }

  const admin = createAdminClient();

  // 1. Resolve the agent by its public id. Public/unauthenticated callers
  //    only ever get this — never the internal workspace UUID directly.
  const { data: agent } = await admin
    .from("agents")
    .select("id, workspace_id, name, is_active, agent_settings(*)")
    .eq("public_agent_id", publicAgentId)
    .eq("is_active", true)
    .maybeSingle<any>();

  if (!agent) {
    return new Response(JSON.stringify({ error: "agent not found" }), { status: 404, headers: CORS_HEADERS });
  }

  const settings = agent.agent_settings;
  const workspaceId = agent.workspace_id as string;

  const { data: workspace } = await admin
    .from("workspaces")
    .select("id, name, is_suspended, timezone")
    .eq("id", workspaceId)
    .single();

  if (workspace?.is_suspended) {
    return new Response(
      JSON.stringify({ error: "This agent's workspace has been suspended." }),
      { status: 403, headers: CORS_HEADERS }
    );
  }

  // 2. Resolve or create the conversation.
  let conversationId = incomingConversationId;
  let conversationStatus: string | null = null;

  if (conversationId) {
    const { data: existing } = await admin
      .from("conversations")
      .select("id, status")
      .eq("id", conversationId)
      .eq("agent_id", agent.id)
      .maybeSingle();
    conversationStatus = existing?.status ?? null;
    if (!existing) conversationId = null; // stale/foreign id — start fresh below
  }

  let isNewConversation = false;

  if (!conversationId) {
    const { data: created } = await admin
      .from("conversations")
      .insert({ workspace_id: workspaceId, agent_id: agent.id, channel: "website" })
      .select("id, status")
      .single();
    conversationId = created?.id ?? null;
    conversationStatus = created?.status ?? "ai_active";
    isNewConversation = true;
  }

  if (!conversationId) {
    return new Response(JSON.stringify({ error: "could not start conversation" }), { status: 500, headers: CORS_HEADERS });
  }

  if (isNewConversation) {
    // Fire-and-forget style, but awaited: this is a fast insert, not worth
    // a background queue. Spec section 20 — automatic lead creation.
    await ensureContactAndLead({ workspaceId, conversationId, channel: "website" }).catch(() => {});
  }

  // 3. Persist the user's message regardless of what happens next.
  await admin.from("messages").insert({
    workspace_id: workspaceId,
    conversation_id: conversationId,
    role: "user",
    content: userMessage
  });

  // 4. Human handoff: if a staff member has taken over, the AI stays silent.
  if (conversationStatus === "human_active") {
    return new Response(staticReplyStream(HANDOFF_ACTIVE_MESSAGE_AR, conversationId), {
      headers: { "Content-Type": "text/event-stream", ...CORS_HEADERS }
    });
  }

  // 5. Trial/subscription gate (spec section 29) — checked server-side, never trusted from the client.
  const { data: subscription } = await admin
    .from("subscriptions")
    .select("status, trial_ends_at")
    .eq("workspace_id", workspaceId)
    .maybeSingle();

  const isTrialActive =
    subscription?.status === "trialing" &&
    subscription.trial_ends_at &&
    new Date(subscription.trial_ends_at).getTime() > Date.now();
  const isPaidActive = subscription?.status === "active";

  if (!isTrialActive && !isPaidActive) {
    return new Response(staticReplyStream(TRIAL_EXPIRED_MESSAGE_AR, conversationId), {
      headers: { "Content-Type": "text/event-stream", ...CORS_HEADERS }
    });
  }

  // 6. Usage gate — atomically reserves one AI-reply slot. The reservation is released if generation fails.
  const usage = await checkAndIncrementUsage(workspaceId);
  if (!usage.allowed) {
    return new Response(staticReplyStream(LIMIT_REACHED_MESSAGE_AR, conversationId), {
      headers: { "Content-Type": "text/event-stream", ...CORS_HEADERS }
    });
  }

  // 7. Build context: recent history + retrieved knowledge (stubbed until the RAG phase).
  const { data: history } = await admin
    .from("messages")
    .select("role, content")
    .eq("conversation_id", conversationId)
    .order("created_at", { ascending: true })
    .limit(10);

  const knowledgeChunks = await retrieveRelevantChunks({
    workspaceId,
    agentId: agent.id,
    query: userMessage
  });

  const toolSet = await buildToolSet({
    workspaceId,
    agentId: agent.id,
    allowedActions: settings?.allowed_actions,
    webhookUrl: settings?.webhook_url
  });

  const systemMessage = buildSystemPrompt({
    agentName: agent.name,
    businessName: workspace?.name ?? "",
    language: settings?.language ?? "ar",
    personality: settings?.personality ?? null,
    tone: settings?.tone ?? null,
    systemInstructions: settings?.system_instructions ?? null,
    fallbackMessage: settings?.fallback_message ?? TRIAL_EXPIRED_MESSAGE_AR,
    rules: settings?.rules ?? [],
    knowledgeContext: knowledgeChunks,
    timezone: workspace?.timezone,
    hasTools: !!toolSet
  });

  const conversationMessages: ChatMessage[] = (history ?? []).map((m: any) => ({
    role: m.role === "staff" ? "assistant" : (m.role as ChatMessage["role"]),
    content: m.content
  }));

  const { provider, model } = routeModel({
    preferredProvider: settings?.ai_provider,
    preferredModel: settings?.ai_model
  });

  // 8. Stream the completion back to the client, persisting once it's done.
  const encoder = new TextEncoder();
  let fullText = "";

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      try {
        if (toolSet && provider.completeWithTools) {
          // Tool-enabled turn: the model may need one or more round-trips
          // to call a function before it has a final answer, so this
          // can't be a live token stream from the provider. We still
          // honor the client's SSE contract by sending the finished text
          // as a single delta — same shape, just not incremental.
          const { text, toolCalls, usage } = await provider.completeWithTools({
            messages: [systemMessage, ...conversationMessages],
            tools: toolSet.definitions,
            executeTool: toolSet.executeTool,
            model
          });
          fullText = text || settings?.fallback_message || TRIAL_EXPIRED_MESSAGE_AR;

          if (fullText) {
            controller.enqueue(encoder.encode(`data: ${JSON.stringify({ delta: fullText })}\n\n`));
          }

          await admin.from("messages").insert({
            workspace_id: workspaceId,
            conversation_id: conversationId,
            role: "assistant",
            content: fullText,
            output_tokens: usage?.outputTokens ?? null
          });

          if (usage) {
            await recordTokenUsage(workspaceId, usage.inputTokens, usage.outputTokens);
          }

          for (const call of toolCalls) {
            await admin.from("audit_logs").insert({
              workspace_id: workspaceId,
              action: `tool_call:${call.name}`,
              target_table: "conversations",
              target_id: conversationId,
              metadata: { args: call.args, result: call.result }
            });
          }

          const leadQuestions = Array.isArray(settings?.lead_questions) ? settings.lead_questions : [];
          if (leadQuestions.length > 0) {
            await updateLeadFromConversation({ workspaceId, conversationId, leadQuestions }).catch(() => {});
          }

          controller.enqueue(encoder.encode(`data: ${JSON.stringify({ done: true, conversationId })}\n\n`));
          return; // falls through to `finally`, which closes the controller exactly once
        }

        for await (const chunk of provider.streamCompletion({
          messages: [systemMessage, ...conversationMessages],
          model
        })) {
          if (chunk.delta) {
            fullText += chunk.delta;
            controller.enqueue(encoder.encode(`data: ${JSON.stringify({ delta: chunk.delta })}\n\n`));
          }
          if (chunk.done) {
            await admin.from("messages").insert({
              workspace_id: workspaceId,
              conversation_id: conversationId,
              role: "assistant",
              content: fullText || settings?.fallback_message,
              output_tokens: chunk.usage?.outputTokens ?? null
            });
            if (chunk.usage) {
              await recordTokenUsage(workspaceId, chunk.usage.inputTokens, chunk.usage.outputTokens);
            }
            const leadQuestions = Array.isArray(settings?.lead_questions) ? settings.lead_questions : [];
            if (leadQuestions.length > 0) {
              // Awaited (not fire-and-forget): serverless functions can be
              // frozen immediately after the response completes, so a
              // detached promise here could simply never finish.
              await updateLeadFromConversation({ workspaceId, conversationId, leadQuestions }).catch(() => {});
            }
            controller.enqueue(
              encoder.encode(`data: ${JSON.stringify({ done: true, conversationId })}\n\n`)
            );
          }
        }
      } catch (err) {
        console.error("Chat stream error:", err);
        await releaseUsageReservation(workspaceId).catch(() => {});
        controller.enqueue(
          encoder.encode(
            `data: ${JSON.stringify({ delta: settings?.fallback_message ?? "حدث خطأ، حاول مرة أخرى." })}\n\n`
          )
        );
        controller.enqueue(
          encoder.encode(`data: ${JSON.stringify({ done: true, conversationId })}\n\n`)
        );
      } finally {
        controller.close();
      }
    }
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
      ...CORS_HEADERS
    }
  });
}
