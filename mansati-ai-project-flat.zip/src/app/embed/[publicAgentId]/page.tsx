import { createAdminClient } from "@/lib/supabase/admin";
import ChatWidget from "@/components/chat-widget";

/**
 * Loaded inside the iframe that public/widget.js injects onto a business's
 * website. Deliberately bare — no header/nav — since the widget script
 * supplies its own floating launcher chrome around this iframe.
 */
export default async function EmbedPage({ params }: { params: Promise<{ publicAgentId: string }> }) {
  const { publicAgentId } = await params;
  const admin = createAdminClient();
  const { data: agent } = await admin
    .from("agents")
    .select("name, is_active, agent_settings(welcome_message, branding)")
    .eq("public_agent_id", publicAgentId)
    .maybeSingle<any>();

  if (!agent || !agent.is_active) {
    return (
      <div className="flex h-screen items-center justify-center p-4 text-center text-sm text-slate-400">
        هذا الوكيل غير متاح حالياً.
      </div>
    );
  }

  const branding = agent.agent_settings?.branding ?? {};

  return (
    <div className="flex h-screen flex-col bg-white dark:bg-slate-950">
      <div className="flex items-center gap-2 border-b p-3">
        {branding.logo_url && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={branding.logo_url} alt="" className="h-6 w-6 rounded-full object-cover" />
        )}
        <p className="text-sm font-medium">{agent.name}</p>
      </div>
      <div className="flex-1 p-2">
          <ChatWidget publicAgentId={publicAgentId} primaryColor={branding.primary_color} fill />
      </div>
    </div>
  );
}
