import Link from "next/link";

export default function NotFound() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-3 p-8 text-center">
      <h1 className="text-3xl font-bold">404</h1>
      <p className="text-slate-500">هذه الصفحة غير موجودة.</p>
      <Link href="/" className="mt-2 rounded-lg bg-brand-500 px-5 py-2.5 text-sm text-white">
        العودة للصفحة الرئيسية
      </Link>
    </main>
  );
}
