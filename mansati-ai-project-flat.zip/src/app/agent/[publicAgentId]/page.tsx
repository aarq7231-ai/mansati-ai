import { createAdminClient } from "@/lib/supabase/admin";
import ChatWidget from "@/components/chat-widget";

export default async function PublicAgentPage({
  params
}: {
  params: Promise<{ publicAgentId: string }>;
}) {
  const { publicAgentId } = await params;
  const admin = createAdminClient();
  const { data: agent } = await admin
    .from("agents")
    .select("name, is_active, agent_settings(welcome_message, branding)")
    .eq("public_agent_id", publicAgentId)
    .maybeSingle<any>();

  if (!agent || !agent.is_active) {
    return (
      <main className="flex min-h-screen items-center justify-center p-8 text-center text-slate-500">
        هذا الوكيل غير متاح حالياً.
      </main>
    );
  }

  const branding = agent.agent_settings?.branding ?? {};

  return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-4 p-6">
      <h1 className="text-xl font-semibold">{agent.name}</h1>
      {agent.agent_settings?.welcome_message && (
        <p className="text-sm text-slate-500">{agent.agent_settings.welcome_message}</p>
      )}
      <ChatWidget publicAgentId={publicAgentId} primaryColor={branding.primary_color} />
    </main>
  );
}
