"use client";

import { useEffect } from "react";

export default function GlobalError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error("Unhandled error:", error);
  }, [error]);

  return (
    <html lang="ar" dir="rtl">
      <body className="flex min-h-screen flex-col items-center justify-center gap-3 p-8 text-center">
        <h1 className="text-xl font-semibold">حدث خطأ غير متوقع</h1>
        <p className="text-sm text-slate-500">يرجى إعادة تحميل الصفحة أو المحاولة لاحقاً.</p>
        <button onClick={() => reset()} className="mt-2 rounded-lg bg-brand-500 px-5 py-2.5 text-sm text-white">
          إعادة المحاولة
        </button>
      </body>
    </html>
  );
}
