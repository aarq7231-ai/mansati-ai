export default function OnboardingLoading() {
  return (
    <main className="mx-auto flex min-h-screen max-w-lg flex-col justify-center gap-3 p-8">
      <div className="animate-pulse space-y-3">
        <div className="h-6 w-64 rounded bg-slate-200 dark:bg-slate-800" />
        <div className="h-4 w-80 rounded bg-slate-100 dark:bg-slate-900" />
        {[1, 2, 3, 4, 5].map((i) => (
          <div key={i} className="h-11 rounded-lg bg-slate-100 dark:bg-slate-900" />
        ))}
      </div>
    </main>
  );
}
