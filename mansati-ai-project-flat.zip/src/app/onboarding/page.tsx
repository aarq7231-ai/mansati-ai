import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { getCurrentWorkspace } from "@/lib/workspace/current";

function slugify(name: string) {
  return (
    name
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9\u0600-\u06FF]+/g, "-")
      .replace(/(^-|-$)/g, "") || "workspace"
  );
}

async function completeOnboarding(formData: FormData) {
  "use server";

  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const businessName = String(formData.get("business_name") || "").trim();
  const businessType = String(formData.get("business_type") || "").trim();
  const country = String(formData.get("country") || "").trim();
  const language = String(formData.get("language") || "ar");
  const description = String(formData.get("description") || "").trim();
  const websiteUrl = String(formData.get("website_url") || "").trim() || null;
  const agentName = String(formData.get("agent_name") || "الموظف الذكي").trim();

  if (!businessName || !businessType) {
    redirect("/onboarding?error=" + encodeURIComponent("يرجى تعبئة اسم ونوع النشاط التجاري"));
  }

  const baseSlug = slugify(businessName);
  const slug = `${baseSlug}-${Math.random().toString(36).slice(2, 7)}`;
  const referralCode = Math.random().toString(36).slice(2, 10);

  // 1. Create the workspace (tenant)
  const { data: workspace, error: wsError } = await supabase
    .from("workspaces")
    .insert({
      name: businessName,
      slug,
      business_type: businessType,
      country,
      preferred_language: language,
      business_description: description,
      website_url: websiteUrl,
      onboarding_completed: true,
      referral_code: referralCode
    })
    .select()
    .single();

  if (wsError || !workspace) {
    redirect("/onboarding?error=" + encodeURIComponent("تعذر إنشاء مساحة العمل. حاول مرة أخرى."));
    return;
  }

  // 1b. If this user signed up via someone's referral link, log it now that
  // a workspace actually exists to attach it to (spec section 31).
  const refCode = (user.user_metadata as any)?.ref_code as string | undefined;
  if (refCode) {
    const admin = createAdminClient();
    const { data: referrer } = await admin
      .from("workspaces")
      .select("id")
      .eq("referral_code", refCode)
      .maybeSingle();
    if (referrer && referrer.id !== workspace.id) {
      await admin.from("referrals").insert({
        referrer_workspace_id: referrer.id,
        referred_workspace_id: workspace.id,
        code: refCode,
        status: "signed_up"
      });
    }
  }

  // 2. Make the signed-up user the owner
  const { error: memberError } = await supabase.from("workspace_members").insert({
    workspace_id: workspace.id,
    user_id: user.id,
    role: "owner"
  });
  if (memberError) {
    redirect("/onboarding?error=" + encodeURIComponent("تعذر ربط الحساب بمساحة العمل."));
    return;
  }

  // 3. Start the trial subscription (3 days, no card) against the 'trial' plan
  const { data: trialPlan } = await supabase.from("plans").select("id").eq("key", "trial").single();
  if (trialPlan) {
    await supabase.from("subscriptions").insert({
      workspace_id: workspace.id,
      plan_id: trialPlan.id,
      status: "trialing"
    });
  }

  // 4. Look up a template for this business type (spec section 33) — gives
  //    the new agent a real starting personality/tone/FAQ/lead-questions
  //    instead of a blank slate. Falls back gracefully if none matches.
  const { data: template } = await supabase
    .from("agent_templates")
    .select("*")
    .eq("business_type", businessType)
    .eq("is_marketplace_item", false)
    .maybeSingle();

  const { data: agent } = await supabase
    .from("agents")
    .insert({ workspace_id: workspace.id, name: agentName, template_id: template?.id ?? null })
    .select()
    .single();

  if (agent) {
    const systemInstructions = template
      ? `أنت ${agentName}, الموظف الذكي لشركة "${businessName}". ${description}\n\n${template.suggested_system_instructions}`
      : `أنت ${agentName}, الموظف الذكي لشركة "${businessName}" (${businessType}). ${description}`;

    await supabase.from("agent_settings").insert({
      agent_id: agent.id,
      language,
      tone: template?.suggested_tone ?? null,
      welcome_message: template?.suggested_greeting ?? `مرحباً! أنا ${agentName}، كيف أقدر أساعدك اليوم؟`,
      system_instructions: systemInstructions,
      lead_questions: template?.suggested_lead_questions ?? [],
      allowed_actions: template?.suggested_actions ?? []
    });
  }

  redirect("/dashboard");
}

export default async function OnboardingPage({
  searchParams
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const params = await searchParams;
  const { user, workspace } = await getCurrentWorkspace();
  if (!user) redirect("/login");
  if (workspace) redirect("/dashboard"); // already onboarded

  return (
    <main className="mx-auto flex min-h-screen max-w-lg flex-col justify-center gap-4 p-8">
      <h1 className="text-2xl font-bold">أخبرنا عن نشاطك التجاري</h1>
      <p className="text-sm text-slate-500">هذا يساعدنا في إنشاء موظفك الذكي الأول تلقائياً.</p>

      {params.error && (
        <p className="rounded-md bg-red-50 p-3 text-sm text-red-600">{params.error}</p>
      )}

      <form action={completeOnboarding} className="flex flex-col gap-3">
        <input name="business_name" placeholder="اسم النشاط التجاري" className="rounded-lg border px-4 py-2.5" required />

        <select name="business_type" className="rounded-lg border px-4 py-2.5" required defaultValue="">
          <option value="" disabled>نوع النشاط التجاري</option>
          <option value="restaurant">مطعم</option>
          <option value="hotel">فندق</option>
          <option value="clinic">عيادة</option>
          <option value="store">متجر</option>
          <option value="real_estate">عقارات</option>
          <option value="salon">صالون</option>
          <option value="gym">نادي رياضي</option>
          <option value="car_dealership">معرض سيارات</option>
          <option value="school">مدرسة / معهد</option>
          <option value="service_business">أعمال خدمية</option>
          <option value="other">أخرى</option>
        </select>

        <input name="country" placeholder="الدولة" className="rounded-lg border px-4 py-2.5" />

        <select name="language" className="rounded-lg border px-4 py-2.5" defaultValue="ar">
          <option value="ar">العربية</option>
          <option value="en">English</option>
        </select>

        <textarea
          name="description"
          placeholder="صف نشاطك التجاري باختصار"
          className="min-h-24 rounded-lg border px-4 py-2.5"
        />

        <input name="website_url" placeholder="رابط الموقع الإلكتروني (اختياري)" className="rounded-lg border px-4 py-2.5" />

        <input
          name="agent_name"
          placeholder="اسم الموظف الذكي"
          className="rounded-lg border px-4 py-2.5"
          defaultValue="سارة"
        />

        <button type="submit" className="rounded-lg bg-brand-500 px-4 py-2.5 font-medium text-white">
          إنشاء الموظف الذكي
        </button>
      </form>
    </main>
  );
}
