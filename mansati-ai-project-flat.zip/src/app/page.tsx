import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { getLang } from "@/lib/i18n/get-lang";
import { getDictionary } from "@/lib/i18n/dictionaries";
import LangSwitcher from "@/components/lang-switcher";
import ThemeToggle from "@/components/theme-toggle";

export default async function HomePage() {
  const lang = await getLang();
  const t = getDictionary(lang);

  const supabase = await createClient();
  const { data: plans } = await supabase
    .from("plans")
    .select("id, name, price_cents")
    .eq("is_public", true)
    .eq("is_active", true)
    .order("sort_order", { ascending: true });

  return (
    <main className="min-h-screen">
      {/* Header */}
      <header className="mx-auto flex max-w-6xl items-center justify-between p-6">
        <span className="text-xl font-bold">
          {lang === "ar" ? "منصتي AI" : "Mansati AI"}
        </span>
        <nav className="flex items-center gap-3">
          <LangSwitcher current={lang} />
          <ThemeToggle />
          <Link href="/login" className="rounded-lg border px-4 py-2 text-sm">
            {t.nav.login}
          </Link>
          <Link href="/signup" className="rounded-lg bg-brand-500 px-4 py-2 text-sm text-white">
            {t.nav.signup}
          </Link>
        </nav>
      </header>

      {/* Hero */}
      <section className="mx-auto max-w-4xl px-6 py-20 text-center">
        <h1 className="text-4xl font-bold leading-tight md:text-6xl">{t.hero.title}</h1>
        <p className="mx-auto mt-6 max-w-2xl text-lg text-slate-500">{t.hero.subtitle}</p>
        <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <Link
            href="/signup"
            className="rounded-xl bg-brand-500 px-8 py-4 text-lg font-medium text-white shadow-lg shadow-brand-500/20"
          >
            {t.hero.cta}
          </Link>
          <a href="#features" className="rounded-xl border px-8 py-4 text-lg">
            {t.hero.secondaryCta}
          </a>
        </div>
        <p className="mt-3 text-sm text-slate-400">{t.hero.ctaNote}</p>
      </section>

      {/* Features */}
      <section id="features" className="mx-auto max-w-6xl px-6 py-16">
        <h2 className="text-center text-3xl font-bold">{t.features.title}</h2>
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {t.features.items.map((f) => (
            <div key={f.title} className="rounded-2xl border p-6">
              <h3 className="font-semibold">{f.title}</h3>
              <p className="mt-2 text-sm text-slate-500">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Use cases */}
      <section className="bg-slate-50 py-16 dark:bg-slate-900">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <h2 className="text-3xl font-bold">{t.useCases.title}</h2>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            {t.useCases.items.map((u) => (
              <span key={u} className="rounded-full border bg-white px-4 py-2 text-sm dark:bg-slate-800">
                {u}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="mx-auto max-w-4xl px-6 py-16 text-center">
        <h2 className="text-3xl font-bold">{t.pricing.title}</h2>
        <p className="mt-2 text-slate-500">{t.pricing.subtitle}</p>

        <div className="mx-auto mt-10 max-w-sm rounded-2xl border-2 border-brand-500 p-8">
          {plans
            ?.filter((p) => p.price_cents > 0)
            .slice(0, 1)
            .map((plan) => (
              <div key={plan.id}>
                <p className="text-sm text-slate-400">{t.pricing.trialNote}</p>
                <p className="mt-1 text-5xl font-bold">
                  ${(plan.price_cents / 100).toFixed(0)}
                  <span className="text-lg font-normal text-slate-400"> {t.pricing.perMonth}</span>
                </p>
                <p className="mt-2 text-sm text-slate-500">
                  {plan.message_limit} {t.pricing.messagesIncluded}
                </p>
                <Link
                  href="/signup"
                  className="mt-6 block rounded-xl bg-brand-500 px-6 py-3 font-medium text-white"
                >
                  {t.pricing.cta}
                </Link>
              </div>
            ))}
        </div>
      </section>

      {/* Testimonials placeholder */}
      <section className="bg-slate-50 py-16 dark:bg-slate-900">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <h2 className="text-3xl font-bold">{t.testimonials.title}</h2>
          <div className="mt-8 grid gap-4 sm:grid-cols-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="rounded-xl border bg-white p-5 text-sm text-slate-400 dark:bg-slate-800">
                {lang === "ar" ? "شهادة عميل قادمة قريباً" : "Customer testimonial coming soon"}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="mx-auto max-w-3xl px-6 py-16">
        <h2 className="text-center text-3xl font-bold">{t.faq.title}</h2>
        <div className="mt-8 flex flex-col gap-3">
          {t.faq.items.map((item) => (
            <details key={item.q} className="rounded-xl border p-4">
              <summary className="cursor-pointer font-medium">{item.q}</summary>
              <p className="mt-2 text-sm text-slate-500">{item.a}</p>
            </details>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t p-6 text-center text-sm text-slate-400">
        <p>
          {lang === "ar" ? "منصتي AI" : "Mansati AI"} · {t.footer.rights}
        </p>
      </footer>
    </main>
  );
}
