import { notFound } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";

async function getAdminUserId() {
  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  return user?.id ?? null;
}

async function logAdminAction(action: string, workspaceId: string, metadata: Record<string, unknown>) {
  const supabase = await createClient();
  const adminUserId = await getAdminUserId();
  if (!adminUserId) return;
  await supabase.from("admin_logs").insert({
    admin_user_id: adminUserId,
    action,
    target_workspace_id: workspaceId,
    metadata
  });
}

async function suspendWorkspace(workspaceId: string, formData: FormData) {
  "use server";
  const reason = String(formData.get("reason") || "").trim() || null;
  const supabase = await createClient();
  await supabase.from("workspaces").update({ is_suspended: true, suspended_reason: reason }).eq("id", workspaceId);
  await logAdminAction("suspend_workspace", workspaceId, { reason });
  revalidatePath(`/admin/workspaces/${workspaceId}`);
}

async function reactivateWorkspace(workspaceId: string) {
  "use server";
  const supabase = await createClient();
  await supabase.from("workspaces").update({ is_suspended: false, suspended_reason: null }).eq("id", workspaceId);
  await logAdminAction("reactivate_workspace", workspaceId, {});
  revalidatePath(`/admin/workspaces/${workspaceId}`);
}

async function changePlan(workspaceId: string, formData: FormData) {
  "use server";
  const planId = String(formData.get("plan_id") || "");
  if (!planId) return;
  const supabase = await createClient();
  await supabase.from("subscriptions").update({ plan_id: planId, status: "active" }).eq("workspace_id", workspaceId);
  await logAdminAction("change_plan", workspaceId, { plan_id: planId });
  revalidatePath(`/admin/workspaces/${workspaceId}`);
}

export default async function AdminWorkspaceDetailPage({ params }: { params: Promise<{ workspaceId: string }> }) {
  const { workspaceId } = await params;
  const supabase = await createClient();

  const { data: workspace } = await supabase
    .from("workspaces")
    .select("*")
    .eq("id", workspaceId)
    .maybeSingle();
  if (!workspace) notFound();

  const { data: subscription } = await supabase
    .from("subscriptions")
    .select("status, plan_id, trial_ends_at, current_period_end, plans(name)")
    .eq("workspace_id", workspaceId)
    .maybeSingle<any>();

  const { data: plans } = await supabase.from("plans").select("id, name").eq("is_active", true);
  const { data: agents } = await supabase.from("agents").select("id, name, is_active").eq("workspace_id", workspaceId);
  const { data: usage } = await supabase
    .from("usage")
    .select("ai_messages_used, storage_used_mb, period_start")
    .eq("workspace_id", workspaceId)
    .order("period_start", { ascending: false })
    .limit(1)
    .maybeSingle();

  const boundSuspend = suspendWorkspace.bind(null, workspace.id);
  const boundReactivate = reactivateWorkspace.bind(null, workspace.id);
  const boundChangePlan = changePlan.bind(null, workspace.id);

  return (
    <main className="mx-auto max-w-2xl p-8">
      <h1 className="text-2xl font-bold">{workspace.name}</h1>
      <p className="text-sm text-slate-400">{workspace.business_type} · {workspace.country}</p>

      {workspace.is_suspended && (
        <div className="mt-3 rounded-lg bg-red-50 p-3 text-sm text-red-700">
          هذه المساحة موقوفة. {workspace.suspended_reason && `السبب: ${workspace.suspended_reason}`}
        </div>
      )}

      <div className="mt-4 grid grid-cols-2 gap-3">
        <div className="rounded-lg border bg-white p-3 dark:bg-slate-900">
          <p className="text-xs text-slate-400">الخطة</p>
          <p className="font-medium">{subscription?.plans?.name ?? "—"}</p>
        </div>
        <div className="rounded-lg border bg-white p-3 dark:bg-slate-900">
          <p className="text-xs text-slate-400">الحالة</p>
          <p className="font-medium">{subscription?.status ?? "—"}</p>
        </div>
        <div className="rounded-lg border bg-white p-3 dark:bg-slate-900">
          <p className="text-xs text-slate-400">رسائل هذا الشهر</p>
          <p className="font-medium">{usage?.ai_messages_used ?? 0}</p>
        </div>
        <div className="rounded-lg border bg-white p-3 dark:bg-slate-900">
          <p className="text-xs text-slate-400">عدد الوكلاء</p>
          <p className="font-medium">{agents?.length ?? 0}</p>
        </div>
      </div>

      <div className="mt-6 rounded-xl border bg-white p-4 dark:bg-slate-900">
        <p className="mb-2 text-sm font-semibold">تغيير الخطة</p>
        <form action={boundChangePlan} className="flex gap-2">
          <select name="plan_id" defaultValue={subscription?.plan_id} className="flex-1 rounded-lg border px-3 py-2 text-sm">
            {plans?.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
          <button type="submit" className="rounded-lg bg-brand-500 px-4 py-2 text-sm text-white">
            تحديث
          </button>
        </form>
      </div>

      <div className="mt-4 rounded-xl border bg-white p-4 dark:bg-slate-900">
        <p className="mb-2 text-sm font-semibold">إيقاف / تفعيل الحساب</p>
        {workspace.is_suspended ? (
          <form action={boundReactivate}>
            <button type="submit" className="rounded-lg bg-emerald-500 px-4 py-2 text-sm text-white">
              إعادة تفعيل الحساب
            </button>
          </form>
        ) : (
          <form action={boundSuspend} className="flex gap-2">
            <input name="reason" placeholder="سبب الإيقاف (اختياري)" className="flex-1 rounded-lg border px-3 py-2 text-sm" />
            <button type="submit" className="rounded-lg bg-red-500 px-4 py-2 text-sm text-white">
              إيقاف الحساب
            </button>
          </form>
        )}
      </div>
    </main>
  );
}
