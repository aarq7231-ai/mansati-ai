import Link from "next/link";
import { createClient } from "@/lib/supabase/server";

export default async function AdminWorkspacesPage() {
  const supabase = await createClient();
  const { data: workspaces } = await supabase
    .from("workspaces")
    .select("id, name, business_type, is_suspended, created_at, subscriptions(status, plans(name))")
    .order("created_at", { ascending: false })
    .limit(200);

  return (
    <main className="mx-auto max-w-4xl p-8">
      <h1 className="text-2xl font-bold">مساحات العمل</h1>

      <ul className="mt-6 flex flex-col gap-2">
        {(!workspaces || workspaces.length === 0) && (
          <p className="text-sm text-slate-400">لا توجد مساحات عمل مسجّلة بعد.</p>
        )}
        {workspaces?.map((ws: any) => (
          <li key={ws.id}>
            <Link
              href={`/admin/workspaces/${ws.id}`}
              className="flex items-center justify-between rounded-lg border bg-white p-4 hover:bg-slate-50 dark:bg-slate-900"
            >
              <div>
                <p className="font-medium">{ws.name}</p>
                <p className="text-xs text-slate-400">
                  {ws.business_type} · {ws.subscriptions?.[0]?.plans?.name ?? "—"} ·{" "}
                  {ws.subscriptions?.[0]?.status ?? "—"}
                </p>
              </div>
              {ws.is_suspended && (
                <span className="rounded-full bg-red-100 px-3 py-1 text-xs text-red-600">موقوف</span>
              )}
            </Link>
          </li>
        ))}
      </ul>
    </main>
  );
}
