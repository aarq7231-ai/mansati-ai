import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";

async function updatePlan(planId: string, formData: FormData) {
  "use server";
  const supabase = await createClient();

  const name = String(formData.get("name") || "").trim();
  const priceCents = Math.round(parseFloat(String(formData.get("price") || "0")) * 100);
  const messageLimit = parseInt(String(formData.get("message_limit") || "0"), 10);
  const storageLimit = parseInt(String(formData.get("storage_limit_mb") || "0"), 10);
  const agentLimit = parseInt(String(formData.get("agent_limit") || "0"), 10);
  const fileLimit = parseInt(String(formData.get("file_limit") || "0"), 10);
  const isActive = formData.get("is_active") === "on";
  const isPublic = formData.get("is_public") === "on";

  await supabase
    .from("plans")
    .update({
      name,
      price_cents: priceCents,
      message_limit: messageLimit,
      storage_limit_mb: storageLimit,
      agent_limit: agentLimit,
      file_limit: fileLimit,
      is_active: isActive,
      is_public: isPublic
    })
    .eq("id", planId);

  revalidatePath("/admin/plans");
}

export default async function AdminPlansPage() {
  const supabase = await createClient();
  const { data: plans } = await supabase.from("plans").select("*").order("sort_order", { ascending: true });

  return (
    <main className="mx-auto max-w-3xl p-8">
      <h1 className="text-2xl font-bold">الخطط والأسعار</h1>
      <p className="text-sm text-slate-500">
        أي تغيير هنا يطبّق فوراً على كل مستخدمي المنصة، بدون الحاجة لتعديل الكود أو نشر تحديث جديد.
      </p>

      <div className="mt-6 flex flex-col gap-4">
        {plans?.map((plan) => {
          const boundUpdate = updatePlan.bind(null, plan.id);
          return (
            <form
              key={plan.id}
              action={boundUpdate}
              className="grid grid-cols-2 gap-3 rounded-xl border bg-white p-4 dark:bg-slate-900 md:grid-cols-3"
            >
              <input name="name" defaultValue={plan.name} className="rounded-lg border px-3 py-2 text-sm" placeholder="اسم الخطة" />
              <label className="flex items-center gap-2 text-sm">
                <span className="text-slate-400">السعر $</span>
                <input
                  name="price"
                  type="number"
                  step="0.01"
                  defaultValue={(plan.price_cents / 100).toFixed(2)}
                  className="w-24 rounded-lg border px-2 py-1.5"
                />
              </label>
              <label className="flex items-center gap-2 text-sm">
                <span className="text-slate-400">الرسائل/شهر</span>
                <input name="message_limit" type="number" defaultValue={plan.message_limit} className="w-24 rounded-lg border px-2 py-1.5" />
              </label>
              <label className="flex items-center gap-2 text-sm">
                <span className="text-slate-400">التخزين (MB)</span>
                <input name="storage_limit_mb" type="number" defaultValue={plan.storage_limit_mb} className="w-24 rounded-lg border px-2 py-1.5" />
              </label>
              <label className="flex items-center gap-2 text-sm">
                <span className="text-slate-400">عدد الوكلاء</span>
                <input name="agent_limit" type="number" defaultValue={plan.agent_limit} className="w-24 rounded-lg border px-2 py-1.5" />
              </label>
              <label className="flex items-center gap-2 text-sm">
                <span className="text-slate-400">عدد الملفات</span>
                <input name="file_limit" type="number" defaultValue={plan.file_limit} className="w-24 rounded-lg border px-2 py-1.5" />
              </label>
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" name="is_active" defaultChecked={plan.is_active} /> نشطة
              </label>
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" name="is_public" defaultChecked={plan.is_public} /> ظاهرة للجمهور
              </label>
              <button type="submit" className="rounded-lg bg-brand-500 px-4 py-2 text-sm text-white">
                حفظ
              </button>
            </form>
          );
        })}
      </div>
    </main>
  );
}
