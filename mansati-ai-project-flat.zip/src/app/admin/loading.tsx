export default function AdminLoading() {
  return (
    <main className="mx-auto max-w-4xl p-8">
      <div className="animate-pulse space-y-4">
        <div className="h-7 w-40 rounded bg-slate-200 dark:bg-slate-800" />
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
            <div key={i} className="h-20 rounded-xl bg-slate-100 dark:bg-slate-900" />
          ))}
        </div>
      </div>
    </main>
  );
}
