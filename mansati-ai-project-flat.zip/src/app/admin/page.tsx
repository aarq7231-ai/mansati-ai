import { createClient } from "@/lib/supabase/server";

/**
 * All queries here rely on the admin-scoped RLS policies (each relevant
 * table's select policy includes `or is_platform_admin()`) rather than the
 * service-role client — an admin genuinely can read cross-tenant data
 * because the database says so, not because this page bypasses anything.
 */
export default async function AdminOverviewPage() {
  const supabase = await createClient();

  const [
    { count: totalWorkspaces },
    { count: totalUsers },
    { data: subscriptions },
    { count: totalAgents },
    { data: usageRows }
  ] = await Promise.all([
    supabase.from("workspaces").select("id", { count: "exact", head: true }),
    supabase.from("profiles").select("id", { count: "exact", head: true }),
    supabase.from("subscriptions").select("status, plans(price_cents)"),
    supabase.from("agents").select("id", { count: "exact", head: true }),
    supabase.from("usage").select("ai_messages_used").eq("period_start", new Date().toISOString().slice(0, 7) + "-01")
  ]);

  const trialCount = subscriptions?.filter((s) => s.status === "trialing").length ?? 0;
  const activeCount = subscriptions?.filter((s) => s.status === "active").length ?? 0;
  const pastDueCount = subscriptions?.filter((s) => s.status === "past_due").length ?? 0;
  const mrrCents =
    subscriptions
      ?.filter((s) => s.status === "active")
      .reduce((sum, s: any) => sum + (s.plans?.price_cents ?? 0), 0) ?? 0;
  const totalMessagesThisMonth = usageRows?.reduce((sum, u) => sum + (u.ai_messages_used ?? 0), 0) ?? 0;

  const stats = [
    { label: "إجمالي مساحات العمل", value: totalWorkspaces ?? 0 },
    { label: "إجمالي المستخدمين", value: totalUsers ?? 0 },
    { label: "في الفترة التجريبية", value: trialCount },
    { label: "مشتركون نشطون", value: activeCount },
    { label: "دفعات متأخرة", value: pastDueCount },
    { label: "الإيراد الشهري المتكرر (MRR)", value: `$${(mrrCents / 100).toFixed(0)}` },
    { label: "إجمالي الوكلاء", value: totalAgents ?? 0 },
    { label: "رسائل هذا الشهر", value: totalMessagesThisMonth }
  ];

  return (
    <main className="mx-auto max-w-4xl p-8">
      <h1 className="text-2xl font-bold">نظرة عامة</h1>
      <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="rounded-xl border bg-white p-4 dark:bg-slate-900">
            <p className="text-xs text-slate-400">{s.label}</p>
            <p className="mt-1 text-xl font-bold">{s.value}</p>
          </div>
        ))}
      </div>
    </main>
  );
}
