import { redirect } from "next/navigation";
import Link from "next/link";
import { createClient } from "@/lib/supabase/server";

/**
 * Every /admin/* page renders inside this layout, so the admin check
 * happens exactly once per request instead of being repeated in each
 * page. Relies on the `platform_admins` RLS policy (security definer
 * function) to resolve correctly for the querying user — see migration
 * 0002 — rather than using the service-role client, so a non-admin user
 * genuinely cannot read this table no matter what code path is taken.
 */
export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();

  if (!user) redirect("/login?next=/admin");

  const { data: adminRow } = await supabase
    .from("platform_admins")
    .select("user_id")
    .eq("user_id", user.id)
    .maybeSingle();

  if (!adminRow) redirect("/dashboard");

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
      <header className="border-b bg-white p-4 dark:bg-slate-900">
        <nav className="mx-auto flex max-w-4xl items-center gap-4 text-sm">
          <span className="font-bold">لوحة الإدارة</span>
          <Link href="/admin" className="text-slate-500">نظرة عامة</Link>
          <Link href="/admin/workspaces" className="text-slate-500">مساحات العمل</Link>
          <Link href="/admin/plans" className="text-slate-500">الخطط والأسعار</Link>
          <Link href="/dashboard" className="mr-auto text-slate-400">← رجوع للوحة التحكم</Link>
        </nav>
      </header>
      {children}
    </div>
  );
}
