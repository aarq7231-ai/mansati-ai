"use client";

import { useEffect } from "react";

export default function AdminError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error("Admin panel error:", error);
  }, [error]);

  return (
    <main className="mx-auto flex max-w-lg flex-col items-center justify-center gap-3 p-8 py-24 text-center">
      <h1 className="text-xl font-semibold">حدث خطأ في لوحة الإدارة</h1>
      <p className="text-sm text-slate-500">حاول مرة أخرى. إن استمرت المشكلة، راجع سجلات الخادم.</p>
      <button onClick={() => reset()} className="mt-2 rounded-lg bg-brand-500 px-5 py-2.5 text-sm text-white">
        إعادة المحاولة
      </button>
    </main>
  );
}
