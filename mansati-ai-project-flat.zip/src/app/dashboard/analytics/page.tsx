import { redirect } from "next/navigation";
import { getCurrentWorkspace } from "@/lib/workspace/current";
import { createClient } from "@/lib/supabase/server";

const CHANNEL_LABELS: Record<string, string> = {
  website: "الموقع الإلكتروني",
  telegram: "تيليجرام",
  whatsapp: "واتساب",
  instagram: "إنستغرام",
  messenger: "ماسنجر"
};

export default async function AnalyticsPage() {
  const { user, workspace } = await getCurrentWorkspace();
  if (!user) redirect("/login");
  if (!workspace) redirect("/onboarding");

  const supabase = await createClient();

  const [
    { count: totalConversations },
    { count: totalHandoffs },
    { data: conversationsByChannel },
    { data: leads },
  ] = await Promise.all([
    supabase.from("conversations").select("id", { count: "exact", head: true }).eq("workspace_id", workspace.id),
    supabase
      .from("conversations")
      .select("id", { count: "exact", head: true })
      .eq("workspace_id", workspace.id)
      .eq("status", "human_active"),
    supabase.from("conversations").select("channel").eq("workspace_id", workspace.id),
    supabase.from("leads").select("status").eq("workspace_id", workspace.id),
  ]);

  const channelCounts: Record<string, number> = {};
  conversationsByChannel?.forEach((c) => {
    channelCounts[c.channel] = (channelCounts[c.channel] ?? 0) + 1;
  });

  const totalLeads = leads?.length ?? 0;
  const qualifiedLeads = leads?.filter((l) => l.status === "qualified" || l.status === "won").length ?? 0;


  return (
    <main className="mx-auto max-w-3xl p-8">
      <h1 className="text-2xl font-bold">التحليلات</h1>

      <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-4">
        <div className="rounded-xl border p-4">
          <p className="text-xs text-slate-400">إجمالي المحادثات</p>
          <p className="mt-1 text-xl font-bold">{totalConversations ?? 0}</p>
        </div>
        <div className="rounded-xl border p-4">
          <p className="text-xs text-slate-400">العملاء المحتملون</p>
          <p className="mt-1 text-xl font-bold">{totalLeads}</p>
        </div>
        <div className="rounded-xl border p-4">
          <p className="text-xs text-slate-400">العملاء المؤهلون</p>
          <p className="mt-1 text-xl font-bold">{qualifiedLeads}</p>
        </div>
        <div className="rounded-xl border p-4">
          <p className="text-xs text-slate-400">التحويلات لموظف</p>
          <p className="mt-1 text-xl font-bold">{totalHandoffs ?? 0}</p>
        </div>
      </div>


      <div className="mt-6 rounded-xl border p-4">
        <p className="mb-3 text-sm font-semibold">المحادثات حسب القناة</p>
        <div className="flex flex-wrap gap-3">
          {Object.entries(channelCounts).length === 0 && (
            <p className="text-sm text-slate-400">لا توجد محادثات بعد.</p>
          )}
          {Object.entries(channelCounts).map(([channel, count]) => (
            <div key={channel} className="rounded-lg bg-slate-100 px-4 py-2 text-sm dark:bg-slate-800">
              {CHANNEL_LABELS[channel] ?? channel}: <span className="font-semibold">{count}</span>
            </div>
          ))}
        </div>
      </div>
    </main>
  );
}
