import { redirect } from "next/navigation";
import Link from "next/link";
import { getCurrentWorkspace } from "@/lib/workspace/current";
import { createClient } from "@/lib/supabase/server";

export default async function ContactsPage() {
  const { user, workspace } = await getCurrentWorkspace();
  if (!user) redirect("/login");
  if (!workspace) redirect("/onboarding");

  const supabase = await createClient();
  const { data: contacts } = await supabase
    .from("contacts")
    .select("id, name, phone, email, source, tags, last_interaction_at, created_at")
    .eq("workspace_id", workspace.id)
    .order("created_at", { ascending: false })
    .limit(100);

  return (
    <main className="mx-auto max-w-3xl p-8">
      <h1 className="text-2xl font-bold">العملاء (CRM)</h1>

      <ul className="mt-6 flex flex-col gap-2">
        {contacts?.length === 0 && <p className="text-sm text-slate-400">لا يوجد عملاء بعد.</p>}
        {contacts?.map((contact) => (
          <li key={contact.id}>
            <Link
              href={`/dashboard/contacts/${contact.id}`}
              className="flex items-center justify-between rounded-lg border p-4 hover:bg-slate-50 dark:hover:bg-slate-900"
            >
              <div>
                <p className="font-medium">{contact.name || contact.phone || contact.email || "عميل بدون اسم"}</p>
                <p className="text-xs text-slate-400">
                  {contact.source ?? "غير معروف"}
                  {contact.tags?.length ? ` · ${contact.tags.join(", ")}` : ""}
                </p>
              </div>
              <span className="text-xs text-slate-400">
                {new Date(contact.created_at).toLocaleDateString("ar")}
              </span>
            </Link>
          </li>
        ))}
      </ul>
    </main>
  );
}
