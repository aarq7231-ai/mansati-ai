import { redirect, notFound } from "next/navigation";
import Link from "next/link";
import { revalidatePath } from "next/cache";
import { getCurrentWorkspace } from "@/lib/workspace/current";
import { createClient } from "@/lib/supabase/server";

async function updateContact(contactId: string, workspaceId: string, formData: FormData) {
  "use server";
  const supabase = await createClient();

  const name = String(formData.get("name") || "").trim() || null;
  const phone = String(formData.get("phone") || "").trim() || null;
  const email = String(formData.get("email") || "").trim() || null;
  const tagsRaw = String(formData.get("tags") || "").trim();
  const tags = tagsRaw ? tagsRaw.split(",").map((t) => t.trim()).filter(Boolean) : [];
  const notes = String(formData.get("notes") || "").trim() || null;

  await supabase
    .from("contacts")
    .update({ name, phone, email, tags, notes })
    .eq("id", contactId)
    .eq("workspace_id", workspaceId);

  revalidatePath(`/dashboard/contacts/${contactId}`);
}

const LEAD_STATUS_LABELS: Record<string, string> = {
  new: "جديد",
  interested: "مهتم",
  qualified: "مؤهل",
  negotiation: "تفاوض",
  won: "تم الفوز",
  lost: "خسارة"
};

export default async function ContactDetailPage({ params }: { params: Promise<{ contactId: string }> }) {
  const { contactId } = await params;
  const { user, workspace } = await getCurrentWorkspace();
  if (!user) redirect("/login");
  if (!workspace) redirect("/onboarding");

  const supabase = await createClient();
  const { data: contact } = await supabase
    .from("contacts")
    .select("*")
    .eq("id", contactId)
    .eq("workspace_id", workspace.id)
    .maybeSingle();
  if (!contact) notFound();

  const { data: leads } = await supabase
    .from("leads")
    .select("id, status, answers, created_at")
    .eq("contact_id", contactId)
    .order("created_at", { ascending: false });

  const { data: conversations } = await supabase
    .from("conversations")
    .select("id, channel, status, updated_at")
    .eq("contact_id", contactId)
    .order("updated_at", { ascending: false });

  const boundUpdate = updateContact.bind(null, contact.id, workspace.id);

  return (
    <main className="mx-auto max-w-2xl p-8">
      <Link href="/dashboard/contacts" className="text-sm text-brand-600">
        ← كل العملاء
      </Link>

      <h1 className="mt-2 text-2xl font-bold">{contact.name || "عميل بدون اسم"}</h1>

      <form action={boundUpdate} className="mt-4 grid gap-3 rounded-xl border p-4 md:grid-cols-2">
        <input name="name" defaultValue={contact.name ?? ""} placeholder="الاسم" className="rounded-lg border px-3 py-2 text-sm" />
        <input name="phone" defaultValue={contact.phone ?? ""} placeholder="رقم الهاتف" className="rounded-lg border px-3 py-2 text-sm" />
        <input name="email" defaultValue={contact.email ?? ""} placeholder="البريد الإلكتروني" className="rounded-lg border px-3 py-2 text-sm" />
        <input
          name="tags"
          defaultValue={(contact.tags ?? []).join(", ")}
          placeholder="وسوم (مفصولة بفاصلة)"
          className="rounded-lg border px-3 py-2 text-sm"
        />
        <textarea
          name="notes"
          defaultValue={contact.notes ?? ""}
          placeholder="ملاحظات..."
          className="min-h-20 rounded-lg border px-3 py-2 text-sm md:col-span-2"
        />
        <button type="submit" className="rounded-lg bg-brand-500 px-4 py-2 text-sm text-white md:col-span-2">
          حفظ
        </button>
      </form>

      <h2 className="mt-6 text-lg font-semibold">العملاء المحتملون (Leads)</h2>
      <ul className="mt-2 flex flex-col gap-2">
        {leads?.length === 0 && <p className="text-sm text-slate-400">لا توجد سجلات.</p>}
        {leads?.map((lead) => (
          <li key={lead.id} className="rounded-lg border p-3 text-sm">
            <p className="font-medium">{LEAD_STATUS_LABELS[lead.status] ?? lead.status}</p>
            {lead.answers && Object.keys(lead.answers).length > 0 ? (
              <ul className="mt-1 space-y-0.5 text-xs text-slate-500">
                {Object.entries(lead.answers).map(([q, a]) => (
                  <li key={q}>
                    <span className="font-medium">{q}</span>: {String(a)}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="mt-1 text-xs text-slate-400">لم يتم استخراج إجابات بعد.</p>
            )}
          </li>
        ))}
      </ul>

      <h2 className="mt-6 text-lg font-semibold">المحادثات</h2>
      <ul className="mt-2 flex flex-col gap-2">
        {conversations?.length === 0 && <p className="text-sm text-slate-400">لا توجد محادثات.</p>}
        {conversations?.map((c) => (
          <li key={c.id}>
            <Link href={`/dashboard/inbox/${c.id}`} className="block rounded-lg border p-3 text-sm hover:bg-slate-50">
              {c.channel} · {c.status}
            </Link>
          </li>
        ))}
      </ul>
    </main>
  );
}
