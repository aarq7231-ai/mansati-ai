import { redirect } from "next/navigation";
import Link from "next/link";
import { revalidatePath } from "next/cache";
import { getCurrentWorkspace } from "@/lib/workspace/current";
import { createClient } from "@/lib/supabase/server";

const STATUSES = ["new", "interested", "qualified", "negotiation", "won", "lost"] as const;

const STATUS_LABELS: Record<string, string> = {
  new: "جديد",
  interested: "مهتم",
  qualified: "مؤهل",
  negotiation: "تفاوض",
  won: "تم الفوز",
  lost: "خسارة"
};

async function updateLeadStatus(leadId: string, workspaceId: string, formData: FormData) {
  "use server";
  const supabase = await createClient();
  const status = String(formData.get("status") || "new");

  await supabase.from("leads").update({ status }).eq("id", leadId).eq("workspace_id", workspaceId);
  await supabase.from("lead_events").insert({
    workspace_id: workspaceId,
    lead_id: leadId,
    event_type: "status_changed",
    metadata: { status }
  });

  revalidatePath("/dashboard/leads");
}

export default async function LeadsPage({
  searchParams
}: {
  searchParams: Promise<{ status?: string }>;
}) {
  const params = await searchParams;
  const { user, workspace } = await getCurrentWorkspace();
  if (!user) redirect("/login");
  if (!workspace) redirect("/onboarding");

  const supabase = await createClient();
  let query = supabase
    .from("leads")
    .select("id, status, answers, created_at, contacts(name, phone)")
    .eq("workspace_id", workspace.id)
    .order("created_at", { ascending: false })
    .limit(100);

  if (params.status) query = query.eq("status", params.status);

  const { data: leads } = await query;

  return (
    <main className="mx-auto max-w-3xl p-8">
      <h1 className="text-2xl font-bold">مسار العملاء المحتملين</h1>

      <div className="mt-4 flex flex-wrap gap-2">
        <Link
          href="/dashboard/leads"
          className={`rounded-full px-3 py-1 text-xs ${!params.status ? "bg-brand-500 text-white" : "border"}`}
        >
          الكل
        </Link>
        {STATUSES.map((s) => (
          <Link
            key={s}
            href={`/dashboard/leads?status=${s}`}
            className={`rounded-full px-3 py-1 text-xs ${params.status === s ? "bg-brand-500 text-white" : "border"}`}
          >
            {STATUS_LABELS[s]}
          </Link>
        ))}
      </div>

      <ul className="mt-6 flex flex-col gap-2">
        {leads?.length === 0 && <p className="text-sm text-slate-400">لا توجد سجلات.</p>}
        {leads?.map((lead: any) => {
          const boundUpdate = updateLeadStatus.bind(null, lead.id, workspace.id);
          return (
            <li key={lead.id} className="rounded-lg border p-4 text-sm">
              <div className="flex items-center justify-between gap-2">
                <p className="font-medium">{lead.contacts?.name || lead.contacts?.phone || "عميل بدون اسم"}</p>
                <form action={boundUpdate} className="flex items-center gap-1">
                  <select name="status" defaultValue={lead.status} className="rounded-md border px-2 py-1 text-xs">
                    {STATUSES.map((s) => (
                      <option key={s} value={s}>
                        {STATUS_LABELS[s]}
                      </option>
                    ))}
                  </select>
                  <button type="submit" className="rounded-md border px-2 py-1 text-xs">
                    تحديث
                  </button>
                </form>
              </div>
              {lead.answers && Object.keys(lead.answers).length > 0 && (
                <ul className="mt-2 space-y-0.5 text-xs text-slate-500">
                  {Object.entries(lead.answers).map(([q, a]) => (
                    <li key={q}>
                      <span className="font-medium">{q}</span>: {String(a)}
                    </li>
                  ))}
                </ul>
              )}
            </li>
          );
        })}
      </ul>
    </main>
  );
}
