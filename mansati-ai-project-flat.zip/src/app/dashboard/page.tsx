import { redirect } from "next/navigation";
import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { getCurrentWorkspace } from "@/lib/workspace/current";

export default async function DashboardPage() {
  const { user, workspace } = await getCurrentWorkspace();
  if (!user) redirect("/login");
  if (!workspace) redirect("/onboarding");

  const supabase = await createClient();
  const { data: subscription } = await supabase
    .from("subscriptions")
    .select("status, trial_ends_at, plans(name, key, message_limit)")
    .eq("workspace_id", workspace.id)
    .maybeSingle();

  const { data: agents } = await supabase
    .from("agents")
    .select("id, name, public_agent_id, is_active")
    .eq("workspace_id", workspace.id);

  const { data: currentUsage } = await supabase
    .from("usage")
    .select("ai_messages_used")
    .eq("workspace_id", workspace.id)
    .eq("period_start", new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().slice(0, 10))
    .maybeSingle();

  const limitReached =
    subscription?.status === "active" &&
    subscription?.plans?.key === "basic" &&
    typeof subscription?.plans?.message_limit === "number" &&
    (currentUsage?.ai_messages_used ?? 0) >= subscription.plans.message_limit;

  const trialEndsAt = subscription?.trial_ends_at ? new Date(subscription.trial_ends_at) : null;
  const daysLeft = trialEndsAt
    ? Math.max(0, Math.ceil((trialEndsAt.getTime() - Date.now()) / 86_400_000))
    : null;

  return (
    <main className="mx-auto max-w-3xl p-8">
      <h1 className="text-2xl font-bold">{workspace.name}</h1>

      {limitReached && (
        <div className="mt-4 rounded-xl border-2 border-brand-500 bg-brand-50 p-4 dark:bg-slate-900">
          <p className="font-semibold">انتهت الردود الآلية لهذه الفترة.</p>
          <p className="mt-1 text-sm text-slate-500">اشترك بخطة Pro مقابل $10 شهرياً لمواصلة الرد الآلي بحد أعلى.</p>
          <Link href="/dashboard/billing" className="mt-3 inline-block rounded-lg bg-brand-500 px-4 py-2 text-sm text-white">
            الترقية إلى Pro
          </Link>
        </div>
      )}

      <div className="mt-4 rounded-xl border p-4">
        <p className="font-medium">
          الحالة: {subscription?.status === "trialing" ? "فترة تجريبية" : subscription?.status}
        </p>
        {daysLeft !== null && (
          <p className="text-sm text-slate-500">
            {daysLeft > 0
              ? `متبقي ${daysLeft} يوم على انتهاء الفترة التجريبية`
              : "انتهت الفترة التجريبية. اشترك بـ $5 شهرياً لمواصلة استخدام الوكيل."}
          </p>
        )}
      </div>

      <div className="mt-6 flex flex-wrap gap-3">
        <Link href="/dashboard/inbox" className="rounded-lg border px-4 py-2 text-sm">
          صندوق الوارد الموحّد
        </Link>
        <Link href="/dashboard/contacts" className="rounded-lg border px-4 py-2 text-sm">
          العملاء (CRM)
        </Link>
        <Link href="/dashboard/leads" className="rounded-lg border px-4 py-2 text-sm">
          مسار العملاء المحتملين
        </Link>
        <Link href="/dashboard/billing" className="rounded-lg border px-4 py-2 text-sm">
          الفوترة والاشتراك
        </Link>
        <Link href="/dashboard/analytics" className="rounded-lg border px-4 py-2 text-sm">
          التحليلات
        </Link>
        <Link href="/dashboard/referrals" className="rounded-lg border px-4 py-2 text-sm">
          دعوة الأصدقاء
        </Link>
      </div>

      <div className="mt-8 flex items-center justify-between">
        <h2 className="text-lg font-semibold">الوكلاء الأذكياء</h2>
        <Link href="/dashboard/agents" className="text-sm text-brand-600">
          إدارة الوكلاء ←
        </Link>
      </div>
      <ul className="mt-2 flex flex-col gap-2">
        {agents?.map((agent) => (
          <li key={agent.id}>
            <Link href={`/dashboard/agents/${agent.id}`} className="block rounded-lg border p-3 hover:bg-slate-50">
              {agent.name}{" "}
              <span className="text-xs text-slate-400">({agent.public_agent_id})</span>
            </Link>
          </li>
        ))}
      </ul>
    </main>
  );
}
