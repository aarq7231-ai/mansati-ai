"use client";

import { useEffect } from "react";

export default function DashboardError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error("Dashboard error:", error);
  }, [error]);

  return (
    <main className="mx-auto flex max-w-lg flex-col items-center justify-center gap-3 p-8 py-24 text-center">
      <h1 className="text-xl font-semibold">حدث خطأ غير متوقع</h1>
      <p className="text-sm text-slate-500">
        نعتذر عن هذا الخلل. يمكنك المحاولة مرة أخرى، وإذا استمرت المشكلة تواصل معنا.
      </p>
      <button onClick={() => reset()} className="mt-2 rounded-lg bg-brand-500 px-5 py-2.5 text-sm text-white">
        إعادة المحاولة
      </button>
    </main>
  );
}
