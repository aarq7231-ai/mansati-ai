"use client";

import { useState } from "react";

export default function UpgradeButton({ planId }: { planId: string }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleUpgrade() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/billing/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ planId })
      });
      const data = await res.json();
      if (!res.ok || !data.url) throw new Error(data.error || "تعذر بدء عملية الدفع");
      window.location.href = data.url;
    } catch (err: any) {
      setError(err?.message ?? "حدث خطأ");
      setLoading(false);
    }
  }

  return (
    <div className="mt-3">
      <button
        onClick={handleUpgrade}
        disabled={loading}
        className="w-full rounded-lg bg-brand-500 px-4 py-2.5 font-medium text-white disabled:opacity-50"
      >
        {loading ? "جارٍ التحويل..." : "الترقية الآن"}
      </button>
      {error && <p className="mt-2 text-sm text-red-600">{error}</p>}
    </div>
  );
}
