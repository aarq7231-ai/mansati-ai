import { redirect } from "next/navigation";
import { getCurrentWorkspace } from "@/lib/workspace/current";
import { createClient } from "@/lib/supabase/server";
import UpgradeButton from "./upgrade-button";
import CancelSubscriptionButton from "./cancel-button";

const STATUS_LABELS: Record<string, string> = {
  trialing: "فترة تجريبية",
  active: "نشط",
  past_due: "دفعة متأخرة",
  canceled: "ملغى",
  expired: "منتهي"
};

export default async function BillingPage({
  searchParams
}: {
  searchParams: Promise<{ checkout?: string }>;
}) {
  const params = await searchParams;
  const { user, workspace } = await getCurrentWorkspace();
  if (!user) redirect("/login");
  if (!workspace) redirect("/onboarding");

  const supabase = await createClient();
  const { data: subscription } = await supabase
    .from("subscriptions")
    .select("status, trial_ends_at, current_period_end, plans(key, name, price_cents)")
    .eq("workspace_id", workspace.id)
    .maybeSingle<any>();

  const { data: proPlan } = await supabase
    .from("plans")
    .select("id, name, price_cents, message_limit")
    .eq("key", "pro")
    .single();

  const isOnTrial = subscription?.status === "trialing";
  const isOnPro = subscription?.plans?.key === "pro" && subscription?.status === "active";
  const trialEndsAt = subscription?.trial_ends_at ? new Date(subscription.trial_ends_at) : null;
  const daysLeft = trialEndsAt
    ? Math.max(0, Math.ceil((trialEndsAt.getTime() - Date.now()) / 86_400_000))
    : null;

  return (
    <main className="mx-auto max-w-lg p-8">
      <h1 className="text-2xl font-bold">الفوترة والاشتراك</h1>

      {params.checkout === "success" && (
        <p className="mt-4 rounded-md bg-emerald-50 p-3 text-sm text-emerald-700">
          تم الاشتراك بنجاح! قد يستغرق تحديث الحالة بضع ثوانٍ.
        </p>
      )}
      {params.checkout === "canceled" && (
        <p className="mt-4 rounded-md bg-slate-50 p-3 text-sm text-slate-600">تم إلغاء عملية الدفع.</p>
      )}

      <div className="mt-6 rounded-xl border p-5">
        <p className="text-sm text-slate-400">الخطة الحالية</p>
        <p className="text-lg font-semibold">{subscription?.plans?.name ?? "—"}</p>
        <p className="mt-1 text-sm">
          الحالة: <span className="font-medium">{STATUS_LABELS[subscription?.status] ?? subscription?.status}</span>
        </p>
        {isOnTrial && daysLeft !== null && (
          <p className="mt-1 text-sm text-slate-500">
            {daysLeft > 0 ? `متبقي ${daysLeft} يوم على انتهاء الفترة التجريبية` : "انتهت الفترة التجريبية"}
          </p>
        )}
        {subscription?.current_period_end && (
          <p className="mt-1 text-xs text-slate-400">
            التجديد التالي: {new Date(subscription.current_period_end).toLocaleDateString("ar")}
          </p>
        )}
        {isOnPro && <CancelSubscriptionButton />}
      </div>

      {!isOnPro && proPlan && (
        <div className="mt-4 rounded-xl border-2 border-brand-500 p-5">
          <p className="text-lg font-semibold">{proPlan.name}</p>
          <p className="mt-1 text-2xl font-bold">
            ${(proPlan.price_cents / 100).toFixed(0)}
            <span className="text-sm font-normal text-slate-400"> / شهرياً</span>
          </p>
          <p className="mt-1 text-sm text-slate-500">{proPlan.message_limit} رد AI شهرياً</p>
          <UpgradeButton planId={proPlan.id} />
        </div>
      )}
    </main>
  );
}
