"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function CancelSubscriptionButton() {
  const router = useRouter();
  const [confirming, setConfirming] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleCancel() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/billing/cancel", { method: "POST" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "تعذر إلغاء الاشتراك");
      router.refresh();
      setConfirming(false);
    } catch (err: any) {
      setError(err?.message ?? "حدث خطأ");
    } finally {
      setLoading(false);
    }
  }

  if (!confirming) {
    return (
      <button onClick={() => setConfirming(true)} className="mt-3 text-sm text-red-500 underline">
        إلغاء الاشتراك
      </button>
    );
  }

  return (
    <div className="mt-3 rounded-lg border border-red-200 bg-red-50 p-3">
      <p className="text-sm text-red-700">
        هل أنت متأكد؟ سيتوقف وكيلك الذكي عن العمل في نهاية فترة الفوترة الحالية.
      </p>
      <div className="mt-2 flex gap-2">
        <button
          onClick={handleCancel}
          disabled={loading}
          className="rounded-lg bg-red-500 px-3 py-1.5 text-sm text-white disabled:opacity-50"
        >
          {loading ? "جارٍ الإلغاء..." : "نعم، ألغِ الاشتراك"}
        </button>
        <button onClick={() => setConfirming(false)} className="rounded-lg border px-3 py-1.5 text-sm">
          تراجع
        </button>
      </div>
      {error && <p className="mt-2 text-sm text-red-600">{error}</p>}
    </div>
  );
}
