import { redirect } from "next/navigation";
import { getCurrentWorkspace } from "@/lib/workspace/current";
import { createClient } from "@/lib/supabase/server";

const STATUS_LABELS: Record<string, string> = {
  pending: "بانتظار التسجيل",
  signed_up: "سجّل، بانتظار الاشتراك المدفوع",
  converted: "تم! حصلت على المكافأة",
  rewarded: "تمت المكافأة"
};

export default async function ReferralsPage() {
  const { user, workspace } = await getCurrentWorkspace();
  if (!user) redirect("/login");
  if (!workspace) redirect("/onboarding");

  const supabase = await createClient();
  const { data: referrals } = await supabase
    .from("referrals")
    .select("id, status, reward_type, reward_value, created_at, converted_at")
    .eq("referrer_workspace_id", workspace.id)
    .order("created_at", { ascending: false });

  const referralLink = `${process.env.NEXT_PUBLIC_APP_URL}/signup?ref=${workspace.referral_code}`;
  const convertedCount = referrals?.filter((r) => r.status === "converted").length ?? 0;

  return (
    <main className="mx-auto max-w-xl p-8">
      <h1 className="text-2xl font-bold">دعوة الأصدقاء</h1>
      <p className="text-sm text-slate-500">
        شارك رابطك — عندما يشترك من تدعوه بالخطة المدفوعة، تحصل تلقائياً على شهر مجاني.
      </p>

      <div className="mt-6 rounded-xl border bg-slate-50 p-4 dark:bg-slate-900">
        <p className="text-xs text-slate-400">رابط الدعوة الخاص بك</p>
        <code className="mt-1 block break-all text-sm text-brand-600">{referralLink}</code>
      </div>

      <div className="mt-4 rounded-xl border p-4">
        <p className="text-sm">
          عدد الاشتراكات الناجحة: <span className="font-bold">{convertedCount}</span> ×
          شهر مجاني
        </p>
      </div>

      <h2 className="mt-6 text-lg font-semibold">سجل الدعوات</h2>
      <ul className="mt-2 flex flex-col gap-2">
        {referrals?.length === 0 && <p className="text-sm text-slate-400">لم تدعُ أحداً بعد.</p>}
        {referrals?.map((r) => (
          <li key={r.id} className="rounded-lg border p-3 text-sm">
            <p>{STATUS_LABELS[r.status] ?? r.status}</p>
            {r.reward_value && <p className="text-xs text-slate-400">المكافأة: {r.reward_value}</p>}
          </li>
        ))}
      </ul>
    </main>
  );
}
