import { redirect, notFound } from "next/navigation";
import { revalidatePath } from "next/cache";
import { getCurrentWorkspace } from "@/lib/workspace/current";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { processDocument } from "@/lib/knowledge/process";

const MAX_FILE_SIZE_BYTES = 20 * 1024 * 1024; // 20MB — matches typical business-document sizes
const EXT_TO_TYPE: Record<string, string> = {
  pdf: "pdf",
  docx: "docx",
  txt: "txt",
  csv: "csv",
  xlsx: "xlsx"
};

async function requireAgentInWorkspace(agentId: string, workspaceId: string) {
  const supabase = await createClient();
  const { data: agent } = await supabase
    .from("agents")
    .select("id")
    .eq("id", agentId)
    .eq("workspace_id", workspaceId)
    .maybeSingle();
  if (!agent) notFound();
}

async function uploadFile(agentId: string, workspaceId: string, formData: FormData) {
  "use server";
  await requireAgentInWorkspace(agentId, workspaceId);

  const file = formData.get("file") as File | null;
  if (!file || file.size === 0) {
    redirect(`/dashboard/agents/${agentId}/knowledge?error=` + encodeURIComponent("يرجى اختيار ملف"));
  }
  if (file!.size > MAX_FILE_SIZE_BYTES) {
    redirect(
      `/dashboard/agents/${agentId}/knowledge?error=` + encodeURIComponent("حجم الملف كبير جداً (الحد الأقصى 20MB)")
    );
  }

  const ext = file!.name.split(".").pop()?.toLowerCase() ?? "";
  const type = EXT_TO_TYPE[ext];
  if (!type) {
    redirect(
      `/dashboard/agents/${agentId}/knowledge?error=` +
        encodeURIComponent("نوع الملف غير مدعوم. الأنواع المدعومة: PDF, DOCX, TXT, CSV, XLSX")
    );
  }

  const admin = createAdminClient();

  const { data: source } = await admin
    .from("knowledge_sources")
    .insert({ workspace_id: workspaceId, agent_id: agentId, type })
    .select("id")
    .single();
  if (!source) redirect(`/dashboard/agents/${agentId}/knowledge?error=upload_failed`);

  const storagePath = `${workspaceId}/${agentId}/${Date.now()}-${file!.name}`;
  const arrayBuffer = await file!.arrayBuffer();

  const { error: uploadError } = await admin.storage
    .from("knowledge-files")
    .upload(storagePath, Buffer.from(arrayBuffer), {
      contentType: file!.type || "application/octet-stream"
    });
  if (uploadError) redirect(`/dashboard/agents/${agentId}/knowledge?error=storage_upload_failed`);

  const { data: doc } = await admin
    .from("documents")
    .insert({
      workspace_id: workspaceId,
      knowledge_source_id: source!.id,
      file_name: file!.name,
      file_type: type,
      file_size_bytes: file!.size,
      storage_path: storagePath,
      status: "pending"
    })
    .select("id")
    .single();

  if (doc) await processDocument(doc.id);

  revalidatePath(`/dashboard/agents/${agentId}/knowledge`);
}

async function addManualText(agentId: string, workspaceId: string, formData: FormData) {
  "use server";
  await requireAgentInWorkspace(agentId, workspaceId);

  const title = String(formData.get("title") || "نص مضاف يدوياً").trim();
  const content = String(formData.get("content") || "").trim();
  if (!content) {
    redirect(`/dashboard/agents/${agentId}/knowledge?error=` + encodeURIComponent("يرجى كتابة نص"));
  }

  const admin = createAdminClient();
  const { data: source } = await admin
    .from("knowledge_sources")
    .insert({ workspace_id: workspaceId, agent_id: agentId, type: "manual_text" })
    .select("id")
    .single();
  if (!source) redirect(`/dashboard/agents/${agentId}/knowledge?error=save_failed`);

  const { data: doc } = await admin
    .from("documents")
    .insert({
      workspace_id: workspaceId,
      knowledge_source_id: source!.id,
      file_name: title,
      file_type: "manual_text",
      storage_path: content, // plain text stored directly; see process.ts
      status: "pending"
    })
    .select("id")
    .single();

  if (doc) await processDocument(doc.id);
  revalidatePath(`/dashboard/agents/${agentId}/knowledge`);
}

async function addWebsite(agentId: string, workspaceId: string, formData: FormData) {
  "use server";
  await requireAgentInWorkspace(agentId, workspaceId);

  const url = String(formData.get("url") || "").trim();
  try {
    new URL(url);
  } catch {
    redirect(`/dashboard/agents/${agentId}/knowledge?error=` + encodeURIComponent("رابط غير صحيح"));
  }

  const admin = createAdminClient();
  const { data: source } = await admin
    .from("knowledge_sources")
    .insert({ workspace_id: workspaceId, agent_id: agentId, type: "website", source_url: url })
    .select("id")
    .single();
  if (!source) redirect(`/dashboard/agents/${agentId}/knowledge?error=save_failed`);

  const { data: doc } = await admin
    .from("documents")
    .insert({
      workspace_id: workspaceId,
      knowledge_source_id: source!.id,
      file_name: url,
      file_type: "website",
      status: "pending"
    })
    .select("id")
    .single();

  if (doc) await processDocument(doc.id);
  revalidatePath(`/dashboard/agents/${agentId}/knowledge`);
}

async function deleteDocument(agentId: string, workspaceId: string, documentId: string) {
  "use server";
  await requireAgentInWorkspace(agentId, workspaceId);

  const admin = createAdminClient();
  const { data: doc } = await admin
    .from("documents")
    .select("storage_path, workspace_id")
    .eq("id", documentId)
    .eq("workspace_id", workspaceId)
    .maybeSingle();

  if (doc?.storage_path && doc.storage_path.includes("/")) {
    // Only real uploaded files live in storage (manual text/website don't).
    await admin.storage.from("knowledge-files").remove([doc.storage_path]);
  }
  await admin.from("documents").delete().eq("id", documentId);

  revalidatePath(`/dashboard/agents/${agentId}/knowledge`);
}

async function reprocessDocument(agentId: string, workspaceId: string, documentId: string) {
  "use server";
  await requireAgentInWorkspace(agentId, workspaceId);
  await processDocument(documentId);
  revalidatePath(`/dashboard/agents/${agentId}/knowledge`);
}

const STATUS_LABELS: Record<string, string> = {
  pending: "بانتظار المعالجة",
  processing: "جارٍ المعالجة...",
  ready: "جاهز ✓",
  error: "خطأ"
};

export default async function KnowledgePage({
  params,
  searchParams
}: {
  params: Promise<{ agentId: string }>;
  searchParams: Promise<{ error?: string }>;
}) {
  const { agentId } = await params;
  const query = await searchParams;
  const { user, workspace } = await getCurrentWorkspace();
  if (!user) redirect("/login");
  if (!workspace) redirect("/onboarding");
  await requireAgentInWorkspace(agentId, workspace.id);

  const supabase = await createClient();
  const { data: documents } = await supabase
    .from("documents")
    .select("id, file_name, file_type, file_size_bytes, status, error_message, uploaded_at, knowledge_source_id")
    .eq("workspace_id", workspace.id)
    .order("uploaded_at", { ascending: false });

  const boundUploadFile = uploadFile.bind(null, agentId, workspace.id);
  const boundAddManualText = addManualText.bind(null, agentId, workspace.id);
  const boundAddWebsite = addWebsite.bind(null, agentId, workspace.id);

  return (
    <main className="mx-auto max-w-3xl p-8">
      <h1 className="text-2xl font-bold">قاعدة المعرفة</h1>
      <p className="text-sm text-slate-500">
        ارفع مستندات أو أضف نصوصاً أو روابط مواقع ليتعلم منها الوكيل ويجيب من محتواها فقط.
      </p>

      {query.error && (
        <p className="mt-4 rounded-md bg-red-50 p-3 text-sm text-red-600">{query.error}</p>
      )}

      <div className="mt-6 grid gap-6 md:grid-cols-3">
        <form action={boundUploadFile} className="flex flex-col gap-2 rounded-xl border p-4">
          <p className="text-sm font-medium">رفع ملف</p>
          <input type="file" name="file" accept=".pdf,.docx,.txt,.csv,.xlsx" required className="text-xs" />
          <p className="text-xs text-slate-400">PDF, DOCX, TXT, CSV, XLSX — حتى 20MB</p>
          <button type="submit" className="mt-2 rounded-lg bg-brand-500 px-3 py-2 text-sm text-white">
            رفع
          </button>
        </form>

        <form action={boundAddManualText} className="flex flex-col gap-2 rounded-xl border p-4">
          <p className="text-sm font-medium">إضافة نص يدوياً</p>
          <input name="title" placeholder="عنوان (اختياري)" className="rounded-md border px-2 py-1.5 text-sm" />
          <textarea name="content" placeholder="الصق النص هنا..." required className="min-h-20 rounded-md border px-2 py-1.5 text-sm" />
          <button type="submit" className="mt-2 rounded-lg bg-brand-500 px-3 py-2 text-sm text-white">
            حفظ
          </button>
        </form>

        <form action={boundAddWebsite} className="flex flex-col gap-2 rounded-xl border p-4">
          <p className="text-sm font-medium">إضافة رابط موقع</p>
          <input name="url" type="url" placeholder="https://example.com/faq" required className="rounded-md border px-2 py-1.5 text-sm" />
          <p className="text-xs text-slate-400">يُحترم ملف robots.txt الخاص بالموقع.</p>
          <button type="submit" className="mt-2 rounded-lg bg-brand-500 px-3 py-2 text-sm text-white">
            إضافة
          </button>
        </form>
      </div>

      <h2 className="mt-8 text-lg font-semibold">المصادر المضافة</h2>
      <ul className="mt-3 flex flex-col gap-2">
        {documents?.length === 0 && <p className="text-sm text-slate-400">لا توجد مصادر بعد.</p>}
        {documents?.map((doc) => {
          const boundDelete = deleteDocument.bind(null, agentId, workspace.id, doc.id);
          const boundReprocess = reprocessDocument.bind(null, agentId, workspace.id, doc.id);
          return (
            <li key={doc.id} className="flex items-center justify-between rounded-lg border p-3 text-sm">
              <div>
                <p className="font-medium">{doc.file_name}</p>
                <p className="text-xs text-slate-400">
                  {doc.file_type?.toUpperCase()} ·{" "}
                  {doc.file_size_bytes ? `${Math.round(doc.file_size_bytes / 1024)}KB · ` : ""}
                  {STATUS_LABELS[doc.status] ?? doc.status}
                  {doc.status === "error" && doc.error_message ? ` — ${doc.error_message}` : ""}
                </p>
              </div>
              <div className="flex gap-2">
                {doc.status === "error" && (
                  <form action={boundReprocess}>
                    <button className="text-xs text-brand-600">إعادة المعالجة</button>
                  </form>
                )}
                <form action={boundDelete}>
                  <button className="text-xs text-red-500">حذف</button>
                </form>
              </div>
            </li>
          );
        })}
      </ul>
    </main>
  );
}
