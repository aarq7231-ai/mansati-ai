import { redirect, notFound } from "next/navigation";
import Link from "next/link";
import { revalidatePath } from "next/cache";
import { getCurrentWorkspace } from "@/lib/workspace/current";
import { createClient } from "@/lib/supabase/server";
import ChatWidget from "@/components/chat-widget";

async function updateAgentSettings(agentId: string, workspaceId: string, formData: FormData) {
  "use server";

  const supabase = await createClient();

  // Ownership re-verified server-side even though RLS would also block a
  // mismatched workspace — defense in depth, and gives a clean redirect.
  const { data: agent } = await supabase
    .from("agents")
    .select("id, workspace_id")
    .eq("id", agentId)
    .eq("workspace_id", workspaceId)
    .maybeSingle();
  if (!agent) notFound();

  const name = String(formData.get("name") || "").trim();
  const personality = String(formData.get("personality") || "").trim() || null;
  const tone = String(formData.get("tone") || "").trim() || null;
  const systemInstructions = String(formData.get("system_instructions") || "").trim() || null;
  const welcomeMessage = String(formData.get("welcome_message") || "").trim() || null;
  const fallbackMessage = String(formData.get("fallback_message") || "").trim();
  const rulesRaw = String(formData.get("rules") || "").trim();
  const rules = rulesRaw ? rulesRaw.split("\n").map((r) => r.trim()).filter(Boolean) : [];
  const leadQuestionsRaw = String(formData.get("lead_questions") || "").trim();
  const leadQuestions = leadQuestionsRaw
    ? leadQuestionsRaw.split("\n").map((q) => q.trim()).filter(Boolean)
    : [];
  const isActive = formData.get("is_active") === "on";

  const allowedActions: string[] = [];
  if (formData.get("action_check_availability") === "on") allowedActions.push("check_calendar_availability");
  if (formData.get("action_book_appointment") === "on") allowedActions.push("create_calendar_event");
  if (formData.get("action_send_email") === "on") allowedActions.push("send_email");
  if (formData.get("action_notify_employee") === "on") allowedActions.push("notify_employee");
  if (formData.get("action_trigger_webhook") === "on") allowedActions.push("trigger_webhook");
  const webhookUrl = String(formData.get("webhook_url") || "").trim() || null;

  const branding = {
    primary_color: String(formData.get("brand_color") || "#3b6cf6"),
    logo_url: String(formData.get("logo_url") || "").trim() || null,
    greeting: String(formData.get("widget_greeting") || "").trim() || null,
    position: formData.get("widget_position") === "left" ? "left" : "right"
  };

  await supabase.from("agents").update({ name, is_active: isActive }).eq("id", agentId);

  await supabase
    .from("agent_settings")
    .update({
      personality,
      tone,
      system_instructions: systemInstructions,
      welcome_message: welcomeMessage,
      fallback_message: fallbackMessage,
      rules,
      lead_questions: leadQuestions,
      allowed_actions: allowedActions,
      webhook_url: webhookUrl,
      branding
    })
    .eq("agent_id", agentId);

  revalidatePath(`/dashboard/agents/${agentId}`);
}

export default async function AgentBuilderPage({ params }: { params: Promise<{ agentId: string }> }) {
  const { agentId } = await params;
  const { user, workspace } = await getCurrentWorkspace();
  if (!user) redirect("/login");
  if (!workspace) redirect("/onboarding");

  const supabase = await createClient();
  const { data: agent } = await supabase
    .from("agents")
    .select("id, name, is_active, public_agent_id, agent_settings(*)")
    .eq("id", agentId)
    .eq("workspace_id", workspace.id)
    .maybeSingle<any>();

  if (!agent) notFound();
  const settings = agent.agent_settings;
  const branding = settings?.branding ?? {};

  const boundUpdate = updateAgentSettings.bind(null, agent.id, workspace.id);
  const embedUrl = `${process.env.NEXT_PUBLIC_APP_URL}/agent/${agent.public_agent_id}`;
  const embedScript =
    `<script src="${process.env.NEXT_PUBLIC_APP_URL}/widget.js"\n` +
    `  data-agent-id="${agent.public_agent_id}"\n` +
    `  data-color="${branding.primary_color ?? "#3b6cf6"}"\n` +
    `  data-position="${branding.position ?? "right"}"${
      branding.greeting ? `\n  data-greeting="${branding.greeting}"` : ""
    }\n  async></script>`;

  return (
    <main className="mx-auto grid max-w-5xl gap-8 p-8 md:grid-cols-2">
      <div>
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">إعدادات الوكيل</h1>
          <Link href={`/dashboard/agents/${agent.id}/knowledge`} className="text-sm text-brand-600">
            قاعدة المعرفة ←
          </Link>
          <Link href={`/dashboard/agents/${agent.id}/channels`} className="text-sm text-brand-600">
            القنوات ←
          </Link>
        </div>

        <form action={boundUpdate} className="mt-4 flex flex-col gap-3">
          <label className="text-sm font-medium">اسم الوكيل</label>
          <input name="name" defaultValue={agent.name} className="rounded-lg border px-4 py-2.5" required />

          <label className="mt-2 text-sm font-medium">الشخصية</label>
          <input
            name="personality"
            defaultValue={settings?.personality ?? ""}
            placeholder="مثال: ودود ومحترف"
            className="rounded-lg border px-4 py-2.5"
          />

          <label className="mt-2 text-sm font-medium">نبرة الحديث</label>
          <input
            name="tone"
            defaultValue={settings?.tone ?? ""}
            placeholder="مثال: رسمي، عفوي، حماسي"
            className="rounded-lg border px-4 py-2.5"
          />

          <label className="mt-2 text-sm font-medium">تعليمات النظام</label>
          <textarea
            name="system_instructions"
            defaultValue={settings?.system_instructions ?? ""}
            className="min-h-28 rounded-lg border px-4 py-2.5"
          />

          <label className="mt-2 text-sm font-medium">رسالة الترحيب</label>
          <input
            name="welcome_message"
            defaultValue={settings?.welcome_message ?? ""}
            className="rounded-lg border px-4 py-2.5"
          />

          <label className="mt-2 text-sm font-medium">رسالة عدم توفر المعلومة</label>
          <input
            name="fallback_message"
            defaultValue={settings?.fallback_message ?? ""}
            className="rounded-lg border px-4 py-2.5"
            required
          />

          <label className="mt-2 text-sm font-medium">قواعد إضافية (سطر لكل قاعدة)</label>
          <textarea
            name="rules"
            defaultValue={(settings?.rules ?? []).join("\n")}
            placeholder={"مثال:\nلا تذكر الأسعار قبل تأكيد الطلب\nحوّل الشكاوى إلى موظف مباشرة"}
            className="min-h-20 rounded-lg border px-4 py-2.5"
          />

          <label className="mt-2 flex items-center gap-2 text-sm">
            <input type="checkbox" name="is_active" defaultChecked={agent.is_active} />
            الوكيل نشط ويستقبل رسائل
          </label>

          <label className="mt-2 text-sm font-medium">أسئلة تأهيل العميل (سطر لكل سؤال)</label>
          <textarea
            name="lead_questions"
            defaultValue={(settings?.lead_questions ?? []).join("\n")}
            placeholder={"مثال:\nما الخدمة التي تهتم بها؟\nما ميزانيتك التقريبية؟\nمتى تود البدء؟"}
            className="min-h-20 rounded-lg border px-4 py-2.5"
          />
          <p className="text-xs text-slate-400">
            سيحاول الوكيل استخراج إجابات هذه الأسئلة تلقائياً من المحادثة وحفظها في نظام العملاء المحتملين (CRM).
          </p>

          <h3 className="mt-4 text-sm font-semibold text-slate-600">إجراءات يمكن للوكيل تنفيذها</h3>
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              name="action_check_availability"
              defaultChecked={(settings?.allowed_actions ?? []).includes("check_calendar_availability")}
            />
            التحقق من توفر موعد في تقويم جوجل
          </label>
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              name="action_book_appointment"
              defaultChecked={(settings?.allowed_actions ?? []).includes("create_calendar_event")}
            />
            حجز الموعد فعلياً في تقويم جوجل
          </label>
          <p className="text-xs text-slate-400">
            تتطلب هذه الإجراءات ربط تقويم جوجل من صفحة القنوات أولاً — وإلا سيتجاهلها الوكيل بصمت.
          </p>

          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              name="action_send_email"
              defaultChecked={(settings?.allowed_actions ?? []).includes("send_email")}
            />
            إرسال بريد إلكتروني (يتطلب ربط Gmail من صفحة القنوات)
          </label>
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              name="action_notify_employee"
              defaultChecked={(settings?.allowed_actions ?? []).includes("notify_employee")}
            />
            إشعار صاحب النشاط عند وجود عميل مهم
          </label>
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              name="action_trigger_webhook"
              defaultChecked={(settings?.allowed_actions ?? []).includes("trigger_webhook")}
            />
            إرسال بيانات إلى نظام خارجي (Webhook)
          </label>
          <input
            name="webhook_url"
            defaultValue={settings?.webhook_url ?? ""}
            placeholder="https://example.com/webhook"
            className="rounded-lg border px-4 py-2.5"
          />
          <p className="text-xs text-slate-400">
            يُستخدم فقط إذا فعّلت "إرسال بيانات إلى نظام خارجي" أعلاه.
          </p>

          <h3 className="mt-4 text-sm font-semibold text-slate-600">تخصيص مربع المحادثة (Widget)</h3>

          <label className="text-sm font-medium">لون العلامة التجارية</label>
          <input
            type="color"
            name="brand_color"
            defaultValue={branding.primary_color ?? "#3b6cf6"}
            className="h-10 w-16 rounded-lg border p-1"
          />

          <label className="mt-2 text-sm font-medium">رابط الشعار (اختياري)</label>
          <input
            name="logo_url"
            defaultValue={branding.logo_url ?? ""}
            placeholder="https://example.com/logo.png"
            className="rounded-lg border px-4 py-2.5"
          />

          <label className="mt-2 text-sm font-medium">رسالة الفقاعة التعريفية (اختياري)</label>
          <input
            name="widget_greeting"
            defaultValue={branding.greeting ?? ""}
            placeholder="مرحباً! تحتاج مساعدة؟"
            className="rounded-lg border px-4 py-2.5"
          />

          <label className="mt-2 text-sm font-medium">موضع الزر على الموقع</label>
          <select name="widget_position" defaultValue={branding.position ?? "right"} className="rounded-lg border px-4 py-2.5">
            <option value="right">يمين</option>
            <option value="left">يسار</option>
          </select>

          <button type="submit" className="mt-2 rounded-lg bg-brand-500 px-4 py-2.5 font-medium text-white">
            حفظ الإعدادات
          </button>
        </form>

        <div className="mt-6 rounded-lg border bg-slate-50 p-4 text-sm dark:bg-slate-900">
          <p className="font-medium">رابط الصفحة العامة للوكيل</p>
          <code className="break-all text-xs text-brand-600">{embedUrl}</code>
          <p className="mt-2 text-xs text-slate-400">شارك هذا الرابط مع عملائك إذا لم يكن لديك موقع إلكتروني.</p>
        </div>

        <div className="mt-4 rounded-lg border bg-slate-50 p-4 text-sm dark:bg-slate-900">
          <p className="font-medium">إضافة الوكيل إلى موقعك الإلكتروني</p>
          <p className="mt-1 text-xs text-slate-400">
            انسخ هذا الكود والصقه قبل إغلاق وسم &lt;/body&gt; في موقعك.
          </p>
          <pre className="mt-2 overflow-x-auto rounded-md bg-slate-900 p-3 text-xs text-slate-100">
            <code>{embedScript}</code>
          </pre>
        </div>
      </div>

      <div>
        <h2 className="mb-4 text-lg font-semibold">جرّب الوكيل مباشرة</h2>
        <ChatWidget publicAgentId={agent.public_agent_id} primaryColor={branding.primary_color} />
      </div>
    </main>
  );
}
