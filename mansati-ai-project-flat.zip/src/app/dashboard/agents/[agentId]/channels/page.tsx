import { redirect, notFound } from "next/navigation";
import { revalidatePath } from "next/cache";
import crypto from "crypto";
import { getCurrentWorkspace } from "@/lib/workspace/current";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { encryptSecret, decryptSecret } from "@/lib/security/crypto";
import { telegramGetMe, telegramSetWebhook, telegramDeleteWebhook } from "@/lib/telegram/client";
import { whatsappGetPhoneNumber } from "@/lib/meta/whatsapp";

async function connectTelegram(agentId: string, workspaceId: string, formData: FormData) {
  "use server";
  const botToken = String(formData.get("bot_token") || "").trim();
  if (!botToken) {
    redirect(`/dashboard/agents/${agentId}/channels?error=` + encodeURIComponent("يرجى إدخال رمز البوت (Bot Token)"));
  }

  let botInfo;
  try {
    botInfo = await telegramGetMe(botToken);
  } catch (err: any) {
    redirect(`/dashboard/agents/${agentId}/channels?error=` + encodeURIComponent("رمز البوت غير صحيح: " + err.message));
  }

  const admin = createAdminClient();

  const { data: integration } = await admin
    .from("integrations")
    .upsert(
      { workspace_id: workspaceId, agent_id: agentId, type: "telegram", status: "pending", display_name: botInfo!.username },
      { onConflict: "workspace_id,type" }
    )
    .select("id")
    .single();

  if (!integration) {
    redirect(`/dashboard/agents/${agentId}/channels?error=connect_failed`);
  }

  const webhookSecret = crypto.randomBytes(24).toString("hex");
  const webhookUrl = `${process.env.NEXT_PUBLIC_APP_URL}/api/webhooks/telegram/${integration!.id}`;

  try {
    await telegramSetWebhook(botToken, webhookUrl, webhookSecret);
  } catch (err: any) {
    redirect(`/dashboard/agents/${agentId}/channels?error=` + encodeURIComponent("فشل ربط Webhook: " + err.message));
  }

  // Store the token encrypted — never in plain text.
  await admin.from("integration_credentials").upsert(
    { integration_id: integration!.id, encrypted_payload: encryptSecret(botToken) },
    { onConflict: "integration_id" }
  );

  await admin
    .from("integrations")
    .update({ status: "connected", metadata: { bot_username: botInfo!.username, webhook_secret: webhookSecret } })
    .eq("id", integration!.id);

  revalidatePath(`/dashboard/agents/${agentId}/channels`);
}

async function connectWhatsApp(agentId: string, workspaceId: string, formData: FormData) {
  "use server";
  const accessToken = String(formData.get("access_token") || "").trim();
  const phoneNumberId = String(formData.get("phone_number_id") || "").trim();
  if (!accessToken || !phoneNumberId) {
    redirect(`/dashboard/agents/${agentId}/channels?error=` + encodeURIComponent("أدخل WhatsApp Access Token وPhone Number ID"));
  }

  let phoneInfo;
  try {
    phoneInfo = await whatsappGetPhoneNumber(phoneNumberId, accessToken);
  } catch (err: any) {
    redirect(`/dashboard/agents/${agentId}/channels?error=` + encodeURIComponent(err?.message || "بيانات WhatsApp غير صحيحة"));
  }

  const admin = createAdminClient();
  const { data: integration } = await admin
    .from("integrations")
    .upsert(
      {
        workspace_id: workspaceId,
        agent_id: agentId,
        type: "whatsapp",
        status: "connected",
        display_name: phoneInfo?.verified_name || phoneInfo?.display_phone_number || phoneNumberId,
        metadata: {
          phone_number_id: phoneNumberId,
          display_phone_number: phoneInfo?.display_phone_number || null,
          verified_name: phoneInfo?.verified_name || null
        }
      },
      { onConflict: "workspace_id,type" }
    )
    .select("id")
    .single();

  if (!integration) redirect(`/dashboard/agents/${agentId}/channels?error=whatsapp_connect_failed`);

  await admin.from("integration_credentials").upsert(
    { integration_id: integration.id, encrypted_payload: encryptSecret(JSON.stringify({ accessToken })) },
    { onConflict: "integration_id" }
  );

  revalidatePath(`/dashboard/agents/${agentId}/channels`);
}

async function disconnectWhatsApp(agentId: string, workspaceId: string, integrationId: string) {
  "use server";
  const admin = createAdminClient();
  await admin.from("integration_credentials").delete().eq("integration_id", integrationId);
  await admin.from("integrations").update({ status: "disconnected" }).eq("id", integrationId).eq("workspace_id", workspaceId).eq("type", "whatsapp");
  revalidatePath(`/dashboard/agents/${agentId}/channels`);
}

async function disconnectTelegram(agentId: string, workspaceId: string, integrationId: string) {
  "use server";
  const admin = createAdminClient();

  const { data: cred } = await admin
    .from("integration_credentials")
    .select("encrypted_payload")
    .eq("integration_id", integrationId)
    .maybeSingle();

  if (cred) {
    await telegramDeleteWebhook(decryptSecret(cred.encrypted_payload)).catch(() => {});
  }

  await admin.from("integration_credentials").delete().eq("integration_id", integrationId);
  await admin.from("integrations").update({ status: "disconnected" }).eq("id", integrationId).eq("workspace_id", workspaceId);

  revalidatePath(`/dashboard/agents/${agentId}/channels`);
}

export default async function ChannelsPage({
  params,
  searchParams
}: {
  params: Promise<{ agentId: string }>;
  searchParams: Promise<{ error?: string }>;
}) {
  const { agentId } = await params;
  const query = await searchParams;
  const { user, workspace } = await getCurrentWorkspace();
  if (!user) redirect("/login");
  if (!workspace) redirect("/onboarding");

  const supabase = await createClient();
  const { data: agent } = await supabase
    .from("agents")
    .select("id")
    .eq("id", agentId)
    .eq("workspace_id", workspace.id)
    .maybeSingle();
  if (!agent) notFound();

  const { data: whatsappIntegration } = await supabase
    .from("integrations")
    .select("id, status, display_name, metadata")
    .eq("workspace_id", workspace.id)
    .eq("type", "whatsapp")
    .maybeSingle();

  const { data: telegramIntegration } = await supabase
    .from("integrations")
    .select("id, status, display_name")
    .eq("workspace_id", workspace.id)
    .eq("type", "telegram")
    .maybeSingle();

  const { data: calendarIntegration } = await supabase
    .from("integrations")
    .select("id, status")
    .eq("workspace_id", workspace.id)
    .eq("type", "google_calendar")
    .maybeSingle();

  const { data: gmailIntegration } = await supabase
    .from("integrations")
    .select("id, status")
    .eq("workspace_id", workspace.id)
    .eq("type", "gmail")
    .maybeSingle();

  const boundConnect = connectTelegram.bind(null, agent.id, workspace.id);

  return (
    <main className="mx-auto max-w-xl p-8">
      <h1 className="text-2xl font-bold">قنوات التواصل</h1>
      <p className="text-sm text-slate-500">اربط وكيلك الذكي بمنصات التواصل ليجيب فيها تلقائياً.</p>

      {query.error && (
        <p className="mt-4 rounded-md bg-red-50 p-3 text-sm text-red-600">{query.error}</p>
      )}

      <div className="mt-6 rounded-xl border p-4">
        <div className="flex items-center justify-between">
          <p className="font-medium">WhatsApp Business (Meta)</p>
          {whatsappIntegration?.status === "connected" && (
            <span className="rounded-full bg-emerald-100 px-3 py-1 text-xs text-emerald-700">متصل</span>
          )}
        </div>
        <p className="mt-1 text-xs text-slate-400">ربط رقم WhatsApp Business عبر Meta Cloud API ليجيب الوكيل تلقائياً.</p>

        {whatsappIntegration?.status === "connected" ? (
          <div className="mt-3 space-y-3">
            <p className="text-xs text-slate-500">
              {String((whatsappIntegration.metadata as any)?.verified_name || whatsappIntegration.display_name || "WhatsApp")}
              {((whatsappIntegration.metadata as any)?.display_phone_number) ? ` — ${(whatsappIntegration.metadata as any).display_phone_number}` : ""}
            </p>
            <p className="rounded-lg bg-slate-50 p-3 text-xs text-slate-500">
              Webhook: <span className="font-mono break-all">{process.env.NEXT_PUBLIC_APP_URL}/api/webhooks/whatsapp</span>
              <br />
              في Meta اجعل اشتراك Webhooks على حقل <span className="font-mono">messages</span>.
            </p>
            <form action={disconnectWhatsApp.bind(null, agent.id, workspace.id, whatsappIntegration.id)}>
              <button type="submit" className="rounded-lg border px-4 py-2 text-sm text-red-600">فصل WhatsApp</button>
            </form>
          </div>
        ) : (
          <form action={connectWhatsApp.bind(null, agent.id, workspace.id)} className="mt-3 flex flex-col gap-2">
            <input name="phone_number_id" placeholder="WhatsApp Phone Number ID" className="rounded-lg border px-3 py-2 text-sm" required />
            <input name="access_token" type="password" placeholder="Meta WhatsApp Access Token" className="rounded-lg border px-3 py-2 text-sm" required />
            <p className="text-xs text-slate-400">
              استخدم Access Token الخاص بتطبيق Meta/WhatsApp Business وPhone Number ID من Meta. يتم تشفير الـToken وتخزينه على الخادم فقط.
            </p>
            <button type="submit" className="w-fit rounded-lg bg-brand-500 px-4 py-2 text-sm text-white">ربط WhatsApp</button>
          </form>
        )}
      </div>

      <div className="mt-4 rounded-xl border p-4">
        <div className="flex items-center justify-between">
          <p className="font-medium">تيليجرام</p>
          {telegramIntegration?.status === "connected" && (
            <span className="rounded-full bg-emerald-100 px-3 py-1 text-xs text-emerald-700">
              متصل: @{telegramIntegration.display_name}
            </span>
          )}
        </div>

        {telegramIntegration?.status === "connected" ? (
          <form action={disconnectTelegram.bind(null, agent.id, workspace.id, telegramIntegration.id)} className="mt-3">
            <button type="submit" className="rounded-lg border px-4 py-2 text-sm text-red-600">
              فصل الاتصال
            </button>
          </form>
        ) : (
          <form action={boundConnect} className="mt-3 flex flex-col gap-2">
            <input
              name="bot_token"
              placeholder="رمز البوت من BotFather (Bot Token)"
              className="rounded-lg border px-3 py-2 text-sm"
              required
            />
            <p className="text-xs text-slate-400">
              أنشئ بوت جديد عبر تطبيق تيليجرام: تحدث مع{" "}
              <span className="font-mono">@BotFather</span> ← أرسل <span className="font-mono">/newbot</span> ← الصق
              الرمز الناتج هنا.
            </p>
            <button type="submit" className="w-fit rounded-lg bg-brand-500 px-4 py-2 text-sm text-white">
              ربط تيليجرام
            </button>
          </form>
        )}
      </div>

      <div className="mt-4 rounded-xl border p-4">
        <div className="flex items-center justify-between">
          <p className="font-medium">تقويم جوجل (حجز المواعيد)</p>
          {calendarIntegration?.status === "connected" && (
            <span className="rounded-full bg-emerald-100 px-3 py-1 text-xs text-emerald-700">متصل</span>
          )}
        </div>
        <p className="mt-1 text-xs text-slate-400">
          يتيح للوكيل التحقق من الأوقات المتاحة وإنشاء المواعيد مباشرة في تقويمك.
        </p>
        {calendarIntegration?.status === "connected" ? (
          <p className="mt-3 text-xs text-emerald-600">جاهز للاستخدام في إجراءات الوكيل.</p>
        ) : (
          <a
            href={`/api/oauth/google/connect?scope=calendar&agentId=${agent.id}`}
            className="mt-3 inline-block rounded-lg bg-brand-500 px-4 py-2 text-sm text-white"
          >
            ربط تقويم جوجل
          </a>
        )}
      </div>

      <div className="mt-4 rounded-xl border p-4">
        <div className="flex items-center justify-between">
          <p className="font-medium">Gmail (إرسال بريد إلكتروني)</p>
          {gmailIntegration?.status === "connected" && (
            <span className="rounded-full bg-emerald-100 px-3 py-1 text-xs text-emerald-700">متصل</span>
          )}
        </div>
        <p className="mt-1 text-xs text-slate-400">يتيح للوكيل إرسال رسائل بريد إلكتروني نيابة عنك عند الحاجة.</p>
        {gmailIntegration?.status === "connected" ? (
          <p className="mt-3 text-xs text-emerald-600">جاهز للاستخدام في إجراءات الوكيل.</p>
        ) : (
          <a
            href={`/api/oauth/google/connect?scope=gmail&agentId=${agent.id}`}
            className="mt-3 inline-block rounded-lg bg-brand-500 px-4 py-2 text-sm text-white"
          >
            ربط Gmail
          </a>
        )}
      </div>

      <div className="mt-4 rounded-xl border border-dashed p-4 text-sm text-slate-400">
        <p className="font-medium text-slate-500">إنستغرام وماسنجر</p>
        <p className="mt-1 text-xs">سنضيف تكامل Meta لباقي القنوات بعد تفعيل WhatsApp واختباره.</p>
      </div>
    </main>
  );
}
