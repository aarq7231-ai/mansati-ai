import { redirect } from "next/navigation";
import Link from "next/link";
import { getCurrentWorkspace } from "@/lib/workspace/current";
import { createClient } from "@/lib/supabase/server";

export default async function AgentsListPage() {
  const { user, workspace } = await getCurrentWorkspace();
  if (!user) redirect("/login");
  if (!workspace) redirect("/onboarding");

  const supabase = await createClient();
  const { data: agents } = await supabase
    .from("agents")
    .select("id, name, public_agent_id, is_active")
    .eq("workspace_id", workspace.id);

  return (
    <main className="mx-auto max-w-2xl p-8">
      <h1 className="text-2xl font-bold">الوكلاء الأذكياء</h1>
      <ul className="mt-4 flex flex-col gap-2">
        {agents?.map((agent) => (
          <li key={agent.id}>
            <Link href={`/dashboard/agents/${agent.id}`} className="block rounded-lg border p-4 hover:bg-slate-50">
              <p className="font-medium">{agent.name}</p>
              <p className="text-xs text-slate-400">{agent.is_active ? "نشط" : "متوقف"}</p>
            </Link>
          </li>
        ))}
      </ul>
    </main>
  );
}
