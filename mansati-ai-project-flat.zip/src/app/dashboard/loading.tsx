export default function DashboardLoading() {
  return (
    <main className="mx-auto max-w-3xl p-8">
      <div className="animate-pulse space-y-4">
        <div className="h-7 w-48 rounded bg-slate-200 dark:bg-slate-800" />
        <div className="h-24 w-full rounded-xl bg-slate-100 dark:bg-slate-900" />
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-20 rounded-xl bg-slate-100 dark:bg-slate-900" />
          ))}
        </div>
      </div>
    </main>
  );
}
