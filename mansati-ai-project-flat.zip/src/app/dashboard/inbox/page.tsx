import { redirect } from "next/navigation";
import Link from "next/link";
import { getCurrentWorkspace } from "@/lib/workspace/current";
import { createClient } from "@/lib/supabase/server";
import AutoRefresh from "@/components/auto-refresh";

const CHANNEL_LABELS: Record<string, string> = {
  website: "الموقع الإلكتروني",
  whatsapp: "واتساب",
  instagram: "إنستغرام",
  messenger: "ماسنجر",
  telegram: "تيليجرام"
};

const STATUS_LABELS: Record<string, string> = {
  ai_active: "يرد الوكيل الذكي",
  human_active: "بانتظار / يرد موظف",
  closed: "مغلقة"
};

export default async function InboxPage() {
  const { user, workspace } = await getCurrentWorkspace();
  if (!user) redirect("/login");
  if (!workspace) redirect("/onboarding");

  const supabase = await createClient();
  const { data: conversations } = await supabase
    .from("conversations")
    .select("id, channel, status, updated_at, agents(name), contacts(name, phone)")
    .eq("workspace_id", workspace.id)
    .order("updated_at", { ascending: false })
    .limit(50);

  return (
    <main className="mx-auto max-w-3xl p-8">
      <AutoRefresh intervalMs={6000} />
      <h1 className="text-2xl font-bold">صندوق الوارد الموحّد</h1>
      <p className="text-sm text-slate-500">جميع المحادثات من كل القنوات في مكان واحد.</p>

      <ul className="mt-6 flex flex-col gap-2">
        {conversations?.length === 0 && (
          <p className="text-sm text-slate-400">لا توجد محادثات بعد.</p>
        )}
        {conversations?.map((c: any) => (
          <li key={c.id}>
            <Link
              href={`/dashboard/inbox/${c.id}`}
              className="flex items-center justify-between rounded-lg border p-4 hover:bg-slate-50 dark:hover:bg-slate-900"
            >
              <div>
                <p className="font-medium">{c.contacts?.name || c.contacts?.phone || "زائر"}</p>
                <p className="text-xs text-slate-400">
                  {CHANNEL_LABELS[c.channel] ?? c.channel} · {c.agents?.name}
                </p>
              </div>
              <span
                className={`rounded-full px-3 py-1 text-xs ${
                  c.status === "human_active"
                    ? "bg-amber-100 text-amber-700"
                    : c.status === "closed"
                    ? "bg-slate-100 text-slate-500"
                    : "bg-emerald-100 text-emerald-700"
                }`}
              >
                {STATUS_LABELS[c.status] ?? c.status}
              </span>
            </Link>
          </li>
        ))}
      </ul>
    </main>
  );
}
