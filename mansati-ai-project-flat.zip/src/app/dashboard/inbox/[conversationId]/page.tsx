import { redirect, notFound } from "next/navigation";
import Link from "next/link";
import { revalidatePath } from "next/cache";
import { getCurrentWorkspace } from "@/lib/workspace/current";
import { createClient } from "@/lib/supabase/server";
import AutoRefresh from "@/components/auto-refresh";

async function requireConversation(conversationId: string, workspaceId: string) {
  const supabase = await createClient();
  const { data } = await supabase
    .from("conversations")
    .select("id, workspace_id")
    .eq("id", conversationId)
    .eq("workspace_id", workspaceId)
    .maybeSingle();
  if (!data) notFound();
}

async function claimConversation(conversationId: string, workspaceId: string, userId: string) {
  "use server";
  await requireConversation(conversationId, workspaceId);
  const supabase = await createClient();
  await supabase
    .from("conversations")
    .update({ status: "human_active", assigned_staff_id: userId })
    .eq("id", conversationId);
  revalidatePath(`/dashboard/inbox/${conversationId}`);
}

async function releaseToAI(conversationId: string, workspaceId: string) {
  "use server";
  await requireConversation(conversationId, workspaceId);
  const supabase = await createClient();
  await supabase
    .from("conversations")
    .update({ status: "ai_active", assigned_staff_id: null })
    .eq("id", conversationId);
  revalidatePath(`/dashboard/inbox/${conversationId}`);
}

async function closeConversation(conversationId: string, workspaceId: string) {
  "use server";
  await requireConversation(conversationId, workspaceId);
  const supabase = await createClient();
  await supabase.from("conversations").update({ status: "closed" }).eq("id", conversationId);
  revalidatePath(`/dashboard/inbox/${conversationId}`);
}

async function sendStaffMessage(
  conversationId: string,
  workspaceId: string,
  formData: FormData
) {
  "use server";
  await requireConversation(conversationId, workspaceId);
  const content = String(formData.get("content") || "").trim();
  if (!content) return;

  const supabase = await createClient();
  await supabase.from("messages").insert({
    workspace_id: workspaceId,
    conversation_id: conversationId,
    role: "staff",
    content
  });
  // Touch the conversation so it resurfaces at the top of the inbox.
  await supabase.from("conversations").update({ updated_at: new Date().toISOString() }).eq("id", conversationId);

  revalidatePath(`/dashboard/inbox/${conversationId}`);
  revalidatePath("/dashboard/inbox");
}

const ROLE_LABELS: Record<string, string> = {
  user: "العميل",
  assistant: "الوكيل الذكي",
  staff: "موظف",
  system: "النظام"
};

export default async function ConversationPage({
  params
}: {
  params: Promise<{ conversationId: string }>;
}) {
  const { conversationId } = await params;
  const { user, workspace } = await getCurrentWorkspace();
  if (!user) redirect("/login");
  if (!workspace) redirect("/onboarding");

  const supabase = await createClient();
  const { data: conversation } = await supabase
    .from("conversations")
    .select("id, status, channel, agents(name), contacts(name, phone)")
    .eq("id", conversationId)
    .eq("workspace_id", workspace.id)
    .maybeSingle<any>();

  if (!conversation) notFound();

  const { data: messages } = await supabase
    .from("messages")
    .select("id, role, content, created_at")
    .eq("conversation_id", conversationId)
    .order("created_at", { ascending: true });

  const boundClaim = claimConversation.bind(null, conversation.id, workspace.id, user.id);
  const boundRelease = releaseToAI.bind(null, conversation.id, workspace.id);
  const boundClose = closeConversation.bind(null, conversation.id, workspace.id);
  const boundSend = sendStaffMessage.bind(null, conversation.id, workspace.id);

  return (
    <main className="mx-auto max-w-2xl p-8">
      <AutoRefresh />
      <Link href="/dashboard/inbox" className="text-sm text-brand-600">
        ← كل المحادثات
      </Link>

      <div className="mt-2 flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold">{conversation.contacts?.name || conversation.contacts?.phone || "زائر"}</h1>
          <p className="text-xs text-slate-400">{conversation.agents?.name}</p>
        </div>

        <div className="flex gap-2">
          {conversation.status !== "human_active" ? (
            <form action={boundClaim}>
              <button className="rounded-lg bg-amber-500 px-3 py-1.5 text-sm text-white">
                تحويل إلى موظف
              </button>
            </form>
          ) : (
            <form action={boundRelease}>
              <button className="rounded-lg border px-3 py-1.5 text-sm">إعادة إلى الوكيل الذكي</button>
            </form>
          )}
          {conversation.status !== "closed" && (
            <form action={boundClose}>
              <button className="rounded-lg border px-3 py-1.5 text-sm text-slate-500">إغلاق</button>
            </form>
          )}
        </div>
      </div>

      <div className="mt-4 flex flex-col gap-3 rounded-xl border p-4">
        {messages?.map((m) => (
          <div key={m.id} className={`flex ${m.role === "user" ? "justify-start" : "justify-end"}`}>
            <div
              className={`max-w-[80%] rounded-2xl px-4 py-2 text-sm ${
                m.role === "user"
                  ? "bg-slate-100 dark:bg-slate-800"
                  : m.role === "staff"
                  ? "bg-amber-500 text-white"
                  : "bg-brand-500 text-white"
              }`}
            >
              <p className="mb-0.5 text-[10px] opacity-70">{ROLE_LABELS[m.role] ?? m.role}</p>
              {m.content}
            </div>
          </div>
        ))}
      </div>

      {conversation.status === "human_active" ? (
        <form action={boundSend} className="mt-4 flex gap-2">
          <input
            name="content"
            placeholder="اكتب ردك كموظف..."
            required
            className="flex-1 rounded-full border px-4 py-2 text-sm"
          />
          <button type="submit" className="rounded-full bg-amber-500 px-4 py-2 text-sm font-medium text-white">
            إرسال
          </button>
        </form>
      ) : (
        <p className="mt-4 text-center text-xs text-slate-400">
          حوّل المحادثة إلى موظف أولاً لتتمكن من الرد يدوياً.
        </p>
      )}
    </main>
  );
}
