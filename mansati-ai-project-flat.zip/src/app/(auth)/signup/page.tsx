import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

async function signup(formData: FormData) {
  "use server";

  const email = String(formData.get("email") || "").trim();
  const password = String(formData.get("password") || "");
  const fullName = String(formData.get("full_name") || "").trim();
  const refCode = String(formData.get("ref") || "").trim() || null;

  if (!email || !password || password.length < 8) {
    redirect("/signup?error=" + encodeURIComponent("يرجى إدخال بريد إلكتروني صحيح وكلمة مرور 8 أحرف على الأقل"));
  }

  const supabase = await createClient();
  const { error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      // ref_code rides along in user metadata until onboarding creates the
      // workspace — that's when the actual referrals row gets written,
      // since a workspace doesn't exist yet at signup time.
      data: { full_name: fullName, ref_code: refCode },
      emailRedirectTo: `${process.env.NEXT_PUBLIC_APP_URL}/api/auth/callback`
    }
  });

  if (error) {
    redirect("/signup?error=" + encodeURIComponent(error.message));
  }

  // Supabase requires email confirmation by default. Send them to a
  // "check your email" state rather than straight into onboarding.
  redirect("/signup?check_email=1");
}

export default async function SignupPage({
  searchParams
}: {
  searchParams: Promise<{ error?: string; check_email?: string; ref?: string }>;
}) {
  const params = await searchParams;

  if (params.check_email) {
    return (
      <main className="mx-auto flex min-h-screen max-w-md flex-col items-center justify-center gap-3 p-8 text-center">
        <h1 className="text-xl font-semibold">تحقق من بريدك الإلكتروني</h1>
        <p className="text-slate-500">أرسلنا رابط تأكيد. اضغط عليه لإكمال إنشاء الحساب.</p>
      </main>
    );
  }

  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col justify-center gap-4 p-8">
      <h1 className="text-2xl font-bold">ابدأ مجاناً لمدة 3 أيام</h1>
      <p className="text-sm text-slate-500">بدون بطاقة ائتمان.</p>

      {params.error && (
        <p className="rounded-md bg-red-50 p-3 text-sm text-red-600">{params.error}</p>
      )}

      <form action={signup} className="flex flex-col gap-3">
        {params.ref && <input type="hidden" name="ref" value={params.ref} />}
        <input
          name="full_name"
          placeholder="الاسم الكامل"
          className="rounded-lg border px-4 py-2.5"
          required
        />
        <input
          name="email"
          type="email"
          placeholder="البريد الإلكتروني"
          className="rounded-lg border px-4 py-2.5"
          required
        />
        <input
          name="password"
          type="password"
          placeholder="كلمة المرور"
          minLength={8}
          className="rounded-lg border px-4 py-2.5"
          required
        />
        <button type="submit" className="rounded-lg bg-brand-500 px-4 py-2.5 font-medium text-white">
          إنشاء حساب
        </button>
      </form>
    </main>
  );
}
