import { redirect } from "next/navigation";
import Link from "next/link";
import { createClient } from "@/lib/supabase/server";

// `next` comes straight from a query param / hidden form field, so it must
// never be handed to redirect() unsanitized — redirect() will happily
// follow an absolute URL, turning this into an open redirect (e.g.
// /login?next=https://evil.example after a real, successful login). Only
// same-site relative paths are allowed; anything else falls back to a
// safe default.
function sanitizeNextPath(next: string): string {
  if (next.startsWith("/") && !next.startsWith("//") && !next.startsWith("/\\")) {
    return next;
  }
  return "/dashboard";
}

async function login(formData: FormData) {
  "use server";

  const email = String(formData.get("email") || "").trim();
  const password = String(formData.get("password") || "");
  const next = sanitizeNextPath(String(formData.get("next") || "/dashboard"));

  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword({ email, password });

  if (error) {
    redirect("/login?error=" + encodeURIComponent("البريد الإلكتروني أو كلمة المرور غير صحيحة"));
  }

  redirect(next);
}

export default async function LoginPage({
  searchParams
}: {
  searchParams: Promise<{ error?: string; next?: string }>;
}) {
  const params = await searchParams;
  const safeNext = sanitizeNextPath(params.next || "/dashboard");

  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col justify-center gap-4 p-8">
      <h1 className="text-2xl font-bold">تسجيل الدخول</h1>

      {params.error && (
        <p className="rounded-md bg-red-50 p-3 text-sm text-red-600">{params.error}</p>
      )}

      <form action={login} className="flex flex-col gap-3">
        <input type="hidden" name="next" value={safeNext} />
        <input name="email" type="email" placeholder="البريد الإلكتروني" className="rounded-lg border px-4 py-2.5" required />
        <input name="password" type="password" placeholder="كلمة المرور" className="rounded-lg border px-4 py-2.5" required />
        <button type="submit" className="rounded-lg bg-brand-500 px-4 py-2.5 font-medium text-white">
          دخول
        </button>
      </form>

      <div className="flex justify-between text-sm">
        <Link href="/reset-password" className="text-brand-600">نسيت كلمة المرور؟</Link>
        <Link href="/signup" className="text-brand-600">إنشاء حساب جديد</Link>
      </div>
    </main>
  );
}
