import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

/**
 * Landed on after /api/auth/callback exchanges the recovery-link code for a
 * real session (see reset-password/page.tsx, which points the emailed link
 * here). The user is already authenticated at this point — Supabase's
 * password-recovery flow works by signing the user in via the link, then
 * letting them set a new password with a normal authenticated
 * `updateUser` call — so this just needs the form, not another code
 * exchange.
 */
async function updatePassword(formData: FormData) {
  "use server";

  const password = String(formData.get("password") || "");
  const confirmPassword = String(formData.get("confirm_password") || "");

  if (password.length < 8) {
    redirect("/reset-password/confirm?error=" + encodeURIComponent("كلمة المرور يجب أن تكون 8 أحرف على الأقل"));
  }
  if (password !== confirmPassword) {
    redirect("/reset-password/confirm?error=" + encodeURIComponent("كلمتا المرور غير متطابقتين"));
  }

  const supabase = await createClient();

  // No active session means this wasn't reached via a valid recovery link
  // (e.g. someone navigating here directly, or a stale/expired link whose
  // callback exchange failed) — nothing to update.
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) redirect("/reset-password?error=" + encodeURIComponent("انتهت صلاحية الرابط، أعد المحاولة"));

  const { error } = await supabase.auth.updateUser({ password });
  if (error) {
    redirect("/reset-password/confirm?error=" + encodeURIComponent(error.message));
  }

  redirect("/dashboard");
}

export default async function ResetPasswordConfirmPage({
  searchParams
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const params = await searchParams;

  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) redirect("/reset-password?error=" + encodeURIComponent("انتهت صلاحية الرابط، أعد المحاولة"));

  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col justify-center gap-4 p-8">
      <h1 className="text-2xl font-bold">اختر كلمة مرور جديدة</h1>

      {params.error && (
        <p className="rounded-md bg-red-50 p-3 text-sm text-red-600">{params.error}</p>
      )}

      <form action={updatePassword} className="flex flex-col gap-3">
        <input
          name="password"
          type="password"
          placeholder="كلمة المرور الجديدة"
          minLength={8}
          className="rounded-lg border px-4 py-2.5"
          required
        />
        <input
          name="confirm_password"
          type="password"
          placeholder="تأكيد كلمة المرور"
          minLength={8}
          className="rounded-lg border px-4 py-2.5"
          required
        />
        <button type="submit" className="rounded-lg bg-brand-500 px-4 py-2.5 font-medium text-white">
          حفظ كلمة المرور
        </button>
      </form>
    </main>
  );
}
