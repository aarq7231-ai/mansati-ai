import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

async function requestReset(formData: FormData) {
  "use server";

  const email = String(formData.get("email") || "").trim();
  const supabase = await createClient();

  await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${process.env.NEXT_PUBLIC_APP_URL}/api/auth/callback?next=/reset-password/confirm`
  });

  // Always show the same message whether or not the email exists,
  // to avoid leaking which emails are registered.
  redirect("/reset-password?sent=1");
}

export default async function ResetPasswordPage({
  searchParams
}: {
  searchParams: Promise<{ sent?: string }>;
}) {
  const params = await searchParams;

  if (params.sent) {
    return (
      <main className="mx-auto flex min-h-screen max-w-md flex-col items-center justify-center gap-3 p-8 text-center">
        <h1 className="text-xl font-semibold">تحقق من بريدك الإلكتروني</h1>
        <p className="text-slate-500">إذا كان الحساب موجوداً، أرسلنا رابط إعادة تعيين كلمة المرور.</p>
      </main>
    );
  }

  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col justify-center gap-4 p-8">
      <h1 className="text-2xl font-bold">إعادة تعيين كلمة المرور</h1>
      <form action={requestReset} className="flex flex-col gap-3">
        <input name="email" type="email" placeholder="البريد الإلكتروني" className="rounded-lg border px-4 py-2.5" required />
        <button type="submit" className="rounded-lg bg-brand-500 px-4 py-2.5 font-medium text-white">
          إرسال رابط إعادة التعيين
        </button>
      </form>
    </main>
  );
}
