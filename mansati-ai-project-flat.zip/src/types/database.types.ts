/**
 * Hand-written types matching supabase/all_migrations_combined.sql.
 *
 * Once you have a real Supabase project linked, you can replace this file
 * with a fully machine-generated version by running:
 *   npx supabase login
 *   npx supabase link --project-ref <your-project-ref>
 *   npm run types:gen
 * That generates exact types for ALL tables/enums/relationships
 * automatically. This file covers every table the current codebase
 * touches, including each table's `Relationships` array (foreign keys) —
 * without it, PostgREST's embedded selects (e.g. `agents(name)`,
 * `plans(price_cents)`) resolve to a `SelectQueryError` type at compile
 * time even though they work fine at runtime, so keep this in sync with
 * `all_migrations_combined.sql` if you add a table or a foreign key
 * before regenerating for real.
 */

export type Json = string | number | boolean | null | { [key: string]: Json } | Json[];

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          full_name: string | null;
          avatar_url: string | null;
          preferred_language: "ar" | "en";
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["profiles"]["Row"]> & { id: string };
        Update: Partial<Database["public"]["Tables"]["profiles"]["Row"]>;
        Relationships: [];
      };
      workspaces: {
        Row: {
          id: string;
          name: string;
          slug: string;
          business_type: string | null;
          country: string | null;
          preferred_language: "ar" | "en";
          business_description: string | null;
          website_url: string | null;
          logo_url: string | null;
          timezone: string;
          onboarding_completed: boolean;
          is_suspended: boolean;
          suspended_reason: string | null;
          referral_code: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["workspaces"]["Row"]> & { name: string; slug: string };
        Update: Partial<Database["public"]["Tables"]["workspaces"]["Row"]>;
        Relationships: [];
      };
      workspace_members: {
        Row: {
          id: string;
          workspace_id: string;
          user_id: string;
          role: "owner" | "admin" | "agent_staff";
          created_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["workspace_members"]["Row"]> & {
          workspace_id: string;
          user_id: string;
        };
        Update: Partial<Database["public"]["Tables"]["workspace_members"]["Row"]>;
        Relationships: [{ foreignKeyName: "workspace_members_workspace_id_fkey", columns: ["workspace_id"], isOneToOne: false, referencedRelation: "workspaces", referencedColumns: ["id"] }];
      };
      plans: {
        Row: {
          id: string;
          key: string;
          name: string;
          price_cents: number;
          currency: string;
          interval: "month" | "year";
          message_limit: number;
          storage_limit_mb: number;
          agent_limit: number;
          file_limit: number;
          is_public: boolean;
          is_active: boolean;
          sort_order: number;
          provider_metadata: Json;
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["plans"]["Row"]> & { key: string; name: string; message_limit: number; storage_limit_mb: number; agent_limit: number; file_limit: number };
        Update: Partial<Database["public"]["Tables"]["plans"]["Row"]>;
        Relationships: [];
      };
      subscriptions: {
        Row: {
          id: string;
          workspace_id: string;
          plan_id: string;
          status: "trialing" | "active" | "past_due" | "canceled" | "expired";
          billing_provider: string | null;
          provider_customer_id: string | null;
          provider_subscription_id: string | null;
          trial_started_at: string;
          trial_ends_at: string;
          current_period_start: string | null;
          current_period_end: string | null;
          canceled_at: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["subscriptions"]["Row"]> & { workspace_id: string; plan_id: string };
        Update: Partial<Database["public"]["Tables"]["subscriptions"]["Row"]>;
        Relationships: [{ foreignKeyName: "subscriptions_workspace_id_fkey", columns: ["workspace_id"], isOneToOne: true, referencedRelation: "workspaces", referencedColumns: ["id"] }, { foreignKeyName: "subscriptions_plan_id_fkey", columns: ["plan_id"], isOneToOne: false, referencedRelation: "plans", referencedColumns: ["id"] }];
      };
      agents: {
        Row: {
          id: string;
          workspace_id: string;
          template_id: string | null;
          public_agent_id: string;
          name: string;
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["agents"]["Row"]> & { workspace_id: string; name: string };
        Update: Partial<Database["public"]["Tables"]["agents"]["Row"]>;
        Relationships: [{ foreignKeyName: "agents_workspace_id_fkey", columns: ["workspace_id"], isOneToOne: false, referencedRelation: "workspaces", referencedColumns: ["id"] }, { foreignKeyName: "agents_template_id_fkey", columns: ["template_id"], isOneToOne: false, referencedRelation: "agent_templates", referencedColumns: ["id"] }];
      };
      agent_settings: {
        Row: {
          agent_id: string;
          language: string;
          personality: string | null;
          tone: string | null;
          system_instructions: string | null;
          welcome_message: string | null;
          fallback_message: string;
          rules: Json;
          lead_questions: Json;
          handoff_triggers: Json;
          allowed_actions: Json;
          branding: Json;
          ai_provider: string;
          ai_model: string | null;
          webhook_url: string | null;
          updated_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["agent_settings"]["Row"]> & { agent_id: string };
        Update: Partial<Database["public"]["Tables"]["agent_settings"]["Row"]>;
        Relationships: [{ foreignKeyName: "agent_settings_agent_id_fkey", columns: ["agent_id"], isOneToOne: true, referencedRelation: "agents", referencedColumns: ["id"] }];
      };
      conversations: {
        Row: {
          id: string;
          workspace_id: string;
          agent_id: string;
          contact_id: string | null;
          channel: "website" | "whatsapp" | "instagram" | "messenger" | "telegram";
          status: "ai_active" | "human_active" | "closed";
          assigned_staff_id: string | null;
          external_thread_id: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["conversations"]["Row"]> & {
          workspace_id: string;
          agent_id: string;
        };
        Update: Partial<Database["public"]["Tables"]["conversations"]["Row"]>;
        Relationships: [{ foreignKeyName: "conversations_workspace_id_fkey", columns: ["workspace_id"], isOneToOne: false, referencedRelation: "workspaces", referencedColumns: ["id"] }, { foreignKeyName: "conversations_agent_id_fkey", columns: ["agent_id"], isOneToOne: false, referencedRelation: "agents", referencedColumns: ["id"] }, { foreignKeyName: "conversations_contact_id_fkey", columns: ["contact_id"], isOneToOne: false, referencedRelation: "contacts", referencedColumns: ["id"] }];
      };
      messages: {
        Row: {
          id: string;
          workspace_id: string;
          conversation_id: string;
          role: "user" | "assistant" | "system" | "staff";
          content: string;
          input_tokens: number | null;
          output_tokens: number | null;
          feedback: number | null;
          created_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["messages"]["Row"]> & {
          workspace_id: string;
          conversation_id: string;
          role: "user" | "assistant" | "system" | "staff";
          content: string;
        };
        Update: Partial<Database["public"]["Tables"]["messages"]["Row"]>;
        Relationships: [{ foreignKeyName: "messages_workspace_id_fkey", columns: ["workspace_id"], isOneToOne: false, referencedRelation: "workspaces", referencedColumns: ["id"] }, { foreignKeyName: "messages_conversation_id_fkey", columns: ["conversation_id"], isOneToOne: false, referencedRelation: "conversations", referencedColumns: ["id"] }];
      };
      usage: {
        Row: {
          id: string;
          workspace_id: string;
          period_start: string;
          period_end: string;
          ai_messages_used: number;
          input_tokens_used: number;
          output_tokens_used: number;
          storage_used_mb: number;
          documents_count: number;
          agents_count: number;
          integrations_count: number;
          updated_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["usage"]["Row"]> & { workspace_id: string };
        Update: Partial<Database["public"]["Tables"]["usage"]["Row"]>;
        Relationships: [{ foreignKeyName: "usage_workspace_id_fkey", columns: ["workspace_id"], isOneToOne: false, referencedRelation: "workspaces", referencedColumns: ["id"] }];
      };
      knowledge_sources: {
        Row: {
          id: string;
          workspace_id: string;
          agent_id: string;
          type: "pdf" | "docx" | "txt" | "csv" | "xlsx" | "website" | "manual_text";
          source_url: string | null;
          created_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["knowledge_sources"]["Row"]> & {
          workspace_id: string;
          agent_id: string;
          type: "pdf" | "docx" | "txt" | "csv" | "xlsx" | "website" | "manual_text";
        };
        Update: Partial<Database["public"]["Tables"]["knowledge_sources"]["Row"]>;
        Relationships: [{ foreignKeyName: "knowledge_sources_workspace_id_fkey", columns: ["workspace_id"], isOneToOne: false, referencedRelation: "workspaces", referencedColumns: ["id"] }, { foreignKeyName: "knowledge_sources_agent_id_fkey", columns: ["agent_id"], isOneToOne: false, referencedRelation: "agents", referencedColumns: ["id"] }];
      };
      documents: {
        Row: {
          id: string;
          workspace_id: string;
          knowledge_source_id: string;
          file_name: string;
          file_type: string | null;
          file_size_bytes: number | null;
          storage_path: string | null;
          status: "pending" | "processing" | "ready" | "error";
          error_message: string | null;
          uploaded_at: string;
          processed_at: string | null;
        };
        Insert: Partial<Database["public"]["Tables"]["documents"]["Row"]> & {
          workspace_id: string;
          knowledge_source_id: string;
          file_name: string;
        };
        Update: Partial<Database["public"]["Tables"]["documents"]["Row"]>;
        Relationships: [{ foreignKeyName: "documents_workspace_id_fkey", columns: ["workspace_id"], isOneToOne: false, referencedRelation: "workspaces", referencedColumns: ["id"] }, { foreignKeyName: "documents_knowledge_source_id_fkey", columns: ["knowledge_source_id"], isOneToOne: false, referencedRelation: "knowledge_sources", referencedColumns: ["id"] }];
      };
      document_chunks: {
        Row: {
          id: string;
          workspace_id: string;
          document_id: string;
          chunk_index: number;
          content: string;
          embedding: string | null;
          created_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["document_chunks"]["Row"]> & {
          workspace_id: string;
          document_id: string;
          chunk_index: number;
          content: string;
        };
        Update: Partial<Database["public"]["Tables"]["document_chunks"]["Row"]>;
        Relationships: [{ foreignKeyName: "document_chunks_workspace_id_fkey", columns: ["workspace_id"], isOneToOne: false, referencedRelation: "workspaces", referencedColumns: ["id"] }, { foreignKeyName: "document_chunks_document_id_fkey", columns: ["document_id"], isOneToOne: false, referencedRelation: "documents", referencedColumns: ["id"] }];
      };
      contacts: {
        Row: {
          id: string;
          workspace_id: string;
          name: string | null;
          phone: string | null;
          email: string | null;
          source: string | null;
          tags: string[];
          notes: string | null;
          last_interaction_at: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["contacts"]["Row"]> & { workspace_id: string };
        Update: Partial<Database["public"]["Tables"]["contacts"]["Row"]>;
        Relationships: [{ foreignKeyName: "contacts_workspace_id_fkey", columns: ["workspace_id"], isOneToOne: false, referencedRelation: "workspaces", referencedColumns: ["id"] }];
      };
      leads: {
        Row: {
          id: string;
          workspace_id: string;
          contact_id: string;
          conversation_id: string | null;
          status: "new" | "interested" | "qualified" | "negotiation" | "won" | "lost";
          answers: Json;
          value_estimate: number | null;
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["leads"]["Row"]> & { workspace_id: string; contact_id: string };
        Update: Partial<Database["public"]["Tables"]["leads"]["Row"]>;
        Relationships: [{ foreignKeyName: "leads_workspace_id_fkey", columns: ["workspace_id"], isOneToOne: false, referencedRelation: "workspaces", referencedColumns: ["id"] }, { foreignKeyName: "leads_contact_id_fkey", columns: ["contact_id"], isOneToOne: false, referencedRelation: "contacts", referencedColumns: ["id"] }, { foreignKeyName: "leads_conversation_id_fkey", columns: ["conversation_id"], isOneToOne: false, referencedRelation: "conversations", referencedColumns: ["id"] }];
      };
      lead_events: {
        Row: {
          id: string;
          workspace_id: string;
          lead_id: string;
          event_type: string;
          metadata: Json;
          created_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["lead_events"]["Row"]> & {
          workspace_id: string;
          lead_id: string;
          event_type: string;
        };
        Update: Partial<Database["public"]["Tables"]["lead_events"]["Row"]>;
        Relationships: [{ foreignKeyName: "lead_events_workspace_id_fkey", columns: ["workspace_id"], isOneToOne: false, referencedRelation: "workspaces", referencedColumns: ["id"] }, { foreignKeyName: "lead_events_lead_id_fkey", columns: ["lead_id"], isOneToOne: false, referencedRelation: "leads", referencedColumns: ["id"] }];
      };
      admin_logs: {
        Row: {
          id: string;
          admin_user_id: string;
          action: string;
          target_workspace_id: string | null;
          metadata: Json;
          created_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["admin_logs"]["Row"]> & {
          admin_user_id: string;
          action: string;
        };
        Update: Partial<Database["public"]["Tables"]["admin_logs"]["Row"]>;
        Relationships: [{ foreignKeyName: "admin_logs_target_workspace_id_fkey", columns: ["target_workspace_id"], isOneToOne: false, referencedRelation: "workspaces", referencedColumns: ["id"] }];
      };
      platform_admins: {
        Row: { user_id: string; created_at: string };
        Insert: { user_id: string; created_at?: string };
        Update: Partial<Database["public"]["Tables"]["platform_admins"]["Row"]>;
        Relationships: [];
      };
      integrations: {
        Row: {
          id: string;
          workspace_id: string;
          agent_id: string | null;
          type: "whatsapp" | "instagram" | "messenger" | "telegram" | "google_calendar" | "gmail";
          status: string;
          display_name: string | null;
          metadata: Json;
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["integrations"]["Row"]> & {
          workspace_id: string;
          type: "whatsapp" | "instagram" | "messenger" | "telegram" | "google_calendar" | "gmail";
        };
        Update: Partial<Database["public"]["Tables"]["integrations"]["Row"]>;
        Relationships: [{ foreignKeyName: "integrations_workspace_id_fkey", columns: ["workspace_id"], isOneToOne: false, referencedRelation: "workspaces", referencedColumns: ["id"] }, { foreignKeyName: "integrations_agent_id_fkey", columns: ["agent_id"], isOneToOne: false, referencedRelation: "agents", referencedColumns: ["id"] }];
      };
      integration_credentials: {
        Row: { id: string; integration_id: string; encrypted_payload: string; created_at: string; updated_at: string };
        Insert: Partial<Database["public"]["Tables"]["integration_credentials"]["Row"]> & {
          integration_id: string;
          encrypted_payload: string;
        };
        Update: Partial<Database["public"]["Tables"]["integration_credentials"]["Row"]>;
        Relationships: [{ foreignKeyName: "integration_credentials_integration_id_fkey", columns: ["integration_id"], isOneToOne: true, referencedRelation: "integrations", referencedColumns: ["id"] }];
      };
      agent_templates: {
        Row: {
          id: string;
          key: string;
          name: string;
          business_type: string;
          description: string | null;
          suggested_system_instructions: string | null;
          suggested_tone: string | null;
          suggested_greeting: string | null;
          suggested_faq: Json;
          suggested_lead_questions: Json;
          suggested_actions: Json;
          is_marketplace_item: boolean;
          created_by: string | null;
          created_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["agent_templates"]["Row"]> & {
          key: string;
          name: string;
          business_type: string;
        };
        Update: Partial<Database["public"]["Tables"]["agent_templates"]["Row"]>;
        Relationships: [];
      };
      notifications: {
        Row: {
          id: string;
          workspace_id: string;
          user_id: string | null;
          type: string;
          title: string;
          body: string | null;
          read_at: string | null;
          created_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["notifications"]["Row"]> & {
          workspace_id: string;
          type: string;
          title: string;
        };
        Update: Partial<Database["public"]["Tables"]["notifications"]["Row"]>;
        Relationships: [{ foreignKeyName: "notifications_workspace_id_fkey", columns: ["workspace_id"], isOneToOne: false, referencedRelation: "workspaces", referencedColumns: ["id"] }];
      };
      referrals: {
        Row: {
          id: string;
          referrer_workspace_id: string;
          referred_workspace_id: string | null;
          code: string;
          status: string;
          reward_type: string | null;
          reward_value: string | null;
          created_at: string;
          converted_at: string | null;
        };
        Insert: Partial<Database["public"]["Tables"]["referrals"]["Row"]> & {
          referrer_workspace_id: string;
          code: string;
        };
        Update: Partial<Database["public"]["Tables"]["referrals"]["Row"]>;
        Relationships: [{ foreignKeyName: "referrals_referrer_workspace_id_fkey", columns: ["referrer_workspace_id"], isOneToOne: false, referencedRelation: "workspaces", referencedColumns: ["id"] }, { foreignKeyName: "referrals_referred_workspace_id_fkey", columns: ["referred_workspace_id"], isOneToOne: false, referencedRelation: "workspaces", referencedColumns: ["id"] }];
      };
    };
    Views: Record<string, never>;
    Functions: {
      is_workspace_member: { Args: { ws_id: string }; Returns: boolean };
      is_workspace_admin_or_owner: { Args: { ws_id: string }; Returns: boolean };
      is_platform_admin: { Args: Record<string, never>; Returns: boolean };
      check_and_increment_usage: {
        Args: { p_workspace_id: string };
        Returns: { allowed: boolean; messages_used: number; message_limit: number }[];
      };
      record_token_usage: {
        Args: { p_workspace_id: string; p_input_tokens: number; p_output_tokens: number };
        Returns: void;
      };
      release_ai_reply_usage: {
        Args: { p_workspace_id: string };
        Returns: void;
      };
      match_document_chunks: {
        Args: { p_agent_id: string; p_query_embedding: string; p_match_count: number };
        Returns: { content: string; similarity: number }[];
      };
    };
    Enums: {
      workspace_role: "owner" | "admin" | "agent_staff";
      subscription_status: "trialing" | "active" | "past_due" | "canceled" | "expired";
    };
  };
}
