"use client";

import { useRef, useState } from "react";

interface DisplayMessage {
  role: "user" | "assistant";
  content: string;
}

interface ChatWidgetProps {
  publicAgentId: string;
  /** Business's brand color (from agent_settings.branding.primary_color). Falls back to the default brand color. */
  primaryColor?: string;
  /** Stretch to fill the parent container instead of using a fixed max-width/height (used inside the widget iframe). */
  fill?: boolean;
}

/**
 * Minimal but fully functional chat UI: streaming responses, typing
 * indicator, retry on error. Used by the dashboard's "test your agent"
 * panel, the public standalone chat page, and the embeddable widget's
 * iframe content — all three just pass different props.
 */
export default function ChatWidget({ publicAgentId, primaryColor, fill }: ChatWidgetProps) {
  const accent = primaryColor || "#3b6cf6";
  const [messages, setMessages] = useState<DisplayMessage[]>([]);
  const [input, setInput] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);
  const conversationIdRef = useRef<string | null>(null);

  async function send() {
    const text = input.trim();
    if (!text || isStreaming) return;

    setMessages((prev) => [...prev, { role: "user", content: text }, { role: "assistant", content: "" }]);
    setInput("");
    setIsStreaming(true);

    try {
      const res = await fetch(`/api/chat/${publicAgentId}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text, conversationId: conversationIdRef.current })
      });

      if (!res.body) throw new Error("no response body");

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        const frames = buffer.split("\n\n");
        buffer = frames.pop() ?? "";

        for (const frame of frames) {
          const line = frame.trim();
          if (!line.startsWith("data:")) continue;
          const json = JSON.parse(line.slice("data:".length).trim());

          if (json.delta) {
            setMessages((prev) => {
              const next = [...prev];
              next[next.length - 1] = {
                role: "assistant",
                content: next[next.length - 1].content + json.delta
              };
              return next;
            });
          }
          if (json.done) {
            conversationIdRef.current = json.conversationId ?? conversationIdRef.current;
          }
        }
      }
    } catch (err) {
      setMessages((prev) => {
        const next = [...prev];
        next[next.length - 1] = { role: "assistant", content: "حدث خطأ في الاتصال. حاول مرة أخرى." };
        return next;
      });
    } finally {
      setIsStreaming(false);
    }
  }

  return (
    <div
      className={
        fill
          ? "flex h-full w-full flex-col"
          : "flex h-[520px] w-full max-w-md flex-col rounded-2xl border shadow-sm"
      }
    >
      <div className="flex-1 space-y-3 overflow-y-auto p-4">
        {messages.length === 0 && (
          <p className="text-center text-sm text-slate-400">ابدأ المحادثة بكتابة رسالة بالأسفل 👇</p>
        )}
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[80%] rounded-2xl px-4 py-2 text-sm ${
                m.role === "user" ? "text-white" : "bg-slate-100 dark:bg-slate-800"
              }`}
              style={m.role === "user" ? { backgroundColor: accent } : undefined}
            >
              {m.content || (isStreaming && i === messages.length - 1 ? "…" : "")}
            </div>
          </div>
        ))}
      </div>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          send();
        }}
        className="flex gap-2 border-t p-3"
      >
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="اكتب رسالتك..."
          className="flex-1 rounded-full border px-4 py-2 text-sm"
          disabled={isStreaming}
        />
        <button
          type="submit"
          disabled={isStreaming || !input.trim()}
          className="rounded-full px-4 py-2 text-sm font-medium text-white disabled:opacity-50"
          style={{ backgroundColor: accent }}
        >
          إرسال
        </button>
      </form>
    </div>
  );
}
