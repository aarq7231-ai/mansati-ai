"use client";

import { useRouter } from "next/navigation";
import type { Lang } from "@/lib/i18n/dictionaries";

export default function LangSwitcher({ current }: { current: Lang }) {
  const router = useRouter();
  const other: Lang = current === "ar" ? "en" : "ar";

  async function switchLang() {
    await fetch("/api/set-lang", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ lang: other })
    });
    router.refresh();
  }

  return (
    <button onClick={switchLang} className="rounded-lg border px-3 py-1.5 text-sm">
      {other === "ar" ? "العربية" : "English"}
    </button>
  );
}
