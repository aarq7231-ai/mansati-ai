"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";

/**
 * Simple polling refresh — re-runs the server component every few seconds
 * so a staff member watching a conversation sees new customer/AI messages
 * arrive. A real-time subscription (Supabase Realtime) is a clean upgrade
 * path later; this needs no new infrastructure to ship now.
 */
export default function AutoRefresh({ intervalMs = 4000 }: { intervalMs?: number }) {
  const router = useRouter();

  useEffect(() => {
    const id = setInterval(() => router.refresh(), intervalMs);
    return () => clearInterval(id);
  }, [router, intervalMs]);

  return null;
}
