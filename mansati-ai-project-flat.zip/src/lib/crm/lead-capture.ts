import "server-only";
import { createAdminClient } from "@/lib/supabase/admin";
import { extractLeadAnswers } from "@/lib/ai/extract-lead-answers";

/**
 * Called once per conversation, right when it's created (spec section 20:
 * "Allow automatic lead creation from conversations"). Anonymous at this
 * point — website visitors haven't given a name/phone yet — but having
 * the contact+lead rows in place from message one means qualification
 * answers have somewhere to land as soon as they're extracted.
 */
export async function ensureContactAndLead(params: {
  workspaceId: string;
  conversationId: string;
  channel: string;
}): Promise<{ contactId: string; leadId: string }> {
  const admin = createAdminClient();

  const { data: contact } = await admin
    .from("contacts")
    .insert({ workspace_id: params.workspaceId, source: params.channel })
    .select("id")
    .single();

  await admin.from("conversations").update({ contact_id: contact!.id }).eq("id", params.conversationId);

  const { data: lead } = await admin
    .from("leads")
    .insert({
      workspace_id: params.workspaceId,
      contact_id: contact!.id,
      conversation_id: params.conversationId,
      status: "new"
    })
    .select("id")
    .single();

  await admin.from("lead_events").insert({
    workspace_id: params.workspaceId,
    lead_id: lead!.id,
    event_type: "created",
    metadata: { channel: params.channel }
  });

  return { contactId: contact!.id, leadId: lead!.id };
}

/**
 * Runs after each assistant reply. Extracts answers to the agent's
 * configured lead_questions from the conversation so far, merges any new
 * ones into leads.answers (never overwriting previously-captured answers
 * with a blank), and bumps the lead to "qualified" once every question
 * has been answered.
 */
export async function updateLeadFromConversation(params: {
  workspaceId: string;
  conversationId: string;
  leadQuestions: string[];
}): Promise<void> {
  if (params.leadQuestions.length === 0) return;

  const admin = createAdminClient();

  const { data: lead } = await admin
    .from("leads")
    .select("id, answers, status")
    .eq("conversation_id", params.conversationId)
    .maybeSingle<any>();
  if (!lead) return;

  const { data: history } = await admin
    .from("messages")
    .select("role, content")
    .eq("conversation_id", params.conversationId)
    .order("created_at", { ascending: true })
    .limit(30);

  const conversationText = (history ?? [])
    .filter((m: any) => m.role === "user" || m.role === "assistant")
    .map((m: any) => `${m.role === "user" ? "العميل" : "الوكيل"}: ${m.content}`)
    .join("\n");

  const extracted = await extractLeadAnswers({ questions: params.leadQuestions, conversationText });
  if (Object.keys(extracted).length === 0) return;

  const mergedAnswers = { ...(lead.answers ?? {}), ...extracted };
  const allAnswered = params.leadQuestions.every((q) => !!mergedAnswers[q]);

  await admin
    .from("leads")
    .update({
      answers: mergedAnswers,
      status: allAnswered && lead.status === "new" ? "qualified" : lead.status
    })
    .eq("id", lead.id);

  if (allAnswered && lead.status === "new") {
    await admin.from("lead_events").insert({
      workspace_id: params.workspaceId,
      lead_id: lead.id,
      event_type: "auto_qualified",
      metadata: { answers: mergedAnswers }
    });
  }
}
