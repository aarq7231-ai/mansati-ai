import "server-only";

const TELEGRAM_API = "https://api.telegram.org/bot";

export async function telegramGetMe(botToken: string) {
  const res = await fetch(`${TELEGRAM_API}${botToken}/getMe`);
  const data = await res.json();
  if (!data.ok) throw new Error(data.description || "Invalid Telegram bot token");
  return data.result as { id: number; username: string; first_name: string };
}

export async function telegramSetWebhook(botToken: string, url: string, secretToken: string) {
  const res = await fetch(`${TELEGRAM_API}${botToken}/setWebhook`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ url, secret_token: secretToken, allowed_updates: ["message"] })
  });
  const data = await res.json();
  if (!data.ok) throw new Error(data.description || "Failed to set Telegram webhook");
}

export async function telegramDeleteWebhook(botToken: string) {
  await fetch(`${TELEGRAM_API}${botToken}/deleteWebhook`, { method: "POST" });
}

export async function telegramSendMessage(botToken: string, chatId: number | string, text: string) {
  const res = await fetch(`${TELEGRAM_API}${botToken}/sendMessage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ chat_id: chatId, text })
  });
  const data = await res.json();
  if (!data.ok) throw new Error(data.description || "Failed to send Telegram message");
}
