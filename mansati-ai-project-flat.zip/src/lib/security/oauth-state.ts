import "server-only";
import crypto from "crypto";
import { getEncryptionKey } from "./crypto";

/**
 * Signed, expiring `state` payload for the Google OAuth flow.
 *
 * The previous implementation just base64-encoded { workspaceId, agentId,
 * scope } with no signature — anyone could tamper with the `state` query
 * param on the way back from Google (or simply construct their own) and
 * point a completed OAuth consent at an arbitrary workspaceId, hijacking
 * that workspace's Calendar/Gmail integration. This wraps the same payload
 * with an HMAC (keyed with the same ENCRYPTION_KEY already required for
 * integration secrets) plus an issued-at timestamp, and the callback route
 * both verifies the signature and re-checks that the requesting user still
 * owns the workspace before trusting anything in it.
 */
export interface OAuthStatePayload {
  workspaceId: string;
  agentId: string;
  scope: "calendar" | "gmail";
  userId: string;
  iat: number; // ms epoch, when the state was issued
}

const STATE_MAX_AGE_MS = 15 * 60 * 1000; // 15 minutes — plenty for a consent flow, short enough to limit replay

function sign(payloadB64: string): string {
  return crypto.createHmac("sha256", getEncryptionKey()).update(payloadB64).digest("base64url");
}

export function signOAuthState(payload: Omit<OAuthStatePayload, "iat">): string {
  const full: OAuthStatePayload = { ...payload, iat: Date.now() };
  const payloadB64 = Buffer.from(JSON.stringify(full)).toString("base64url");
  const signature = sign(payloadB64);
  return `${payloadB64}.${signature}`;
}

/** Returns the verified payload, or null if the state is missing, malformed, tampered with, or expired. */
export function verifyOAuthState(state: string | null): OAuthStatePayload | null {
  if (!state) return null;
  const [payloadB64, signature] = state.split(".");
  if (!payloadB64 || !signature) return null;

  const expected = sign(payloadB64);
  const sigBuf = Buffer.from(signature);
  const expectedBuf = Buffer.from(expected);
  if (sigBuf.length !== expectedBuf.length || !crypto.timingSafeEqual(sigBuf, expectedBuf)) {
    return null;
  }

  try {
    const payload = JSON.parse(Buffer.from(payloadB64, "base64url").toString("utf-8")) as OAuthStatePayload;
    if (
      typeof payload.workspaceId !== "string" ||
      typeof payload.userId !== "string" ||
      typeof payload.iat !== "number" ||
      (payload.scope !== "calendar" && payload.scope !== "gmail")
    ) {
      return null;
    }
    if (Date.now() - payload.iat > STATE_MAX_AGE_MS) return null;
    return payload;
  } catch {
    return null;
  }
}
