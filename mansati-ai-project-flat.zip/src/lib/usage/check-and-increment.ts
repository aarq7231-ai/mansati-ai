import "server-only";
import { createAdminClient } from "@/lib/supabase/admin";

/**
 * Reserves one AI reply slot atomically before generation. If generation fails,
 * callers MUST release the reservation so failed requests never consume a reply.
 */
export async function checkAndIncrementUsage(workspaceId: string) {
  const admin = createAdminClient();
  const { data, error } = await admin
    .rpc("check_and_increment_usage", { p_workspace_id: workspaceId })
    .single();

  if (error || !data) return { allowed: false, messagesUsed: 0, messageLimit: 0 };

  return {
    allowed: (data as any).allowed as boolean,
    messagesUsed: (data as any).messages_used as number,
    messageLimit: (data as any).message_limit as number
  };
}

export async function releaseUsageReservation(workspaceId: string) {
  const admin = createAdminClient();
  await admin.rpc("release_ai_reply_usage", { p_workspace_id: workspaceId });
}

export async function recordTokenUsage(workspaceId: string, inputTokens: number, outputTokens: number) {
  const admin = createAdminClient();
  await admin.rpc("record_token_usage", {
    p_workspace_id: workspaceId,
    p_input_tokens: inputTokens,
    p_output_tokens: outputTokens
  });
}
