import "server-only";

/**
 * Extracts plain text from a raw file buffer based on its type.
 * pdf/docx/xlsx extraction uses small, well-established libraries — added
 * to package.json (pdf-parse, mammoth, xlsx) — imported dynamically so a
 * missing/broken parser for one file type never breaks the others.
 */
export async function extractTextFromFile(buffer: Buffer, fileType: string): Promise<string> {
  const type = fileType.toLowerCase();

  if (type === "txt" || type === "text/plain") {
    return buffer.toString("utf-8");
  }

  if (type === "csv" || type === "text/csv") {
    // CSV is already plain text; keep row structure so the model can read it
    // as structured data rather than one long unbroken line.
    return buffer.toString("utf-8");
  }

  if (type === "pdf" || type === "application/pdf") {
    const pdfParse = (await import("pdf-parse")).default;
    const result = await pdfParse(buffer);
    return result.text;
  }

  if (
    type === "docx" ||
    type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
  ) {
    const mammoth = await import("mammoth");
    const result = await mammoth.extractRawText({ buffer });
    return result.value;
  }

  if (
    type === "xlsx" ||
    type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
  ) {
    const XLSX = await import("xlsx");
    const workbook = XLSX.read(buffer, { type: "buffer" });
    return workbook.SheetNames.map((sheetName) => {
      const sheet = workbook.Sheets[sheetName];
      return `# ${sheetName}\n${XLSX.utils.sheet_to_csv(sheet)}`;
    }).join("\n\n");
  }

  throw new Error(`Unsupported file type for text extraction: ${fileType}`);
}

/**
 * Fetches a web page and strips it down to readable text. Deliberately
 * simple (no headless browser, no JS execution) — matches the spec's
 * requirement to avoid heavyweight/illegal scraping. Respects robots.txt
 * by checking it before fetching the target page.
 */
export async function extractTextFromUrl(url: string): Promise<string> {
  const parsed = new URL(url);

  const robotsUrl = `${parsed.origin}/robots.txt`;
  const disallowedForAll = await fetch(robotsUrl)
    .then((r) => (r.ok ? r.text() : ""))
    .then((robotsTxt) => isPathDisallowed(robotsTxt, parsed.pathname))
    .catch(() => false); // if robots.txt is unreachable, proceed cautiously (don't block legitimate use)

  if (disallowedForAll) {
    throw new Error("This page disallows automated access via robots.txt.");
  }

  const res = await fetch(url, { headers: { "User-Agent": "MansatiAI-KnowledgeBot/1.0" } });
  if (!res.ok) throw new Error(`Failed to fetch ${url}: ${res.status}`);
  const html = await res.text();

  return html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function isPathDisallowed(robotsTxt: string, path: string): boolean {
  // Minimal robots.txt parser: only checks a blanket "User-agent: *" block's
  // Disallow rules. Good enough for MVP-level respect of site preferences.
  const lines = robotsTxt.split("\n").map((l) => l.trim());
  let inWildcardBlock = false;
  for (const line of lines) {
    if (/^user-agent:\s*\*/i.test(line)) inWildcardBlock = true;
    else if (/^user-agent:/i.test(line)) inWildcardBlock = false;
    else if (inWildcardBlock && /^disallow:/i.test(line)) {
      const rule = line.split(":")[1]?.trim();
      if (rule && rule !== "" && path.startsWith(rule)) return true;
    }
  }
  return false;
}
