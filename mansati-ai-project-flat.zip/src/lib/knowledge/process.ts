import "server-only";
import { createAdminClient } from "@/lib/supabase/admin";
import { getEmbeddingProvider, toVectorLiteral } from "@/lib/ai/embeddings";
import { extractTextFromFile, extractTextFromUrl } from "./extract";
import { chunkText } from "./chunk";

/**
 * Runs the full pipeline for a single `documents` row:
 *   extract text -> chunk -> embed -> store in document_chunks -> mark ready
 *
 * Called synchronously right after upload for this phase (files are small
 * business documents, not massive archives). If upload volume grows, this
 * is the function to move into a background queue — nothing about its
 * signature would need to change for callers.
 */
export async function processDocument(documentId: string): Promise<void> {
  const admin = createAdminClient();

  const { data: doc } = await admin
    .from("documents")
    .select("id, workspace_id, knowledge_source_id, file_name, file_type, storage_path")
    .eq("id", documentId)
    .single();

  if (!doc) return;

  await admin.from("documents").update({ status: "processing" }).eq("id", documentId);

  try {
    const { data: source } = await admin
      .from("knowledge_sources")
      .select("type, source_url")
      .eq("id", doc.knowledge_source_id)
      .single();

    let text = "";

    if (source?.type === "website" && source.source_url) {
      text = await extractTextFromUrl(source.source_url);
    } else if (source?.type === "manual_text") {
      // Manual text is stored directly on the document row's storage_path
      // field as a plain string for simplicity — see addManualText() in
      // the knowledge dashboard page.
      text = doc.storage_path ?? "";
    } else if (doc.storage_path) {
      const { data: fileBlob, error: downloadError } = await admin.storage
        .from("knowledge-files")
        .download(doc.storage_path);
      if (downloadError || !fileBlob) throw new Error("Failed to download file from storage");
      const buffer = Buffer.from(await fileBlob.arrayBuffer());
      text = await extractTextFromFile(buffer, doc.file_type ?? "");
    }

    const chunks = chunkText(text);
    if (chunks.length === 0) {
      await admin
        .from("documents")
        .update({ status: "error", error_message: "لم يتم العثور على نص قابل للقراءة في هذا المصدر." })
        .eq("id", documentId);
      return;
    }

    const embeddingProvider = getEmbeddingProvider();
    const vectors = await embeddingProvider.embed(chunks);

    const rows = chunks.map((content, i) => ({
      workspace_id: doc.workspace_id,
      document_id: doc.id,
      chunk_index: i,
      content,
      embedding: toVectorLiteral(vectors[i])
    }));

    // Replace any previous chunks (covers the "reprocess" action).
    await admin.from("document_chunks").delete().eq("document_id", doc.id);
    await admin.from("document_chunks").insert(rows);

    await admin
      .from("documents")
      .update({ status: "ready", processed_at: new Date().toISOString(), error_message: null })
      .eq("id", documentId);
  } catch (err: any) {
    await admin
      .from("documents")
      .update({ status: "error", error_message: err?.message ?? "فشل في معالجة المصدر" })
      .eq("id", documentId);
  }
}
