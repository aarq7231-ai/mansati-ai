import { createClient } from "@/lib/supabase/server";

/**
 * Resolves the signed-in user's primary workspace. This is the single
 * choke point every feature route should call instead of re-deriving
 * "which tenant am I in" logic ad hoc — keeps multi-tenancy consistent
 * as staff/multi-workspace support grows later.
 *
 * Relies on RLS (workspace_members) to only ever return workspaces the
 * user actually belongs to — this function does not itself grant access.
 */
export async function getCurrentWorkspace() {
  const supabase = await createClient();

  const {
    data: { user }
  } = await supabase.auth.getUser();

  if (!user) return { user: null, workspace: null };

  const { data: membership } = await supabase
    .from("workspace_members")
    .select("workspace_id, role, workspaces(*)")
    .eq("user_id", user.id)
    .order("created_at", { ascending: true })
    .limit(1)
    .maybeSingle();

  return {
    user,
    workspace: membership?.workspaces ?? null,
    role: membership?.role ?? null
  };
}
