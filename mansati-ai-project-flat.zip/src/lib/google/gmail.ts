import "server-only";

function toBase64Url(str: string): string {
  return Buffer.from(str, "utf-8").toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

// RFC 2822 headers must be ASCII. Subjects are frequently Arabic here, so
// non-ASCII text has to be wrapped as an RFC 2047 encoded-word or it gets
// mangled (or rejected) by mail clients — plain UTF-8 bytes in a header is
// not valid RFC 2822/2047.
function encodeHeaderValue(value: string): string {
  // eslint-disable-next-line no-control-regex
  if (/^[\x00-\x7F]*$/.test(value)) return value;
  return `=?UTF-8?B?${Buffer.from(value, "utf-8").toString("base64")}?=`;
}

export async function sendGmail(
  accessToken: string,
  params: { to: string; subject: string; body: string }
): Promise<{ id: string }> {
  // Gmail's API takes a full RFC 2822 message, base64url-encoded — no need
  // for a mail library for a simple plain-text send.
  const message = [
    `To: ${params.to}`,
    `Subject: ${encodeHeaderValue(params.subject)}`,
    "MIME-Version: 1.0",
    "Content-Type: text/plain; charset=utf-8",
    "Content-Transfer-Encoding: base64",
    "",
    Buffer.from(params.body, "utf-8").toString("base64")
  ].join("\r\n");

  const res = await fetch("https://gmail.googleapis.com/gmail/v1/users/me/messages/send", {
    method: "POST",
    headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
    body: JSON.stringify({ raw: toBase64Url(message) })
  });

  if (!res.ok) throw new Error(`Failed to send email: ${await res.text()}`);
  return res.json();
}
