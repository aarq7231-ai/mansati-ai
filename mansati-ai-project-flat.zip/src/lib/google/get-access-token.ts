import "server-only";
import { createAdminClient } from "@/lib/supabase/admin";
import { decryptSecret } from "@/lib/security/crypto";
import { refreshGoogleAccessToken } from "./oauth";

/**
 * Always exchanges the stored refresh_token for a fresh access_token
 * rather than caching one with an expiry to track — one extra network
 * call per use, but it sidesteps an entire class of "token expired
 * mid-request" bugs for a feature that isn't called on every message.
 */
export async function getGoogleAccessToken(workspaceId: string, type: "google_calendar" | "gmail"): Promise<string> {
  const admin = createAdminClient();

  const { data: integration } = await admin
    .from("integrations")
    .select("id, status")
    .eq("workspace_id", workspaceId)
    .eq("type", type)
    .maybeSingle();

  if (!integration || integration.status !== "connected") {
    throw new Error(`${type} is not connected for this workspace.`);
  }

  const { data: cred } = await admin
    .from("integration_credentials")
    .select("encrypted_payload")
    .eq("integration_id", integration.id)
    .single();
  if (!cred) throw new Error(`No stored credentials for ${type}.`);

  const refreshToken = decryptSecret(cred.encrypted_payload);
  const { access_token } = await refreshGoogleAccessToken(refreshToken);
  return access_token;
}
