import "server-only";

const CALENDAR_API = "https://www.googleapis.com/calendar/v3";

export async function checkCalendarAvailability(
  accessToken: string,
  params: { calendarId?: string; timeMin: string; timeMax: string }
): Promise<{ busy: { start: string; end: string }[] }> {
  const res = await fetch(`${CALENDAR_API}/freeBusy`, {
    method: "POST",
    headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      timeMin: params.timeMin,
      timeMax: params.timeMax,
      items: [{ id: params.calendarId ?? "primary" }]
    })
  });
  if (!res.ok) throw new Error(`Calendar freeBusy check failed: ${await res.text()}`);
  const data = await res.json();
  return { busy: data.calendars?.[params.calendarId ?? "primary"]?.busy ?? [] };
}

export async function createCalendarEvent(
  accessToken: string,
  params: { calendarId?: string; summary: string; description?: string; startTime: string; endTime: string; attendeeEmail?: string }
) {
  const res = await fetch(`${CALENDAR_API}/calendars/${params.calendarId ?? "primary"}/events`, {
    method: "POST",
    headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      summary: params.summary,
      description: params.description,
      start: { dateTime: params.startTime },
      end: { dateTime: params.endTime },
      attendees: params.attendeeEmail ? [{ email: params.attendeeEmail }] : undefined
    })
  });
  if (!res.ok) throw new Error(`Failed to create calendar event: ${await res.text()}`);
  return res.json() as Promise<{ id: string; htmlLink: string }>;
}

export async function updateCalendarEvent(
  accessToken: string,
  params: { calendarId?: string; eventId: string; startTime?: string; endTime?: string; summary?: string }
) {
  const body: Record<string, unknown> = {};
  if (params.summary) body.summary = params.summary;
  if (params.startTime) body.start = { dateTime: params.startTime };
  if (params.endTime) body.end = { dateTime: params.endTime };

  const res = await fetch(`${CALENDAR_API}/calendars/${params.calendarId ?? "primary"}/events/${params.eventId}`, {
    method: "PATCH",
    headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  if (!res.ok) throw new Error(`Failed to update calendar event: ${await res.text()}`);
  return res.json();
}

export async function cancelCalendarEvent(accessToken: string, params: { calendarId?: string; eventId: string }) {
  const res = await fetch(`${CALENDAR_API}/calendars/${params.calendarId ?? "primary"}/events/${params.eventId}`, {
    method: "DELETE",
    headers: { Authorization: `Bearer ${accessToken}` }
  });
  if (!res.ok && res.status !== 410) throw new Error(`Failed to cancel calendar event: ${await res.text()}`);
}
