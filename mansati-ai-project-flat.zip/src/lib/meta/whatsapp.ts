import "server-only";

const GRAPH_API_BASE = "https://graph.facebook.com";

function graphVersion() {
  return process.env.META_GRAPH_API_VERSION || "v23.0";
}

function graphUrl(path: string) {
  return `${GRAPH_API_BASE}/${graphVersion()}/${path.replace(/^\//, "")}`;
}

export type WhatsAppCredentials = {
  accessToken: string;
};

export async function whatsappGetPhoneNumber(phoneNumberId: string, accessToken: string) {
  const res = await fetch(
    graphUrl(`${encodeURIComponent(phoneNumberId)}?fields=id,display_phone_number,verified_name`),
    { headers: { Authorization: `Bearer ${accessToken}` }, cache: "no-store" }
  );
  const data = await res.json().catch(() => ({}));
  if (!res.ok || data.error) {
    throw new Error(data?.error?.message || "تعذر التحقق من WhatsApp Phone Number ID أو Access Token");
  }
  return data as { id: string; display_phone_number?: string; verified_name?: string };
}

export async function whatsappSendText(
  phoneNumberId: string,
  accessToken: string,
  to: string,
  body: string
) {
  const res = await fetch(graphUrl(`${encodeURIComponent(phoneNumberId)}/messages`), {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to,
      type: "text",
      text: { preview_url: false, body }
    })
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok || data.error) {
    throw new Error(data?.error?.message || "فشل إرسال رسالة WhatsApp");
  }
  return data;
}
