export type Lang = "ar" | "en";

export const dictionaries = {
  ar: {
    dir: "rtl" as const,
    nav: { login: "تسجيل الدخول", signup: "ابدأ مجاناً" },
    hero: {
      title: "موظفك الذكي الذي يعمل 24/7",
      subtitle:
        "أنشئ وكيل ذكاء اصطناعي يجيب على عملائك، يجمع العملاء المحتملين، ويحجز المواعيد — على موقعك وقنوات التواصل، دون أن يغلق أبداً.",
      cta: "ابدأ مجاناً لمدة 3 أيام",
      ctaNote: "بدون بطاقة ائتمان",
      secondaryCta: "شاهد كيف يعمل"
    },
    features: {
      title: "كل ما يحتاجه نشاطك التجاري",
      items: [
        { title: "يجيب من معرفتك", desc: "ارفع مستندات نشاطك التجاري أو موقعك الإلكتروني، ويجيب الوكيل من محتواها فقط — بدون اختلاق معلومات." },
        { title: "يجمع العملاء المحتملين", desc: "يسأل الأسئلة التي تحددها ويحفظ الإجابات تلقائياً في نظام إدارة العملاء المدمج." },
        { title: "يحوّل للموظف عند الحاجة", desc: "عندما يحتاج العميل لموظف بشري، ينتقل الوكيل بسلاسة ويتوقف عن الرد فوراً." },
        { title: "يعمل في كل مكان", desc: "على موقعك، وقريباً واتساب وإنستغرام وماسنجر وتيليجرام — من محادثة واحدة موحدة." },
        { title: "بلا حدود مخفية", desc: "أنت من يتحكم بشخصية الوكيل، لهجته، وقواعده — بدون أي كود." },
        { title: "جاهز خلال دقائق", desc: "أخبرنا عن نشاطك التجاري وسننشئ لك أول وكيل ذكي تلقائياً." }
      ]
    },
    useCases: {
      title: "لكل نوع من الأنشطة التجارية",
      items: ["مطاعم", "فنادق", "عيادات", "متاجر", "عقارات", "صالونات", "نوادي رياضية", "معارض سيارات", "مدارس ومعاهد", "شركات خدمية"]
    },
    pricing: {
      title: "سعر واحد بسيط",
      subtitle: "بدون رسوم مخفية، وبدون بطاقة ائتمان لتجربة المنصة",
      perMonth: "شهرياً",
      trialNote: "٣ أيام مجاناً، ثم",
      messagesIncluded: "رسالة ذكاء اصطناعي شهرياً",
      cta: "ابدأ الآن"
    },
    faq: {
      title: "الأسئلة الشائعة",
      items: [
        { q: "هل أحتاج بطاقة ائتمان للتجربة؟", a: "لا، يمكنك تجربة المنصة لمدة 3 أيام كاملة بدون أي بطاقة ائتمان." },
        { q: "هل يمكن للوكيل الإجابة بلغتي؟", a: "نعم، يدعم الوكيل العربية والإنجليزية ويمكن تخصيص اللغة من إعدادات الوكيل." },
        { q: "ماذا يحدث إذا لم يعرف الوكيل الإجابة؟", a: "الوكيل مصمم ليقول بصراحة إنه لا يملك معلومة مؤكدة بدلاً من اختلاقها، ويمكنه تحويل المحادثة لموظف بشري." },
        { q: "هل بياناتي معزولة عن باقي المستخدمين؟", a: "نعم، كل نشاط تجاري له مساحة عمل معزولة بالكامل على مستوى قاعدة البيانات." }
      ]
    },
    testimonials: { title: "يثق بنا أصحاب الأنشطة التجارية" },
    footer: { rights: "جميع الحقوق محفوظة" }
  },
  en: {
    dir: "ltr" as const,
    nav: { login: "Log in", signup: "Start free" },
    hero: {
      title: "Your AI employee who works 24/7",
      subtitle:
        "Create an AI agent that answers your customers, collects leads, and books appointments — on your website and messaging channels, and it never closes.",
      cta: "Start free for 3 days",
      ctaNote: "No credit card required",
      secondaryCta: "See how it works"
    },
    features: {
      title: "Everything your business needs",
      items: [
        { title: "Answers from your knowledge", desc: "Upload your business documents or website, and the agent answers only from that content — never invented." },
        { title: "Collects leads automatically", desc: "Asks the qualification questions you define and saves answers straight into the built-in CRM." },
        { title: "Hands off to a human", desc: "When a customer needs a person, the agent steps back smoothly and stays silent immediately." },
        { title: "Works everywhere", desc: "On your website, and soon WhatsApp, Instagram, Messenger, and Telegram — one unified inbox." },
        { title: "No hidden limits", desc: "You control the agent's personality, tone, and rules — no code required." },
        { title: "Ready in minutes", desc: "Tell us about your business and we'll create your first AI agent automatically." }
      ]
    },
    useCases: {
      title: "Built for every kind of business",
      items: ["Restaurants", "Hotels", "Clinics", "Stores", "Real Estate", "Salons", "Gyms", "Car Dealerships", "Schools", "Service Businesses"]
    },
    pricing: {
      title: "One simple price",
      subtitle: "No hidden fees, no credit card to try the platform",
      perMonth: "/ month",
      trialNote: "3 days free, then",
      messagesIncluded: "AI messages / month",
      cta: "Get started"
    },
    faq: {
      title: "Frequently asked questions",
      items: [
        { q: "Do I need a credit card to try it?", a: "No — you get a full 3-day trial with no credit card required." },
        { q: "Can the agent reply in my language?", a: "Yes, Arabic and English are supported, configurable per agent." },
        { q: "What happens if the agent doesn't know the answer?", a: "It's designed to say so honestly instead of making something up, and can hand the conversation to a human." },
        { q: "Is my data isolated from other users?", a: "Yes — every business gets a fully isolated workspace enforced at the database level." }
      ]
    },
    testimonials: { title: "Trusted by business owners" },
    footer: { rights: "All rights reserved" }
  }
} satisfies Record<Lang, unknown>;

export function getDictionary(lang: Lang) {
  return dictionaries[lang];
}
