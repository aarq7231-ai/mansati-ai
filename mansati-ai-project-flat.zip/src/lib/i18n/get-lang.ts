import { cookies } from "next/headers";
import type { Lang } from "./dictionaries";

export async function getLang(): Promise<Lang> {
  const stored = (await cookies()).get("lang")?.value;
  return stored === "en" ? "en" : "ar";
}
