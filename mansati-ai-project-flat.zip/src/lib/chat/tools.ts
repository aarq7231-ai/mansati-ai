import "server-only";
import type { ToolDefinition } from "@/lib/ai/types";
import { getGoogleAccessToken } from "@/lib/google/get-access-token";
import { checkCalendarAvailability, createCalendarEvent } from "@/lib/google/calendar";
import { sendGmail } from "@/lib/google/gmail";
import { createAdminClient } from "@/lib/supabase/admin";

export interface ToolSet {
  definitions: ToolDefinition[];
  executeTool: (name: string, args: Record<string, unknown>) => Promise<Record<string, unknown>>;
}

/**
 * Only ever exposes a tool to the model if the corresponding
 * agent_settings.allowed_actions entry is present AND whatever it depends
 * on (an integration, a configured URL) is actually in place — a tool the
 * model can "see" but that would fail is worse than not offering it.
 */
export async function buildToolSet(params: {
  workspaceId: string;
  agentId: string;
  allowedActions: unknown;
  webhookUrl?: string | null;
}): Promise<ToolSet | null> {
  const allowed = Array.isArray(params.allowedActions) ? (params.allowedActions as string[]) : [];
  const definitions: ToolDefinition[] = [];
  const admin = createAdminClient();

  const integrationStatus = async (type: "google_calendar" | "gmail") => {
    const { data } = await admin
      .from("integrations")
      .select("status")
      .eq("workspace_id", params.workspaceId)
      .eq("type", type)
      .maybeSingle();
    return data?.status === "connected";
  };

  const calendarConnected =
    allowed.includes("check_calendar_availability") || allowed.includes("create_calendar_event")
      ? await integrationStatus("google_calendar")
      : false;

  const gmailConnected = allowed.includes("send_email") ? await integrationStatus("gmail") : false;

  if (allowed.includes("check_calendar_availability") && calendarConnected) {
    definitions.push({
      name: "check_calendar_availability",
      description: "يتحقق مما إذا كان وقت معين متاحاً في التقويم. استخدمه قبل تأكيد أي موعد مع العميل.",
      parameters: {
        type: "object",
        properties: {
          start_time_iso: { type: "string", description: "بداية الوقت المطلوب فحصه، بصيغة ISO 8601 مع فرق التوقيت، مثال: 2026-09-20T14:00:00+03:00" },
          end_time_iso: { type: "string", description: "نهاية الوقت المطلوب فحصه، بنفس الصيغة" }
        },
        required: ["start_time_iso", "end_time_iso"]
      }
    });
  }

  if (allowed.includes("create_calendar_event") && calendarConnected) {
    definitions.push({
      name: "create_calendar_event",
      description: "يحجز موعداً فعلياً في التقويم. استخدمه فقط بعد تأكيد العميل للوقت والتحقق من توفره.",
      parameters: {
        type: "object",
        properties: {
          summary: { type: "string", description: "عنوان الموعد، مثال: موعد مع أحمد" },
          start_time_iso: { type: "string", description: "بداية الموعد بصيغة ISO 8601 مع فرق التوقيت" },
          end_time_iso: { type: "string", description: "نهاية الموعد بصيغة ISO 8601 مع فرق التوقيت" },
          attendee_email: { type: "string", description: "بريد العميل الإلكتروني إن توفر (اختياري)" }
        },
        required: ["summary", "start_time_iso", "end_time_iso"]
      }
    });
  }

  if (allowed.includes("send_email") && gmailConnected) {
    definitions.push({
      name: "send_email",
      description: "يرسل بريداً إلكترونياً. استخدمه فقط عند الحاجة الفعلية، مثل إرسال تفاصيل حجز أو ملخص للعميل.",
      parameters: {
        type: "object",
        properties: {
          to: { type: "string", description: "البريد الإلكتروني للمستلم" },
          subject: { type: "string", description: "عنوان الرسالة" },
          body: { type: "string", description: "نص الرسالة" }
        },
        required: ["to", "subject", "body"]
      }
    });
  }

  if (allowed.includes("notify_employee")) {
    definitions.push({
      name: "notify_employee",
      description: "يرسل إشعاراً داخلياً لأصحاب النشاط التجاري، مثلاً عند وجود عميل مهم أو طلب عاجل.",
      parameters: {
        type: "object",
        properties: { message: { type: "string", description: "نص الإشعار الموجه للموظف/صاحب النشاط" } },
        required: ["message"]
      }
    });
  }

  if (allowed.includes("trigger_webhook") && params.webhookUrl) {
    definitions.push({
      name: "trigger_webhook",
      description: "يرسل بيانات إلى نظام خارجي مرتبط (مثل CRM أو أداة أتمتة) عند حدث مهم في المحادثة.",
      parameters: {
        type: "object",
        properties: {
          event: { type: "string", description: "اسم الحدث، مثال: appointment_requested" },
          data: { type: "string", description: "بيانات الحدث كنص JSON" }
        },
        required: ["event"]
      }
    });
  }

  if (definitions.length === 0) return null;

  const executeTool = async (name: string, args: Record<string, unknown>): Promise<Record<string, unknown>> => {
    try {
      switch (name) {
        case "check_calendar_availability": {
          const accessToken = await getGoogleAccessToken(params.workspaceId, "google_calendar");
          const { busy } = await checkCalendarAvailability(accessToken, {
            timeMin: String(args.start_time_iso),
            timeMax: String(args.end_time_iso)
          });
          return { available: busy.length === 0, busy_slots: busy };
        }
        case "create_calendar_event": {
          const accessToken = await getGoogleAccessToken(params.workspaceId, "google_calendar");
          const event = await createCalendarEvent(accessToken, {
            summary: String(args.summary ?? "موعد"),
            startTime: String(args.start_time_iso),
            endTime: String(args.end_time_iso),
            attendeeEmail: args.attendee_email ? String(args.attendee_email) : undefined
          });
          return { success: true, event_id: event.id, event_link: event.htmlLink };
        }
        case "send_email": {
          const accessToken = await getGoogleAccessToken(params.workspaceId, "gmail");
          const result = await sendGmail(accessToken, {
            to: String(args.to),
            subject: String(args.subject),
            body: String(args.body)
          });
          return { success: true, message_id: result.id };
        }
        case "notify_employee": {
          const { data: owners } = await admin
            .from("workspace_members")
            .select("user_id")
            .eq("workspace_id", params.workspaceId)
            .in("role", ["owner", "admin"]);

          for (const owner of owners ?? []) {
            await admin.from("notifications").insert({
              workspace_id: params.workspaceId,
              user_id: owner.user_id,
              type: "agent_notification",
              title: "تنبيه من الوكيل الذكي",
              body: String(args.message ?? "")
            });
          }
          return { success: true, notified: owners?.length ?? 0 };
        }
        case "trigger_webhook": {
          const res = await fetch(params.webhookUrl!, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ event: args.event, data: args.data, agent_id: params.agentId })
          });
          return { success: res.ok, status: res.status };
        }
        default:
          return { error: "unknown tool" };
      }
    } catch (err: any) {
      // Surfaced back to the model as a function response, not thrown —
      // lets the AI tell the customer something sensible ("couldn't book
      // that, try another time") instead of the whole turn erroring out.
      return { error: err?.message ?? "tool execution failed" };
    }
  };

  return { definitions, executeTool };
}
