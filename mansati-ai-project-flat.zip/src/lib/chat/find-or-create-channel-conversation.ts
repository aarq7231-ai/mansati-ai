import "server-only";
import { createAdminClient } from "@/lib/supabase/admin";
import { ensureContactAndLead } from "@/lib/crm/lead-capture";

/**
 * Channel messages don't carry a conversationId the way the website widget
 * does — instead they're identified by the channel's own thread/chat id
 * (external_thread_id). This finds an existing open conversation for that
 * thread, or starts a new one (and, like the website flow, auto-creates a
 * contact + lead) — the same conversations/messages tables either way, per
 * the spec's "all channels feed into the same conversation engine".
 */
export async function findOrCreateChannelConversation(params: {
  workspaceId: string;
  agentId: string;
  channel: "telegram" | "whatsapp" | "instagram" | "messenger";
  externalThreadId: string;
}): Promise<{ conversationId: string; status: string; isNew: boolean }> {
  const admin = createAdminClient();

  const { data: existing } = await admin
    .from("conversations")
    .select("id, status")
    .eq("workspace_id", params.workspaceId)
    .eq("agent_id", params.agentId)
    .eq("channel", params.channel)
    .eq("external_thread_id", params.externalThreadId)
    .neq("status", "closed")
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (existing) {
    return { conversationId: existing.id, status: existing.status, isNew: false };
  }

  const { data: created } = await admin
    .from("conversations")
    .insert({
      workspace_id: params.workspaceId,
      agent_id: params.agentId,
      channel: params.channel,
      external_thread_id: params.externalThreadId
    })
    .select("id, status")
    .single();

  if (created) {
    await ensureContactAndLead({
      workspaceId: params.workspaceId,
      conversationId: created.id,
      channel: params.channel
    }).catch(() => {});
  }

  return { conversationId: created!.id, status: created!.status ?? "ai_active", isNew: true };
}
