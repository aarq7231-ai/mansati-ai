import "server-only";
import { createAdminClient } from "@/lib/supabase/admin";
import { getEmbeddingProvider, toVectorLiteral } from "@/lib/ai/embeddings";

const MATCH_COUNT = 4;
const SIMILARITY_THRESHOLD = 0.7; // below this, treat as "no relevant knowledge" (anti-hallucination)

/**
 * Embeds the user's message and runs a pgvector cosine-similarity search
 * against this agent's ready document chunks (see migration 0005). Returns
 * an empty array — not made-up content — when nothing clears the relevance
 * threshold, so the system prompt's fallback-message rule takes over.
 */
export async function retrieveRelevantChunks(params: {
  workspaceId: string;
  agentId: string;
  query: string;
}): Promise<string[]> {
  const admin = createAdminClient();

  try {
    const embeddingProvider = getEmbeddingProvider();
    const [queryVector] = await embeddingProvider.embed([params.query]);
    if (!queryVector) return [];

    const { data, error } = await admin.rpc("match_document_chunks", {
      p_agent_id: params.agentId,
      p_query_embedding: toVectorLiteral(queryVector),
      p_match_count: MATCH_COUNT
    });

    if (error || !data) return [];

    return (data as { content: string; similarity: number }[])
      .filter((row) => row.similarity >= SIMILARITY_THRESHOLD)
      .map((row) => row.content);
  } catch {
    // Retrieval failures should degrade to "no knowledge found", never crash the chat turn.
    return [];
  }
}
