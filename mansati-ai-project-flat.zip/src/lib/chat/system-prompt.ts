import type { ChatMessage } from "@/lib/ai/types";

export interface AgentSettingsForPrompt {
  agentName: string;
  businessName: string;
  language: string;
  personality: string | null;
  tone: string | null;
  systemInstructions: string | null;
  fallbackMessage: string;
  rules: unknown; // jsonb array of strings
  knowledgeContext: string[]; // retrieved chunks, empty until the RAG phase is built
  timezone?: string; // workspace.timezone, for grounding relative dates/times when tools are available
  hasTools?: boolean; // whether calendar (or other) tools are available this turn
}

/**
 * Anti-hallucination priority order (spec section 10):
 *   1. system instructions
 *   2. business settings
 *   3. retrieved knowledge
 *   4. conversation context
 * Each section below is labeled so the model treats earlier sections as
 * higher priority, and is explicitly told not to invent information that
 * isn't present in any of them.
 */
export function buildSystemPrompt(settings: AgentSettingsForPrompt): ChatMessage {
  const rules = Array.isArray(settings.rules) ? (settings.rules as string[]) : [];

  const sections: string[] = [];

  sections.push(
    `# تعليمات النظام (أعلى أولوية)\n` +
      `أنت "${settings.agentName}", الموظف الذكي لشركة "${settings.businessName}". ` +
      `تحدث باللغة: ${settings.language === "ar" ? "العربية" : "English"}.` +
      (settings.personality ? `\nالشخصية: ${settings.personality}` : "") +
      (settings.tone ? `\nنبرة الحديث: ${settings.tone}` : "")
  );

  if (settings.systemInstructions) {
    sections.push(`# إعدادات النشاط التجاري\n${settings.systemInstructions}`);
  }

  if (rules.length > 0) {
    sections.push(`# قواعد يجب الالتزام بها\n${rules.map((r) => `- ${r}`).join("\n")}`);
  }

  if (settings.knowledgeContext.length > 0) {
    sections.push(
      `# معلومات مسترجعة من قاعدة المعرفة\n${settings.knowledgeContext.join("\n---\n")}`
    );
  } else {
    sections.push(`# قاعدة المعرفة\nلا توجد معلومات مسترجعة لهذا السؤال.`);
  }

  if (settings.hasTools) {
    const tz = settings.timezone || "UTC";
    const now = new Date();
    sections.push(
      `# الوقت الحالي\n` +
        `التاريخ والوقت الآن (بتوقيت ${tz}): ${now.toLocaleString("sv-SE", { timeZone: tz })}. ` +
        `استخدم هذا لحساب أي تاريخ أو وقت نسبي يذكره العميل (مثل "غداً" أو "الثلاثاء القادم")، ` +
        `وقدّم أي وقت للأدوات بصيغة ISO 8601 كاملة مع فرق التوقيت.`
    );
  }

  sections.push(
    `# قاعدة صارمة لمنع الاختلاق\n` +
      `اعتمد فقط على المعلومات أعلاه وسياق المحادثة. إذا لم تجد إجابة مؤكدة، لا تختلق معلومات. ` +
      `بدلاً من ذلك، استخدم بالضبط هذه الرسالة: "${settings.fallbackMessage}"`
  );

  return { role: "system", content: sections.join("\n\n") };
}
