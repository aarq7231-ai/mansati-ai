import "server-only";
import { createClient as createSupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/types/database.types";

/**
 * ADMIN CLIENT — uses the service role key and BYPASSES ROW LEVEL SECURITY.
 *
 * The `server-only` import above makes Next.js throw a build error if this
 * file is ever imported into client-side code, as a guardrail against
 * accidentally shipping the service role key to the browser.
 *
 * Use this ONLY for:
 *  - trusted server-side jobs that must cross tenants (usage rollups, cron,
 *    webhook handlers verifying signatures before writing)
 *  - reading/writing integration_credentials (encrypted secrets)
 *  - platform admin panel operations after verifying is_platform_admin()
 *
 * Every other read/write should go through the regular server client
 * (lib/supabase/server.ts) so RLS keeps doing its job.
 */
export function createAdminClient() {
  return createSupabaseClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    {
      auth: { autoRefreshToken: false, persistSession: false }
    }
  );
}
