import { createBrowserClient } from "@supabase/ssr";
import type { Database } from "@/types/database.types";

/**
 * Client-side Supabase instance. Uses the public anon key only — RLS
 * policies (see supabase/migrations/0002_rls_policies.sql) are what
 * actually enforce tenant isolation, not this client.
 */
export function createClient() {
  return createBrowserClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
