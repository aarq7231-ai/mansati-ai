import "server-only";
import type { AIProvider, CompletionRequest } from "./types";

export async function completeNonStreaming(
  provider: AIProvider,
  request: CompletionRequest
): Promise<{ text: string; inputTokens: number; outputTokens: number }> {
  let text = "";
  let inputTokens = 0;
  let outputTokens = 0;

  for await (const chunk of provider.streamCompletion(request)) {
    if (chunk.delta) text += chunk.delta;
    if (chunk.done && chunk.usage) {
      inputTokens = chunk.usage.inputTokens;
      outputTokens = chunk.usage.outputTokens;
    }
  }

  return { text, inputTokens, outputTokens };
}
