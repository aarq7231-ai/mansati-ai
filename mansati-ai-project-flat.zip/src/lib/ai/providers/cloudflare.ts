import "server-only";
import type {
  AIProvider,
  ChatMessage,
  CompletionChunk,
  CompletionRequest,
  ToolCallResult,
  ToolDefinition
} from "../types";

const DEFAULT_MODEL = "@cf/meta/llama-3.2-1b-instruct";
const TOOL_MODEL = "@cf/qwen/qwen3-30b-a3b-fp8";
const MAX_TOOL_ROUNDS = 4;

type CloudflareMessage = {
  role: "system" | "user" | "assistant" | "tool";
  content: string | null;
  tool_calls?: Array<{ id: string; type: "function"; function: { name: string; arguments: string } }>;
  tool_call_id?: string;
};

function env(name: string): string {
  const value = process.env[name];
  if (!value) throw new Error(`${name} is not set.`);
  return value;
}

function normalizeModel(model?: string | null, fallback = DEFAULT_MODEL): string {
  if (!model || model.startsWith("gemini")) return fallback;
  return model.startsWith("@cf/") ? model : fallback;
}

function endpoint(path: string): string {
  return `https://api.cloudflare.com/client/v4/accounts/${env("CLOUDFLARE_ACCOUNT_ID")}/ai${path}`;
}

async function cloudflareFetch(path: string, body: unknown): Promise<Response> {
  return fetch(endpoint(path), {
    method: "POST",
    headers: {
      Authorization: `Bearer ${env("CLOUDFLARE_AI_API_TOKEN")}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  });
}

function toMessages(messages: ChatMessage[]): CloudflareMessage[] {
  return messages.map((m) => ({ role: m.role, content: m.content }));
}

export class CloudflareProvider implements AIProvider {
  readonly id = "cloudflare";

  async *streamCompletion(request: CompletionRequest): AsyncGenerator<CompletionChunk> {
    const model = normalizeModel(request.model, process.env.CLOUDFLARE_AI_MODEL || DEFAULT_MODEL);
    const res = await cloudflareFetch("/v1/chat/completions", {
      model,
      messages: toMessages(request.messages),
      temperature: request.temperature ?? 0.4,
      max_tokens: request.maxOutputTokens ?? 512,
      stream: true,
      stream_options: { include_usage: true }
    });

    if (!res.ok || !res.body) {
      throw new Error(`Cloudflare Workers AI request failed (${res.status}): ${await res.text().catch(() => "")}`);
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    let outputChars = 0;
    let usage: { inputTokens: number; outputTokens: number } | undefined;

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const frames = buffer.split("\n\n");
      buffer = frames.pop() ?? "";

      for (const frame of frames) {
        for (const rawLine of frame.split("\n")) {
          const line = rawLine.trim();
          if (!line.startsWith("data:")) continue;
          const payload = line.slice(5).trim();
          if (!payload || payload === "[DONE]") continue;
          try {
            const parsed = JSON.parse(payload);
            const delta = parsed?.choices?.[0]?.delta?.content;
            if (typeof delta === "string" && delta) {
              outputChars += delta.length;
              yield { delta, done: false };
            }
            if (parsed?.usage) {
              usage = {
                inputTokens: Number(parsed.usage.prompt_tokens ?? parsed.usage.input_tokens ?? 0),
                outputTokens: Number(parsed.usage.completion_tokens ?? parsed.usage.output_tokens ?? 0)
              };
            }
          } catch {
            // Ignore partial/malformed SSE frames; the next frame may complete the JSON.
          }
        }
      }
    }

    yield {
      delta: "",
      done: true,
      usage: usage ?? { inputTokens: 0, outputTokens: Math.ceil(outputChars / 4) }
    };
  }

  async completeWithTools(params: {
    messages: ChatMessage[];
    tools: ToolDefinition[];
    executeTool: (name: string, args: Record<string, unknown>) => Promise<Record<string, unknown>>;
    model?: string;
  }): Promise<{ text: string; toolCalls: ToolCallResult[]; usage: { inputTokens: number; outputTokens: number } }> {
    // Keep normal chat on the inexpensive 1B model. Only tool-enabled turns use
    // the Workers AI model with function-calling support.
    const model = process.env.CLOUDFLARE_TOOL_MODEL || TOOL_MODEL;
    let messages: CloudflareMessage[] = toMessages(params.messages);
    const toolCalls: ToolCallResult[] = [];
    let inputTokens = 0;
    let outputTokens = 0;

    const tools = params.tools.map((tool) => ({
      type: "function",
      function: {
        name: tool.name,
        description: tool.description,
        parameters: tool.parameters
      }
    }));

    for (let round = 0; round < MAX_TOOL_ROUNDS; round++) {
      const res = await cloudflareFetch("/v1/chat/completions", {
        model,
        messages,
        tools,
        tool_choice: "auto",
        temperature: 0.2,
        max_tokens: 768
      });

      if (!res.ok) {
        throw new Error(`Cloudflare Workers AI tool request failed (${res.status}): ${await res.text().catch(() => "")}`);
      }

      const data = await res.json();
      inputTokens += Number(data?.usage?.prompt_tokens ?? data?.usage?.input_tokens ?? 0);
      outputTokens += Number(data?.usage?.completion_tokens ?? data?.usage?.output_tokens ?? 0);

      const message = data?.choices?.[0]?.message;
      if (!message) return { text: "", toolCalls, usage: { inputTokens, outputTokens } };

      const calls = Array.isArray(message.tool_calls) ? message.tool_calls : [];
      if (calls.length === 0) {
        return {
          text: typeof message.content === "string" ? message.content : "",
          toolCalls,
          usage: { inputTokens, outputTokens }
        };
      }

      messages = [
        ...messages,
        {
          role: "assistant",
          content: typeof message.content === "string" ? message.content : null,
          tool_calls: calls.map((call: any) => ({
            id: String(call.id),
            type: "function",
            function: {
              name: String(call.function?.name ?? ""),
              arguments: String(call.function?.arguments ?? "{}")
            }
          }))
        }
      ];

      for (const call of calls) {
        const name = String(call.function?.name ?? "");
        let args: Record<string, unknown> = {};
        try {
          args = JSON.parse(String(call.function?.arguments ?? "{}"));
        } catch {
          args = {};
        }
        const result = await params.executeTool(name, args);
        toolCalls.push({ name, args, result });
        messages.push({
          role: "tool",
          content: JSON.stringify(result),
          tool_call_id: String(call.id)
        });
      }
    }

    return { text: "", toolCalls, usage: { inputTokens, outputTokens } };
  }
}
