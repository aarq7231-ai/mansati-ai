import "server-only";
import { routeModel } from "./router";
import { completeNonStreaming } from "./complete-non-streaming";

export async function extractLeadAnswers(params: {
  questions: string[];
  conversationText: string;
}): Promise<Record<string, string>> {
  if (params.questions.length === 0) return {};

  const prompt =
    `فيما يلي محادثة بين عميل ووكيل ذكي، والأسئلة التالية التي يريد صاحب النشاط التجاري إجاباتها:\n\n` +
    params.questions.map((q, i) => `${i + 1}. ${q}`).join("\n") +
    `\n\nالمحادثة:\n${params.conversationText}\n\n` +
    `أرجع فقط كائن JSON صالح يربط كل سؤال بإجابته، ولا تدرج إلا الأسئلة التي توجد لها إجابة واضحة ومؤكدة في المحادثة. ` +
    `لا تخترع إجابات. إن لم توجد إجابة لأي سؤال، لا تدرجه في الكائن. لا تكتب أي نص خارج كائن JSON.`;

  try {
    const { provider, model } = routeModel({});
    const result = await completeNonStreaming(provider, {
      messages: [
        { role: "system", content: "أنت مستخرج بيانات CRM. أعد JSON فقط." },
        { role: "user", content: prompt }
      ],
      model
    });

    const parsed = JSON.parse(result.text.trim());
    if (typeof parsed !== "object" || parsed === null) return {};

    const output: Record<string, string> = {};
    for (const q of params.questions) {
      if (typeof (parsed as any)[q] === "string" && (parsed as any)[q].trim()) {
        output[q] = (parsed as any)[q].trim();
      }
    }
    return output;
  } catch {
    return {};
  }
}
