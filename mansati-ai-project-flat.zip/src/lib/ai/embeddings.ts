import "server-only";

export interface EmbeddingProvider {
  readonly id: string;
  embed(texts: string[]): Promise<number[][]>;
}

const EMBEDDING_MODEL = "@cf/google/embeddinggemma-300m";
const EMBEDDING_DIMENSIONS = 768;

class CloudflareEmbeddingProvider implements EmbeddingProvider {
  readonly id = "cloudflare";

  async embed(texts: string[]): Promise<number[][]> {
    const accountId = process.env.CLOUDFLARE_ACCOUNT_ID;
    const apiToken = process.env.CLOUDFLARE_AI_API_TOKEN;
    if (!accountId || !apiToken) {
      throw new Error("Cloudflare Workers AI credentials are not configured.");
    }

    const url = `https://api.cloudflare.com/client/v4/accounts/${accountId}/ai/run/${EMBEDDING_MODEL}`;
    const res = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiToken}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ text: texts })
    });

    if (!res.ok) {
      throw new Error(`Cloudflare embedding request failed (${res.status}): ${await res.text().catch(() => "")}`);
    }

    const data = await res.json();
    const vectors = data?.result?.data ?? data?.data ?? [];
    if (!Array.isArray(vectors)) throw new Error("Cloudflare embedding response was invalid.");

    const normalized = vectors.map((vector: unknown) => (Array.isArray(vector) ? vector.map(Number) : []));
    if (normalized.some((vector: number[]) => vector.length !== EMBEDDING_DIMENSIONS)) {
      throw new Error(`Cloudflare embedding dimension mismatch; expected ${EMBEDDING_DIMENSIONS}.`);
    }
    return normalized;
  }
}

const embeddingProvider = new CloudflareEmbeddingProvider();

export function getEmbeddingProvider(): EmbeddingProvider {
  return embeddingProvider;
}

export function toVectorLiteral(values: number[]): string {
  return `[${values.join(",")}]`;
}
