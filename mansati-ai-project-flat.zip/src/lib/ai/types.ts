/**
 * AI Provider abstraction (spec section 39).
 *
 * Nothing in the chat engine should ever import a specific provider
 * (Cloudflare Workers AI, DeepSeek, etc.) directly — everything goes through this
 * interface + the ModelRouter (./router.ts), so adding a new provider
 * later never requires touching the chat route or agent builder.
 */

export interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface CompletionRequest {
  messages: ChatMessage[];
  model?: string;
  maxOutputTokens?: number;
  temperature?: number;
}

export interface CompletionChunk {
  /** Incremental text delta for streaming. */
  delta: string;
  /** Set on the final chunk. */
  done: boolean;
  /** Only populated on the final chunk, when the provider reports it. */
  usage?: { inputTokens: number; outputTokens: number };
}

export interface ToolDefinition {
  name: string;
  description: string;
  parameters: {
    type: "object";
    properties: Record<string, { type: string; description: string }>;
    required?: string[];
  };
}

export interface ToolCallResult {
  name: string;
  args: Record<string, unknown>;
  result: Record<string, unknown>;
}

export interface AIProvider {
  /** Machine-readable id, e.g. "cloudflare", "deepseek". Matches agent_settings.ai_provider. */
  readonly id: string;

  /** Streams the completion as an async generator of text chunks. */
  streamCompletion(request: CompletionRequest): AsyncGenerator<CompletionChunk>;

  /**
   * Optional: providers that support function calling implement this.
   * Runs the model-decides-then-calls-a-function loop internally (up to a
   * few rounds) and returns the final text plus a record of what was
   * actually executed, so callers can log/persist tool activity.
   * Not every provider needs to implement this — callers must check for
   * its presence before use.
   */
  completeWithTools?(params: {
    messages: ChatMessage[];
    tools: ToolDefinition[];
    executeTool: (name: string, args: Record<string, unknown>) => Promise<Record<string, unknown>>;
    model?: string;
  }): Promise<{ text: string; toolCalls: ToolCallResult[]; usage?: { inputTokens: number; outputTokens: number } }>;
}
