import "server-only";
import type { AIProvider } from "./types";
import { CloudflareProvider } from "./providers/cloudflare";

const cloudflare = new CloudflareProvider();

export interface RouteDecision {
  provider: AIProvider;
  model?: string;
}

/**
 * Mansati uses Cloudflare Workers AI as its sole runtime AI provider.
 * Legacy Gemini settings are intentionally mapped to the Cloudflare defaults
 * so existing agents continue working after migration without a manual edit.
 */
export function routeModel(params: {
  preferredProvider?: string | null;
  preferredModel?: string | null;
}): RouteDecision {
  const preferredModel = params.preferredModel;
  const model = preferredModel && preferredModel.startsWith("@cf/") ? preferredModel : undefined;
  return { provider: cloudflare, model };
}
