import "server-only";

/**
 * Billing provider abstraction (spec section 30). Nothing outside
 * src/lib/billing/ and the two /api/billing/* routes should know which
 * payment provider is in use — checkout, webhooks, and cancellation all
 * go through this interface so a region-specific provider can be added
 * later (many payment providers aren't available in every country) without
 * touching the dashboard or the subscriptions data model.
 */
export interface CreateCheckoutParams {
  workspaceId: string;
  planId: string;
  customerEmail?: string;
  successUrl: string;
  cancelUrl: string;
}

export interface BillingProvider {
  readonly id: string;
  createCheckoutSession(params: CreateCheckoutParams): Promise<{ url: string }>;
  /** Verifies the webhook signature and returns a normalized event, or throws if invalid. */
  verifyWebhook(rawBody: string, signatureHeader: string | null): Promise<NormalizedBillingEvent>;
  cancelSubscription(providerSubscriptionId: string): Promise<void>;
}

export type NormalizedBillingEvent =
  | { type: "checkout_completed"; workspaceId: string; providerCustomerId: string; providerSubscriptionId: string; currentPeriodStart: string; currentPeriodEnd: string }
  | { type: "payment_failed"; providerSubscriptionId: string }
  | { type: "subscription_canceled"; providerSubscriptionId: string }
  | { type: "subscription_renewed"; providerSubscriptionId: string; currentPeriodStart: string; currentPeriodEnd: string }
  | { type: "ignored" };
