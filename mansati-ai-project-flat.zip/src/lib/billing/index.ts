import "server-only";
import type { BillingProvider } from "./types";
import { StripeProvider } from "./providers/stripe";

const providers: Record<string, BillingProvider> = {
  stripe: new StripeProvider()
};

/**
 * Returns the billing provider to use for a workspace. Defaults to Stripe
 * for now; a workspace-level "which provider is available in my country"
 * setting is a natural extension point here later — nothing else in the
 * app needs to change to support it.
 */
export function getBillingProvider(id = "stripe"): BillingProvider {
  return providers[id] ?? providers.stripe;
}
