import "server-only";
import { createAdminClient } from "@/lib/supabase/admin";
import type { BillingProvider, CreateCheckoutParams, NormalizedBillingEvent } from "../types";

/**
 * Stripe adapter. Every call checks for STRIPE_SECRET_KEY itself rather
 * than assuming it's configured — this class can exist and be registered
 * in the provider registry even before a business owner has connected
 * Stripe; it just throws a clear, actionable error until they do.
 */
export class StripeProvider implements BillingProvider {
  readonly id = "stripe";

  private async getClient() {
    const secretKey = process.env.STRIPE_SECRET_KEY;
    if (!secretKey) {
      throw new Error(
        "STRIPE_SECRET_KEY is not set. Add it to .env.local once you've created a Stripe account — see README Phase 7 setup."
      );
    }
    // Lazy import: the `stripe` package is only required once billing is
    // actually configured, keeping it out of the critical path otherwise.
    const Stripe = (await import("stripe")).default;
    return new Stripe(secretKey, { apiVersion: "2024-06-20" });
  }

  async createCheckoutSession(params: CreateCheckoutParams): Promise<{ url: string }> {
    const stripe = await this.getClient();
    const admin = createAdminClient();

    const { data: plan } = await admin
      .from("plans")
      .select("id, provider_metadata")
      .eq("id", params.planId)
      .single();

    const priceId = (plan?.provider_metadata as any)?.stripe?.price_id;
    if (!priceId) {
      throw new Error(
        "This plan has no Stripe price configured yet. Set plans.provider_metadata.stripe.price_id from the Stripe Dashboard (Admin Panel phase will expose this in the UI)."
      );
    }

    const { data: subscription } = await admin
      .from("subscriptions")
      .select("provider_customer_id")
      .eq("workspace_id", params.workspaceId)
      .maybeSingle();

    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      line_items: [{ price: priceId, quantity: 1 }],
      customer: subscription?.provider_customer_id || undefined,
      customer_email: subscription?.provider_customer_id ? undefined : params.customerEmail,
      success_url: params.successUrl,
      cancel_url: params.cancelUrl,
      metadata: { workspace_id: params.workspaceId, plan_id: params.planId }
    });

    if (!session.url) throw new Error("Stripe did not return a checkout URL");
    return { url: session.url };
  }

  async verifyWebhook(rawBody: string, signatureHeader: string | null): Promise<NormalizedBillingEvent> {
    const stripe = await this.getClient();
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
    if (!webhookSecret || !signatureHeader) {
      throw new Error("Missing Stripe webhook secret or signature header");
    }

    const event = stripe.webhooks.constructEvent(rawBody, signatureHeader, webhookSecret);

    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as any;
        const workspaceId = session.metadata?.workspace_id;
        if (!workspaceId || !session.subscription || !session.customer) return { type: "ignored" };

        const stripeSub = await stripe.subscriptions.retrieve(session.subscription as string);
        return {
          type: "checkout_completed",
          workspaceId,
          providerCustomerId: session.customer as string,
          providerSubscriptionId: stripeSub.id,
          currentPeriodStart: new Date(stripeSub.current_period_start * 1000).toISOString(),
          currentPeriodEnd: new Date(stripeSub.current_period_end * 1000).toISOString()
        };
      }
      case "invoice.payment_failed": {
        const invoice = event.data.object as any;
        return { type: "payment_failed", providerSubscriptionId: invoice.subscription as string };
      }
      case "customer.subscription.deleted": {
        const sub = event.data.object as any;
        return { type: "subscription_canceled", providerSubscriptionId: sub.id };
      }
      case "customer.subscription.updated": {
        const sub = event.data.object as any;
        if (sub.status === "active") {
          return {
            type: "subscription_renewed",
            providerSubscriptionId: sub.id,
            currentPeriodStart: new Date(sub.current_period_start * 1000).toISOString(),
            currentPeriodEnd: new Date(sub.current_period_end * 1000).toISOString()
          };
        }
        return { type: "ignored" };
      }
      default:
        return { type: "ignored" };
    }
  }

  async cancelSubscription(providerSubscriptionId: string): Promise<void> {
    const stripe = await this.getClient();
    await stripe.subscriptions.cancel(providerSubscriptionId);
  }
}
